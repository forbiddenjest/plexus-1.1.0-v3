# Plexus Virtualization 1.1.0 (stable)

Self-hosted KVM virtualization by PlexScale: a web panel for administrators and customers,
and lightweight cluster nodes that run the virtual machines.

```text
plexus/
├── README.md        this file
├── VERSION          release number (read by the installer and the tests)
├── web/             install on the PANEL SERVER only
│   ├── plexus/          Python package: app, routes, services, templates, static files
│   ├── migrations/      database migrations (0001 … 0008)
│   ├── deploy/          install.sh, systemd units, Caddyfile, `plexus` command
│   ├── pyproject.toml   pinned dependencies
│   └── .env.example     every PLEXUS_* setting
├── node/            the ONLY files a cluster node receives
│   ├── setup.sh.j2      enrollment script (filled in by the panel)
│   ├── bin/             plexus-node (helper), plexus-node-selftest
│   └── systemd/         plexus-node.service, plexus-rules.path, plexus-node-refresh.service
└── test/            tests for a real deployment (never installed anywhere)
    ├── test_*.py        177 unit and integration tests (pytest)
    ├── run_all.sh       runs every check against your installation
    └── e2e/             plexus_e2e.py (live panel + nodes), simulated_nodes.py (rehearsal)
```

## Install

**Panel server** (Ubuntu 24.04 / Debian 12, Python 3.12):

```bash
sudo bash plexus/web/deploy/install.sh
sudo nano /etc/plexus/plexus.env                  # set PLEXUS_TRUSTED_HOST
sudo cp /opt/plexus/deploy/caddy/Caddyfile /etc/caddy/Caddyfile   # put your hostname in it
sudo systemctl reload caddy
sudo plexus create-admin you@plexus.io --username admin
sudo systemctl start Plexus
sudo plexus doctor
```

The installer puts the panel in `/opt/plexus`, the node files in `/opt/plexus/node`, settings
in `/etc/plexus/plexus.env` and data in `/var/lib/plexus`. It backs up the database before
every upgrade and is safe to run again.

**Each node**: in the panel open **Administration › Clusters › Add cluster**, run the one-time
command it shows (valid 15 minutes) as root on the node, then press **Verify**:

```bash
curl -fsSL --proto '=https' https://<panel-host>/node-setup/<token> | sudo bash
```

## Services and everyday commands

| Where | Unit | What it does |
|---|---|---|
| panel | `Plexus.service` | the whole panel (starts the two below) |
| panel | `plexus-web.service` | web interface on 127.0.0.1:8000 behind Caddy (TLS) |
| panel | `clusters.service` (`plexus-clusters`) | jobs, machine transfers, live states, metrics |
| node | `plexus-node.service`, `plexus-rules.path` | guest network, firewall and NAT rules |
| node | `<node name>.service` | `systemctl restart <node name>` quick fix (guests keep running) |

```bash
sudo plexus status | doctor | nodes | logs
sudo plexus node verify <name> | node refresh <name>
sudo plexus machine reset-state <vm-id>
sudo plexus-node-selftest            # on a node: read-only health report (--json for monitoring)
```

## Testing on your machines

```bash
# everything: unit tests, node self-test over SSH, live end-to-end checks (read-only)
sudo bash plexus/test/run_all.sh --url https://panel.plexus.io --email admin@plexus.io \
     --nodes "root@node-01 root@node-02"

# add the full lifecycle on real nodes: create, stop, start, restart,
# transfer to another node and back, delete (one test machine)
sudo bash plexus/test/run_all.sh --url https://panel.plexus.io --email admin@plexus.io \
     --nodes "root@node-01 root@node-02" \
     --destructive --owner-id 1 --image-id 1 --source-cluster-id 1 --target-cluster-id 2
```

The administrator password is asked once (or read from `PLEXUS_QA_PASSWORD`) and never printed.
IDs are in the panel URLs (for example `/administrator/clusters/2/edit`). Results go to
`plexus/test/results-<date>.json`; exit status 0 means every check passed.

Unit tests only: `cd plexus/test && pytest -q` (after `pip install -e '../web[test]'`).

Rehearse without real nodes (real panel, two simulated nodes, temporary database):

```bash
cd plexus/test && python3 -m venv .venv && .venv/bin/pip install -e '../web[test]'
.venv/bin/python e2e/simulated_nodes.py --port 8099            # admin@plexus.io / plexus-admin-2026
PLEXUS_QA_PASSWORD=plexus-admin-2026 python3 e2e/plexus_e2e.py --url http://127.0.0.1:8099 \
   --email admin@plexus.io --verify-nodes --destructive --owner-id 2 --image-id 1 \
   --source-cluster-id 1 --target-cluster-id 2 --timeout 60
```

## What is new in 1.1.0

**Machine Transfer** (Administration › Machines › Edit): moves a machine with all its data to
another available node. A pre-flight check runs first; if it fails nothing changes. The disk is
copied from a read-only snapshot over pinned, encrypted SSH and verified with SHA-256 and
`qemu-img check`. The machine receives the target node's next free IPv4 and its guest network
is rewritten automatically; the old address is held until the move is confirmed. Any failure
before the switch restores the machine on its original node with its original address, and a
restart of the clusters service resumes safely. A **Machine Transfer in Progress...** window
shows a circular % ring, each step, copy speed and the old and new IPv4.

**Live states and metrics**: states update on screen within seconds; transitional states are
re-checked every 5 s and every node fully every 30 s, in parallel. Metrics use exact sample
times, ignore counter resets and gaps, and are never shown as live once stale.

**Interface**: new user icon, larger dashboard logo, logo-only favicon, footer "Plexus
Virtualization", full IP addresses in administration (still masked on customer dashboards).

**Release**: `web/`, `node/` and `test/` layout; database migration `0008_transfer_progress`.
