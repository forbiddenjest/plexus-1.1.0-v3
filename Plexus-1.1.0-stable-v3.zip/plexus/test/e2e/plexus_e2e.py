#!/usr/bin/env python3
"""Plexus Virtualization - end-to-end test of a running panel and its real nodes.

Standard library only: runs with any Python 3.9+ on the panel server or your workstation.

Read-only checks (default) never change anything:
    python3 plexus/test/e2e/plexus_e2e.py --url https://vps.example.com --email admin@example.com

Full lifecycle on real nodes (creates, powers, transfers and deletes ONE test machine):
    python3 plexus/test/e2e/plexus_e2e.py --url https://vps.example.com --email admin@example.com \
        --destructive --owner-id 1 --image-id 1 --source-cluster-id 1 --target-cluster-id 2

The password is read from PLEXUS_QA_PASSWORD or asked for interactively; it is never printed.
Exit status: 0 = all checks passed, 1 = at least one failure.
"""
from __future__ import annotations

import argparse
import getpass
import http.cookiejar
import json
import os
import re
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

STATES = {"provisioning", "running", "stopped", "starting", "stopping", "restarting", "rebuilding", "deleting",
          "suspended", "failed", "transferring", "unknown"}
SETTLED = {"running", "stopped", "suspended", "failed"}
ADMIN_PAGES = ["/administrator/overview", "/administrator/accounts", "/administrator/clusters", "/administrator/machines",
               "/administrator/network", "/administrator/images", "/administrator/logs", "/administrator/others",
               "/administrator/metrics"]
IPV4 = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")


class Panel:
    def __init__(self, base: str, insecure: bool):
        self.base = base.rstrip("/")
        context = ssl.create_default_context()
        if insecure:
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
        self.jar = http.cookiejar.CookieJar()

        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, *args, **kwargs):
                return None
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar),
                                                  urllib.request.HTTPSHandler(context=context), NoRedirect)
        self.csrf = ""

    def request(self, method: str, path: str, form: dict | None = None, timeout: int = 30):
        data = urllib.parse.urlencode(form).encode() if form is not None else None
        req = urllib.request.Request(self.base + path, data=data, method=method,
                                     headers={"User-Agent": "plexus-e2e/1.1", "Accept": "text/html,application/json"})
        if data is not None:
            req.add_header("Content-Type", "application/x-www-form-urlencoded")
        try:
            with self.opener.open(req, timeout=timeout) as response:
                return response.status, dict(response.headers), response.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as exc:
            return exc.code, dict(exc.headers or {}), exc.read().decode("utf-8", "replace") if exc.fp else ""

    def get(self, path, **kw):
        return self.request("GET", path, **kw)

    def post(self, path, form, **kw):
        form = {"csrf_token": self.csrf, **form}
        return self.request("POST", path, form, **kw)

    def json(self, path):
        status, _, body = self.get(path)
        if status != 200:
            raise AssertionError(f"GET {path} returned {status}")
        return json.loads(body)

    def refresh_csrf(self, html: str):
        found = re.search(r'name="csrf_token" value="([^"]+)"', html) or re.search(r'<meta name="csrf-token" content="([^"]+)"', html)
        if found:
            self.csrf = found.group(1)


class Report:
    def __init__(self):
        self.results = []

    def check(self, name: str, fn):
        try:
            note = fn() or ""
            self.results.append((name, True, note))
            print(f"  PASS  {name}" + (f"  ({note})" if note else ""), flush=True)
            return True
        except Exception as exc:  # report and continue with the next check
            self.results.append((name, False, str(exc)))
            print(f"  FAIL  {name}: {exc}", flush=True)
            return False

    @property
    def failed(self):
        return [r for r in self.results if not r[1]]


def expect(condition, message):
    if not condition:
        raise AssertionError(message)


def wait_for(fn, timeout: float, interval: float = 2.0, what: str = "condition"):
    deadline = time.monotonic() + timeout
    last = None
    while time.monotonic() < deadline:
        last = fn()
        if last:
            return last
        time.sleep(interval)
    raise AssertionError(f"timed out after {int(timeout)} s waiting for {what}")


# ------------------------------------------------------------------ read-only checks

def read_only(panel: Panel, report: Report, email: str, password: str, verify_nodes: bool):
    print("\nPanel")
    report.check("health endpoint", lambda: expect(panel.get("/healthz")[0:3:2] == (200, "ok"), "/healthz is not ok"))

    def headers():
        status, h, html = panel.get("/auth")
        expect(status == 200, f"/auth returned {status}")
        lower = {k.lower(): v for k, v in h.items()}
        for name in ("content-security-policy", "x-frame-options", "x-content-type-options", "referrer-policy"):
            expect(name in lower, f"missing {name}")
        if panel.base.startswith("https://"):
            expect("strict-transport-security" in lower, "missing HSTS on HTTPS")
        expect("Plexus Virtualization" in html, "footer text missing")
        panel.refresh_csrf(html)
    report.check("sign-in page and security headers", headers)

    def wrong_password():
        status, _, body = panel.post("/auth", {"email": email, "password": password + "-wrong"})
        expect(status == 401, f"wrong password was not refused ({status})")
        panel.refresh_csrf(panel.get("/auth")[2])
    report.check("wrong password is rejected", wrong_password)

    def sign_in():
        status, h, _ = panel.post("/auth", {"email": email, "password": password})
        expect(status == 303 and "/dashboard" in h.get("location", h.get("Location", "")), f"sign-in failed ({status})")
        status, _, html = panel.get("/dashboard")
        expect(status == 200, f"dashboard returned {status}")
        panel.refresh_csrf(html)
        expect('class="brand-logo"' in html and 'width="52"' in html, "dashboard logo missing")
        expect('class="user-icon"' in html, "user icon missing")
    if not report.check("administrator sign-in and dashboard", sign_in):
        return False

    def forged_csrf():
        status, _, _ = panel.request("POST", "/account/password", {"csrf_token": "forged", "current_password": "x", "new_password": "y", "confirm_password": "y"})
        expect(status == 403, f"forged CSRF token returned {status}, expected 403")
    report.check("forged CSRF token is refused", forged_csrf)

    for page in ADMIN_PAGES:
        report.check(f"page {page}", lambda page=page: expect(panel.get(page)[0] == 200, f"{page} did not load"))

    def network_plain():
        html = panel.get("/administrator/network")[2]
        expect("ip-blur" not in html, "administration network page still blurs addresses")
    report.check("administration shows full IP addresses", network_plain)

    print("\nLive states")
    snapshots = []

    def live_shape():
        data = panel.json("/dashboard/live?scope=all")
        for m in data["machines"]:
            expect(m["state"] in STATES, f"{m['id']} has unknown state {m['state']}")
        expect(data["running"] == sum(1 for m in data["machines"] if m["state"] == "running"), "running count is inconsistent")
        snapshots.append({m["id"]: m["state"] for m in data["machines"]})
        return f"{data['total']} machines, {data['running']} running"
    report.check("dashboard live data", live_shape)

    def no_flapping():
        for _ in range(3):
            time.sleep(10)
            snapshots.append({m["id"]: m["state"] for m in panel.json("/dashboard/live?scope=all")["machines"]})
        flapping = []
        for vm in snapshots[0]:
            seen = [s.get(vm) for s in snapshots if vm in s]
            settled = [x for x in seen if x in SETTLED]
            if len(set(settled)) > 1 and len(set(seen)) == len(set(settled)):
                flapping.append(f"{vm}: {' -> '.join(seen)}")
        expect(not flapping, "states changed without an operation: " + "; ".join(flapping))
        return "stable over 30 s"
    report.check("settled states stay stable", no_flapping)

    def metrics_fresh():
        latest = snapshots[-1] if snapshots else {}
        running = [vm for vm, state in latest.items() if state == "running"][:10]
        stale = []
        for vm in running:
            status, _, html = panel.get(f"/machines/{vm}/metrics/live")
            if status == 200 and ("No live usage" in html or "not live" in html.lower()):
                stale.append(vm)
        expect(not stale, "running machines without fresh metrics: " + ", ".join(stale))
        return f"{len(running)} running machines checked"
    report.check("running machines have fresh metrics", metrics_fresh)

    if verify_nodes:
        print("\nNodes")
        html = panel.get("/administrator/clusters")[2]
        panel.refresh_csrf(html)
        ids = sorted(set(re.findall(r'/administrator/clusters/(\d+)/edit', html)), key=int)
        for cid in ids:
            def verify(cid=cid):
                status, _, body = panel.post(f"/administrator/clusters/{cid}/verify", {})
                expect(status == 200, f"verify returned {status}")
                failed = re.search(r"Verification failed for ([^<]+)", body)
                expect(not failed, failed.group(0) if failed else "")
                found = re.search(r"([\w.-]+) verified and (\w+)", re.sub(r"<[^>]+>", " ", body))
                expect(found, "no verification result on the page")
                return f"{found.group(1)} {found.group(2)}"
            report.check(f"node {cid} verify", verify)
    return True


# ------------------------------------------------------------------ destructive lifecycle

def machine_ip(panel: Panel, machine_id: str) -> str:
    html = panel.get("/administrator/machines")[2]
    row = next((r for r in re.split(r"<tr", html) if machine_id in r), "")
    found = IPV4.findall(row)
    return found[0] if found else ""


def lifecycle(panel: Panel, report: Report, args):
    print("\nMachine lifecycle on real nodes (creates and deletes one test machine)")
    state = {}

    def live():
        return panel.json(f"/machines/{state['id']}/live")

    def wait_state(target: str, timeout: int):
        seen = []

        def done():
            s = live()["state"]
            if not seen or seen[-1] != s:
                seen.append(s)
            expect(s != "failed", "machine failed: " + " -> ".join(seen))
            return s == target
        wait_for(done, timeout, what=f"state {target}")
        return " -> ".join(seen)

    def create():
        panel.refresh_csrf(panel.get("/administrator/machines/new")[2])
        status, _, html = panel.post("/administrator/machines", {"owner_id": args.owner_id, "cluster_id": args.source_cluster_id, "image_id": args.image_id,
                                                                 "vcpu": "1", "memory_mb": "1024", "disk_gb": "10"})
        found = re.search(r"(vm-[a-z0-9]{5}) queued for provisioning", html)
        expect(status == 200 and found, f"create failed ({status})")
        state["id"] = found.group(1)
        panel.refresh_csrf(html)
        return state["id"]
    if not report.check("create test machine", create):
        return

    report.check("provisioned and running", lambda: wait_state("running", args.timeout))
    state["ip"] = machine_ip(panel, state["id"])

    pending = {"stop": "stopping", "start": "starting", "restart": "restarting"}

    def power(action, expected):
        def run():
            panel.refresh_csrf(panel.get(f"/machines/{state['id']}")[2])
            status, _, body = panel.post(f"/machines/{state['id']}/actions", {"action": action})
            expect(status == 200 and "queued" in body, f"{action} not queued ({status})")
            # The pending state is visible at once (no reload, no stale badge).
            now = live()["state"]
            expect(now in {pending[action], expected}, f"state is {now} right after {action}, expected {pending[action]}")
            result = wait_state(expected, args.timeout)
            time.sleep(2)  # let the worker close the job before the next action
            return result
        return run
    report.check("stop", power("stop", "stopped"))
    report.check("start", power("start", "running"))
    report.check("restart", power("restart", "running"))

    def transfer(target_id, label):
        def run():
            html = panel.get(f"/administrator/machines/{state['id']}/edit")[2]
            panel.refresh_csrf(html)
            vm_name = re.search(r'name="confirm_name" pattern="(vm\d{6})"', html)
            expect(vm_name, "machine name not found on the edit page")
            before = machine_ip(panel, state["id"])
            status, _, body = panel.post(f"/administrator/machines/{state['id']}/transfer", {"target_cluster_id": target_id, "confirm_name": vm_name.group(1)})
            expect(status == 200 and "Machine Transfer in Progress" in body, f"transfer not queued ({status})")
            percents, stages = [], []

            def finished():
                s = panel.json(f"/administrator/machines/{state['id']}/transfer/status")
                percents.append(s.get("percent", 0))
                if s.get("stage") and (not stages or stages[-1] != s["stage"]):
                    stages.append(s["stage"])
                expect(s["state"] != "failed", "transfer failed: " + s.get("result", ""))
                return s if s["state"] == "complete" else None
            result = wait_for(finished, args.timeout * 3, interval=1.0, what="transfer to finish")
            expect(all(a <= b for a, b in zip(percents, percents[1:])), "progress went backwards")
            expect(percents[-1] == 100, "progress did not reach 100 %")
            after = machine_ip(panel, state["id"])
            expect(after and after != before, f"IPv4 did not change ({before} -> {after})")
            expect(live()["state"] == "running", "machine is not running after the transfer")
            return f"{label}: {before} -> {after}, stages {' > '.join(stages)}"
        return run
    report.check("transfer to target node", transfer(args.target_cluster_id, "out"))
    report.check("transfer back to source node", transfer(args.source_cluster_id, "back"))

    def delete():
        html = panel.get(f"/administrator/machines/{state['id']}/edit")[2]
        panel.refresh_csrf(html)
        vm_name = re.search(r'name="confirm_name" pattern="(vm\d{6})"', html).group(1)
        status, _, _ = panel.post(f"/administrator/machines/{state['id']}/delete", {"confirm_name": vm_name})
        expect(status == 303, f"delete returned {status}")
        wait_for(lambda: panel.get(f"/machines/{state['id']}/live")[0] == 404, args.timeout, what="machine to be removed")
    report.check("delete test machine", delete)


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--url", required=True, help="panel URL, e.g. https://vps.example.com")
    parser.add_argument("--email", required=True, help="administrator email")
    parser.add_argument("--insecure", action="store_true", help="accept a self-signed certificate (test labs only)")
    parser.add_argument("--verify-nodes", action="store_true", help="run Verify on every node (read-only on the node)")
    parser.add_argument("--destructive", action="store_true", help="create, power, transfer and delete one test machine")
    parser.add_argument("--owner-id"); parser.add_argument("--image-id")
    parser.add_argument("--source-cluster-id"); parser.add_argument("--target-cluster-id")
    parser.add_argument("--timeout", type=int, default=600, help="seconds to wait for each machine operation")
    parser.add_argument("--json", metavar="FILE", help="also write the results as JSON")
    args = parser.parse_args()
    if args.destructive and not all([args.owner_id, args.image_id, args.source_cluster_id, args.target_cluster_id]):
        parser.error("--destructive needs --owner-id, --image-id, --source-cluster-id and --target-cluster-id")
    password = os.environ.get("PLEXUS_QA_PASSWORD") or getpass.getpass("Administrator password: ")

    panel, report = Panel(args.url, args.insecure), Report()
    print(f"Plexus Virtualization end-to-end test: {args.url}")
    if read_only(panel, report, args.email, password, args.verify_nodes) and args.destructive:
        lifecycle(panel, report, args)

    passed = len(report.results) - len(report.failed)
    print(f"\n{passed} passed, {len(report.failed)} failed")
    if args.json:
        with open(args.json, "w") as f:
            json.dump([{"check": n, "passed": ok, "note": note} for n, ok, note in report.results], f, indent=2)
    sys.exit(1 if report.failed else 0)


if __name__ == "__main__":
    main()
