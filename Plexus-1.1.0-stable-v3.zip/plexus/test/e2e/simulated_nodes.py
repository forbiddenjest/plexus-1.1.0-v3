#!/usr/bin/env python3
"""Plexus with simulated nodes: the real web panel and clusters service against two
SIMULATED cluster nodes, so test/e2e/plexus_e2e.py (including --destructive) can be
rehearsed on any machine without KVM.

    cd plexus/test && python3 -m venv .venv && .venv/bin/pip install -e '../web[test]'
    .venv/bin/python e2e/simulated_nodes.py --port 8099          # leave running
    PLEXUS_QA_PASSWORD=plexus-admin-2026 python3 e2e/plexus_e2e.py --url http://127.0.0.1:8099 \
        --email admin@plexus.io --verify-nodes --destructive --owner-id 2 --image-id 1 \
        --source-cluster-id 1 --target-cluster-id 2 --timeout 60

Everything runs in a throw-away database under /tmp. Only hypervisor calls are simulated;
routes, authorization, the job queue, transfer orchestration, rollback, progress, reconcile
and metrics are the production code.
"""
import argparse
import asyncio
import os
import random
import sys
import tempfile
import threading
import time
import types
from pathlib import Path

PANEL = Path(__file__).resolve().parents[2] / "web"
sys.path.insert(0, str(PANEL))
_tmp = tempfile.mkdtemp(prefix="plexus-sim-")
os.environ.update({
    "PLEXUS_DATABASE_URL": f"sqlite:///{_tmp}/plexus.db", "PLEXUS_MEDIA_PATH": f"{_tmp}/media",
    "PLEXUS_SECRET_KEY": "plexus-simulated-secret-" + "x" * 32, "PLEXUS_ENCRYPTION_KEY": "Ufz3m0t2b8iZbJk1lW3c0bT6jQwq9r0D7kJmE4yH5aE=",
    "PLEXUS_ENVIRONMENT": "development", "PLEXUS_SECURE_COOKIES": "false", "PLEXUS_TRUSTED_HOST": "127.0.0.1",
    "PLEXUS_METRICS_INTERVAL_SECONDS": "5", "PLEXUS_WORKER_INTERVAL_SECONDS": "1",
})
if "libvirt" not in sys.modules:
    stub = types.ModuleType("libvirt")
    stub.libvirtError = type("libvirtError", (Exception,), {})
    stub.VIR_DOMAIN_RUNNING = 1
    stub.open = lambda uri: (_ for _ in ()).throw(stub.libvirtError("simulated nodes only"))
    sys.modules["libvirt"] = stub

from plexus import worker  # noqa: E402
from plexus.db import Base, SessionLocal, engine  # noqa: E402
from plexus.models import Cluster, ClusterIP, Image, User, utcnow  # noqa: E402
from plexus.security import encrypt_node_key, hash_password  # noqa: E402

hv = worker.hv
NODES: dict[int, dict[str, dict]] = {}  # cluster id -> vm name -> {"state", "cpu_ns", "rx", "tx", "rd", "wr"}
LOCK = threading.Lock()
PASSWORD = os.environ.get("PLEXUS_SIM_PASSWORD", "plexus-admin-2026")
SPEED = float(os.environ.get("PLEXUS_SIM_SPEED", "1.0"))  # >1 = slower, for demos and screenshots


def _node(cluster):
    return NODES.setdefault(cluster.id, {})


async def provision(cluster, spec, password):
    await asyncio.sleep(2 * SPEED)
    with LOCK:
        _node(cluster)[spec["vm_name"]] = {"state": "running", "cpu_ns": 0, "rx": 0, "tx": 0, "rd": 0, "wr": 0}
    return "ssh-ed25519 AAAAPLEXUS"


def power_action(cluster, vm, action):
    with LOCK:
        entry = _node(cluster)[vm]
        entry["state"] = "stopped" if action in {"stop", "force-stop"} else "running"
    return {"start": "running", "stop": "stopping", "force-stop": "stopped", "restart": "restarting"}[action]


def statuses(cluster, machines):
    with LOCK:
        return {m.id: _node(cluster).get(m.vm_name, {}).get("state", "unknown") for m in machines}, True


HOSTS: dict[int, dict] = {}


def collect(cluster, items):
    out = {}
    with LOCK:
        host = HOSTS.setdefault(cluster.id, {"busy": 0, "total": 0})
        host["total"] += int(5e9 * 32)
        host["busy"] += int(5e9 * 32 * random.uniform(0.12, 0.28))
        host_stats = {"cpu_threads": 32, "memory_total_mb": 131072, "memory_used_mb": int(131072 * random.uniform(0.18, 0.24)),
                      "cpu_busy_ns": host["busy"], "cpu_total_ns": host["total"]}
        for machine, previous in items:
            entry = _node(cluster).get(machine.vm_name)
            if not entry or entry["state"] != "running":
                continue
            entry["cpu_ns"] += int(random.uniform(0.05, 0.4) * 5e9 * machine.vcpu)
            for key, rate in (("rx", 200_000), ("tx", 80_000), ("rd", 50_000), ("wr", 120_000)):
                entry[key] += int(rate * random.uniform(0.5, 1.5) * 5)
            now = utcnow()
            cpu = hv_cpu(entry["cpu_ns"], now, previous, machine.vcpu)
            out[machine.id] = {"cpu_percent": cpu, "cpu_time_ns": entry["cpu_ns"], "memory_used_mb": int(machine.memory_mb * random.uniform(0.3, 0.6)),
                               "disk_read_bytes": entry["rd"], "disk_write_bytes": entry["wr"], "network_rx_bytes": entry["rx"],
                               "network_tx_bytes": entry["tx"], "sampled_at": now, "epoch": f"{cluster.id}:{machine.vm_name}"}
    return out, host_stats


def hv_cpu(ns, now, previous, vcpu):
    from plexus.services.metrics import cpu_percent
    return cpu_percent(ns, now, previous, vcpu)


async def preflight(source, target, vm, disk_gb, iso):
    await asyncio.sleep(0.5 * SPEED)
    with LOCK:
        if vm in _node(target):
            raise hv.NotStartedError(f"Transfer did not start, the machine was not changed: {target.name} already has {vm}")
    return {"virtual": disk_gb * 1024 ** 3, "actual": 2 * 1024 ** 3}


async def stop_for_transfer(cluster, vm, grace=120, progress=None):
    with LOCK:
        _node(cluster)[vm]["state"] = "stopped"
    for step in range(1, 4):
        await asyncio.sleep(0.5 * SPEED)
        if progress:
            await progress(step / 3, "Waiting for the guest to shut down")


async def snapshot(source, vm, progress=None):
    for step in range(1, 5):
        await asyncio.sleep(0.5 * SPEED)
        if progress:
            await progress(step / 4, f"{step * 25} % of the read-only snapshot")
    return 6 * 1024 ** 3


async def copy(source, target, vm, size, progress=None):
    total = size / 1024 ** 3
    for step in range(1, 21):
        await asyncio.sleep(0.6 * SPEED)
        if progress:
            await progress(step / 20, f"{total * step / 20:.1f} GiB of {total:.1f} GiB · 212 MiB/s")
    with LOCK:
        _node(target)[vm] = dict(_node(source)[vm], state="stopped")
    return "ab" * 32


async def boot(target, spec):
    await asyncio.sleep(1 * SPEED)
    with LOCK:
        _node(target)[spec["vm_name"]]["state"] = "running"
    return "ssh-ed25519 AAAAPLEXUSNEW"


async def confirm(cluster, vm, ip, timeout=150, progress=None):
    await asyncio.sleep(1 * SPEED)
    return True


async def delete(cluster, vm):
    await asyncio.sleep(0.5 * SPEED)
    with LOCK:
        _node(cluster).pop(vm, None)


async def nothing(*_a, **_k):
    return None


async def verify_node(cluster):
    return {"ssh": True, "libvirt": True, "network": True, "rules": True}, ""


def install_simulator():
    for name, fn in {"provision": provision, "transfer_preflight": preflight, "stop_for_transfer": stop_for_transfer,
                     "snapshot_disk": snapshot, "copy_disk": copy, "boot_transferred": boot, "wait_for_guest_address": confirm,
                     "delete": delete, "discard_copy": delete, "remove_scratch": nothing}.items():
        setattr(hv, name, fn)
    worker.power_action = power_action
    worker._statuses = statuses
    worker._collect_cluster = collect
    worker.push_cluster_rules = nothing

    async def disk_figures(cluster):
        return 500 * 1024 ** 3, 120 * 1024 ** 3
    worker._disk_figures = disk_figures
    from plexus.routes import administrator
    administrator.verify_node = verify_node

    def capacity(cluster):
        return 32, 131072
    import plexus.services.libvirt as libvirt_module
    libvirt_module.node_capacity = capacity


def seed():
    Base.metadata.create_all(engine)
    db = SessionLocal()
    db.add(User(email="admin@plexus.io", username="admin", password_hash=hash_password(PASSWORD), role="admin"))
    db.add(User(email="user@plexus.io", username="user", password_hash=hash_password(PASSWORD), role="user"))
    db.add(Image(name="Ubuntu 24.04", url="https://cloud-images.ubuntu.com/noble/current/noble-server-cloudimg-amd64.img", checksum="0" * 64, kind="cloud", os_family="linux"))
    for n, (name, block) in enumerate((("node-01", "203.0.113"), ("node-02", "198.51.100")), start=1):
        cluster = Cluster(name=name, node_ipv4=f"10.0.{n}.1", ssh_port=22, guest_subnet="192.168.122.0/24", uplink_interface="eth0",
                          ssh_key_encrypted=encrypt_node_key("simulated"), node_host_key=f"10.0.{n}.1 ssh-ed25519 AAAA", state="active",
                          cpu_capacity=32, memory_capacity_mb=131072)
        db.add(cluster); db.flush()
        for i in range(8):
            db.add(ClusterIP(cluster_id=cluster.id, private_ipv4=f"10.0.{n}.{20 + i}", public_ipv4=f"{block}.{20 + i}", guest_ipv4=f"192.168.122.{101 + i}"))
    db.commit(); db.close()


def main():
    parser = argparse.ArgumentParser(description="Plexus with simulated nodes")
    parser.add_argument("--port", type=int, default=8099)
    args = parser.parse_args()
    seed()
    install_simulator()
    import uvicorn
    from plexus.main import app

    threading.Thread(target=lambda: asyncio.run(worker.worker_loop()), daemon=True, name="clusters").start()
    print(f"Plexus (simulated nodes) on http://127.0.0.1:{args.port}  (admin@plexus.io / {PASSWORD}, database {_tmp})", flush=True)
    uvicorn.run(app, host="127.0.0.1", port=args.port, log_level="warning")


if __name__ == "__main__":
    main()
