#!/usr/bin/env bash
# Plexus Virtualization - run every test against a real installation.
#   sudo bash plexus/test/run_all.sh --url https://panel.example.com --email admin@example.com \
#        [--nodes "root@node-01 root@node-02"] [--insecure] \
#        [--destructive --owner-id N --image-id N --source-cluster-id N --target-cluster-id N]
# Exit status: 0 = everything passed.
set -uo pipefail
TESTS="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RELEASE="$(cd "$TESTS/.." && pwd)"
NODES=""; E2E_ARGS=()
while [[ $# -gt 0 ]]; do
  case "$1" in
    --nodes) NODES="$2"; shift 2 ;;
    *) E2E_ARGS+=("$1"); shift ;;
  esac
done
STAMP="$(date +%Y%m%d-%H%M%S)"
FAILED=0
section() { printf '\n==== %s ====\n' "$1"; }

section "1/3  Web panel unit and integration tests"
VENV="$TESTS/.venv"
PY=python3.12; command -v "$PY" >/dev/null || PY=python3
if [[ ! -x "$VENV/bin/pytest" ]]; then
  "$PY" -m venv "$VENV" && "$VENV/bin/pip" install -q --upgrade pip && "$VENV/bin/pip" install -q -e "$RELEASE/web[test]" \
    || { echo "Could not prepare the test environment (needs $PY, venv and libvirt-dev)."; FAILED=1; }
fi
if [[ -x "$VENV/bin/pytest" ]]; then
  (cd "$TESTS" && "$VENV/bin/pytest" -q) || FAILED=1
fi

section "2/3  Node self-test"
if [[ -n "$NODES" ]]; then
  for target in $NODES; do
    echo "-- $target"
    ssh -o BatchMode=yes -o ConnectTimeout=10 "$target" 'sudo bash -s' < "$RELEASE/node/bin/plexus-node-selftest" || FAILED=1
  done
elif [[ -d /var/lib/plexus-node ]]; then
  bash "$RELEASE/node/bin/plexus-node-selftest" || FAILED=1
else
  echo "Skipped: pass --nodes \"root@node-01 root@node-02\" to test nodes over SSH."
fi

section "3/3  End-to-end test of the running panel"
if [[ ${#E2E_ARGS[@]} -gt 0 ]]; then
  python3 "$TESTS/e2e/plexus_e2e.py" --verify-nodes --json "$TESTS/results-$STAMP.json" "${E2E_ARGS[@]}" || FAILED=1
  echo "Results: $TESTS/results-$STAMP.json"
else
  echo "Skipped: pass --url and --email to test the running panel."
fi

section "Summary"
if [[ $FAILED -eq 0 ]]; then echo "ALL CHECKS PASSED"; else echo "SOME CHECKS FAILED (see above)"; fi
exit $FAILED
