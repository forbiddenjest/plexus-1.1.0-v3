"""Branding, privacy display rules, release layout and database migrations."""
import os
import re
import sqlite3
import subprocess
import sys

from plexus.models import Machine
from conftest import NODE_ROOT, PANEL_ROOT, RELEASE_ROOT, login, make_cluster, make_machine, make_user

FOOTER = "Plexus Virtualization • © PlexScale. All Rights Reserved."
TEXT_SUFFIXES = {".py", ".html", ".css", ".js", ".md", ".sh", ".j2", ".toml", ".ini", ".json", ".service", ".path", ".mako", ".example", ".txt", ""}


def test_footer_reads_plexus_virtualization(client, db):
    assert FOOTER in client.get("/auth").text
    login(client, db, make_user(db, "u@example.com"))
    page = client.get("/dashboard").text
    assert FOOTER in page and "Plexus Software" not in page


def test_no_previous_product_names_anywhere_in_the_release():
    banned = re.compile("kes" + "trel|virt" + "plex|\\bla" + "b\\b|_la" + "b\\b|\\bla" + "b[_-]", re.IGNORECASE)
    offenders = []
    for path in RELEASE_ROOT.rglob("*"):
        if not path.is_file() or {"vendor", "__pycache__", ".pytest_cache", ".venv"} & set(path.parts) or path.name.startswith("results-"):
            continue
        if banned.search(str(path.relative_to(RELEASE_ROOT))):
            offenders.append(str(path))
        elif path.suffix in TEXT_SUFFIXES or path.name.startswith("."):
            try:
                if banned.search(path.read_text(encoding="utf-8")):
                    offenders.append(str(path))
            except UnicodeDecodeError:
                pass
    assert offenders == []


def test_user_icon_has_no_ring_or_dot(client, db):
    login(client, db, make_user(db, "u@example.com"))
    page = client.get("/dashboard").text
    assert '<img class="user-icon" src="/static/user_icon.png"' in page and "user-avatar" not in page
    css = (PANEL_ROOT / "plexus" / "static" / "app.css").read_text()
    assert ".user-avatar" not in css
    assert re.search(r"\.user-icon,\.user-chip \.user-icon\{[^}]*border:0;border-radius:0;background:none", css)


def test_dashboard_logo_is_large_but_sign_in_logo_unchanged(client, db):
    auth = client.get("/auth").text
    assert '<img src="/static/logo.png" alt="Plexus" width="72" height="72">' in auth and "brand-lg" not in auth
    login(client, db, make_user(db, "u@example.com"))
    page = client.get("/dashboard").text
    assert 'class="brand-logo" src="/static/logo.png" alt="" width="52" height="52"' in page


def test_favicons_are_served(client):
    for path, magic in (("/static/favicon.ico", b"\x00\x00\x01\x00"), ("/static/favicon.png", b"\x89PNG"), ("/static/apple-touch-icon.png", b"\x89PNG")):
        r = client.get(path)
        assert r.status_code == 200 and r.content.startswith(magic), path
    assert 'rel="icon" href="/static/favicon.ico"' in client.get("/auth").text


def test_admin_pages_show_plain_ips_dashboard_keeps_blur(client, db):
    admin = make_user(db, "a@example.com", "admin")
    cluster = make_cluster(db)
    m = make_machine(db, admin, cluster)
    ip = db.get(Machine, m.id).cluster_ip.public_ipv4
    login(client, db, admin)
    for page in ("/administrator/network", "/administrator/machines", "/administrator/clusters", "/administrator/logs", f"/administrator/machines/{m.id}/edit"):
        assert "ip-blur" not in client.get(page).text, page
    assert f'<td class="mono">{ip}</td>' in client.get("/administrator/network").text
    assert "ip-blur" in client.get("/dashboard").text


def test_release_has_two_clean_roots():
    top = sorted(p.name for p in RELEASE_ROOT.iterdir() if not p.name.startswith("."))
    assert top == ["README.md", "VERSION", "node", "test", "web"]
    assert not (PANEL_ROOT / "tests").exists() and not (RELEASE_ROOT / "docs").exists()
    node_files = sorted(str(p.relative_to(NODE_ROOT)) for p in NODE_ROOT.rglob("*") if p.is_file())
    # A cluster node never needs any web panel file.
    assert not any(f.endswith(".py") for f in node_files)
    assert os.access(NODE_ROOT / "bin" / "plexus-node", os.X_OK) and os.access(NODE_ROOT / "bin" / "plexus-node-selftest", os.X_OK)
    for script in (NODE_ROOT / "bin" / "plexus-node", NODE_ROOT / "bin" / "plexus-node-selftest", PANEL_ROOT / "deploy" / "install.sh"):
        assert subprocess.run(["bash", "-n", str(script)], capture_output=True).returncode == 0, script
    assert (RELEASE_ROOT / "VERSION").read_text().strip() == __import__("plexus").__version__


def test_migrations_reach_the_model_schema(tmp_path):
    db_path = tmp_path / "migrated.db"
    env = {**os.environ, "PLEXUS_DATABASE_URL": f"sqlite:///{db_path}"}
    result = subprocess.run([sys.executable, "-m", "alembic", "-c", "alembic.ini", "upgrade", "head"], cwd=PANEL_ROOT, env=env, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr[-2000:]
    connection = sqlite3.connect(db_path)
    try:
        jobs = {row[1] for row in connection.execute("PRAGMA table_info(jobs)")}
        ips = {row[1] for row in connection.execute("PRAGMA table_info(cluster_ips)")}
        version = connection.execute("SELECT version_num FROM alembic_version").fetchone()[0]
    finally:
        connection.close()
    assert {"progress", "stage", "detail"} <= jobs and "held_for" in ips and version == "0008_transfer_progress"
