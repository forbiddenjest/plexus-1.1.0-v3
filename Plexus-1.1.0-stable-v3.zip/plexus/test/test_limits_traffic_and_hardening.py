"""Limits, traffic, notices, flags, edit pages, isolation and hardening."""
import asyncio
import json
from datetime import datetime, timedelta, timezone
import pytest
from fastapi import HTTPException
from plexus.models import AuditLog, Cluster, ClusterIP, Image, Job, Machine, Notice, Session as LoginSession, TrafficDaily, User
from conftest import NODE_ROOT, PANEL_ROOT, login, make_cluster, make_machine, make_user

GB = 1024 ** 3


def _image(db, name="Ubuntu 24.04", kind="cloud"):
    image = Image(name=name, url="https://cloud-images.example/x.img", checksum="a" * 64, kind=kind, os_family="ubuntu")
    db.add(image); db.commit()
    return image


def _create(client, csrf, owner, cluster, image, **over):
    data = {"csrf_token": csrf, "owner_id": owner.id, "cluster_id": cluster.id, "image_id": image.id, "vcpu": 2, "memory_mb": 2048, "disk_gb": 20,
            "bandwidth_limit_gb": 1000, "speed_in_mbps": 1000, "speed_out_mbps": 480}
    data.update(over)
    return client.post("/administrator/machines", data=data)


# ---------------------------------------------------------------- per-account limits

def test_machine_count_limit_is_enforced(client, db):
    admin = make_user(db, "a@example.com", "admin")
    owner = make_user(db, "u@example.com"); owner.max_vms = 1; db.commit()
    cluster, image = make_cluster(db), _image(db)
    csrf = login(client, db, admin)
    assert _create(client, csrf, owner, cluster, image).status_code == 200
    r = _create(client, csrf, owner, cluster, image)
    assert r.status_code == 422 and "Account limit reached for machines" in r.text
    db.expire_all()
    assert db.query(Machine).filter_by(owner_id=owner.id).count() == 1
    assert db.query(ClusterIP).filter(ClusterIP.machine_id.is_not(None)).count() == 1


def test_memory_limit_boundary_is_exact(client, db):
    admin = make_user(db, "a@example.com", "admin")
    owner = make_user(db, "u@example.com"); owner.max_memory_mb = 4096; db.commit()
    cluster, image = make_cluster(db), _image(db)
    csrf = login(client, db, admin)
    assert _create(client, csrf, owner, cluster, image, memory_mb=2048).status_code == 200
    assert _create(client, csrf, owner, cluster, image, memory_mb=2048).status_code == 200  # exactly at the limit
    r = _create(client, csrf, owner, cluster, image, memory_mb=512)
    assert r.status_code == 422 and "memory" in r.text


def test_vcpu_disk_and_ip_limits(client, db):
    admin = make_user(db, "a@example.com", "admin")
    owner = make_user(db, "u@example.com"); owner.max_vcpu = 2; owner.max_disk_gb = 30; owner.max_ips = 1; db.commit()
    cluster, image = make_cluster(db), _image(db)
    csrf = login(client, db, admin)
    assert _create(client, csrf, owner, cluster, image, vcpu=4).status_code == 422
    assert _create(client, csrf, owner, cluster, image, disk_gb=40).status_code == 422
    assert _create(client, csrf, owner, cluster, image, vcpu=1, disk_gb=10).status_code == 200
    r = _create(client, csrf, owner, cluster, image, vcpu=1, disk_gb=10)
    assert r.status_code == 422 and "IPv4 addresses" in r.text


def test_node_memory_cannot_be_overcommitted(client, db):
    admin = make_user(db, "a@example.com", "admin")
    owner = make_user(db, "u@example.com")
    cluster = make_cluster(db, memory_capacity_mb=4096)  # 1024 MB stays with the host
    image = _image(db)
    csrf = login(client, db, admin)
    r = _create(client, csrf, owner, cluster, image, memory_mb=4096)
    assert r.status_code == 409 and "free memory" in r.text
    assert _create(client, csrf, owner, cluster, image, memory_mb=3072).status_code == 200


def test_bad_number_rerenders_form_instead_of_error_page(client, db):
    admin = make_user(db, "a@example.com", "admin")
    owner, cluster, image = make_user(db, "u@example.com"), make_cluster(db), _image(db)
    csrf = login(client, db, admin)
    r = _create(client, csrf, owner, cluster, image, vcpu="lots")
    assert r.status_code == 422 and "vCPU must be a whole number" in r.text and 'name="vcpu"' in r.text
    r = _create(client, csrf, owner, cluster, image, owner_id="")
    assert r.status_code == 422 and "Select an active owner" in r.text


# ---------------------------------------------------------------- machine edit page

def _edit(client, csrf, machine, **over):
    data = {"csrf_token": csrf, "owner_id": machine.owner_id, "vcpu": machine.vcpu, "memory_mb": machine.memory_mb, "disk_gb": machine.disk_gb,
            "bandwidth_limit_gb": machine.bandwidth_limit_gb, "speed_in_mbps": machine.speed_in_mbps, "speed_out_mbps": machine.speed_out_mbps}
    data.update(over)
    return client.post(f"/administrator/machines/{machine.id}/edit", data=data)


def test_disk_can_only_grow(client, db):
    admin, owner = make_user(db, "a@example.com", "admin"), make_user(db, "u@example.com")
    machine = make_machine(db, owner, make_cluster(db), state="stopped")
    csrf = login(client, db, admin)
    r = _edit(client, csrf, machine, disk_gb=10)
    assert r.status_code == 422 and "only grow" in r.text


def test_hardware_change_needs_machine_stopped(client, db):
    admin, owner = make_user(db, "a@example.com", "admin"), make_user(db, "u@example.com")
    machine = make_machine(db, owner, make_cluster(db), state="running")
    csrf = login(client, db, admin)
    assert _edit(client, csrf, machine, vcpu=4).status_code == 409
    r = _edit(client, csrf, machine, bandwidth_limit_gb=500, speed_out_mbps=100)  # traffic changes are live
    assert r.status_code == 200
    db.expire_all()
    m = db.get(Machine, machine.id)
    assert m.bandwidth_limit_gb == 500 and m.speed_out_mbps == 100
    assert db.query(Job).filter_by(machine_id=m.id, kind="resize").count() == 1


def test_resize_queues_job_with_previous_values(client, db):
    admin, owner = make_user(db, "a@example.com", "admin"), make_user(db, "u@example.com")
    machine = make_machine(db, owner, make_cluster(db), state="stopped")
    csrf = login(client, db, admin)
    assert _edit(client, csrf, machine, vcpu=4, memory_mb=4096, disk_gb=40).status_code == 200
    db.expire_all()
    job = db.query(Job).filter_by(machine_id=machine.id, kind="resize").one()
    payload = json.loads(job.payload)
    assert payload["grow_disk_gb"] == 40 and payload["previous"] == {"vcpu": 2, "memory_mb": 2048, "disk_gb": 20, "speed_in_mbps": 0, "speed_out_mbps": 0}


def test_lowered_limit_does_not_block_unrelated_edits(client, db):
    admin, owner = make_user(db, "a@example.com", "admin"), make_user(db, "u@example.com")
    machine = make_machine(db, owner, make_cluster(db), state="stopped")
    owner.max_vcpu = 1; db.commit()  # now below current usage (2)
    csrf = login(client, db, admin)
    assert _edit(client, csrf, machine, bandwidth_limit_gb=200).status_code == 200
    assert _edit(client, csrf, machine, memory_mb=1024).status_code == 200  # shrinking memory is fine
    db.query(Job).delete(); db.commit()                                      # the resize job would make the next edit wait
    r = _edit(client, csrf, machine, memory_mb=1024, vcpu=3)
    assert r.status_code == 422 and "vCPU" in r.text                        # growth is still checked


def test_owner_change_checks_new_owners_limits(client, db):
    admin, owner = make_user(db, "a@example.com", "admin"), make_user(db, "u@example.com")
    other = make_user(db, "o@example.com"); other.max_vms = 0; other.max_memory_mb = 1024; db.commit()
    machine = make_machine(db, owner, make_cluster(db), state="stopped")
    csrf = login(client, db, admin)
    r = _edit(client, csrf, machine, owner_id=other.id)
    assert r.status_code == 422 and "memory" in r.text
    other.max_memory_mb = 0; db.commit()
    assert _edit(client, csrf, machine, owner_id=other.id).status_code == 200
    db.expire_all()
    assert db.get(Machine, machine.id).owner_id == other.id


def test_machine_edit_blocked_while_job_pending(client, db):
    admin, owner = make_user(db, "a@example.com", "admin"), make_user(db, "u@example.com")
    machine = make_machine(db, owner, make_cluster(db), state="stopped")
    db.add(Job(kind="start", machine_id=machine.id, state="queued")); db.commit()
    csrf = login(client, db, admin)
    assert _edit(client, csrf, machine, bandwidth_limit_gb=5).status_code == 409


# ---------------------------------------------------------------- bandwidth accounting

def test_traffic_delta_daily_rows_and_epoch(db):
    from plexus.services.traffic import record_traffic
    owner = make_user(db, "u@example.com")
    m = make_machine(db, owner, make_cluster(db))
    now = datetime(2026, 11, 6, 12, tzinfo=timezone.utc)
    record_traffic(db, m, 1000, 500, now=now, epoch="1:7")
    record_traffic(db, m, 1500, 900, now=now, epoch="1:7")
    assert (m.traffic_rx_bytes, m.traffic_tx_bytes) == (1500, 900)
    # QEMU restarted (new domain id): its counters started again from zero.
    record_traffic(db, m, 200, 100, now=now, epoch="1:8")
    assert (m.traffic_rx_bytes, m.traffic_tx_bytes) == (1700, 1000)
    # Same process, counter went backwards (device recreated): count what it shows.
    record_traffic(db, m, 50, 10, now=now, epoch="1:8")
    assert (m.traffic_rx_bytes, m.traffic_tx_bytes) == (1750, 1010)
    db.commit()
    row = db.query(TrafficDaily).filter_by(machine_id=m.id, day="2026-11-06").one()
    assert (row.rx_bytes, row.tx_bytes) == (1750, 1010)


def test_reaching_cap_suspends_and_powers_off(db):
    from plexus.services.traffic import record_traffic
    owner = make_user(db, "u@example.com")
    m = make_machine(db, owner, make_cluster(db)); m.bandwidth_limit_gb = 1; db.commit()
    assert record_traffic(db, m, GB // 2, 0, epoch="1:1") is False
    assert m.state == "running"
    assert record_traffic(db, m, GB // 2, GB // 2, epoch="1:1") is True
    assert m.state == "suspended" and m.suspend_reason == "bandwidth"
    db.commit()
    assert db.query(Job).filter_by(machine_id=m.id, kind="force-stop").count() == 1
    assert db.query(AuditLog).filter_by(action="machine.bandwidth_suspend").count() == 1


def test_cap_never_interrupts_a_transfer(db):
    from plexus.services.traffic import enforce_cap
    m = make_machine(db, make_user(db, "u@example.com"), make_cluster(db), state="transferring")
    m.bandwidth_limit_gb = 1; m.traffic_rx_bytes = 2 * GB
    assert enforce_cap(db, m) is False and m.state == "transferring"


def test_admin_refresh_bandwidth_lifts_suspension(client, db):
    admin = make_user(db, "a@example.com", "admin")
    m = make_machine(db, make_user(db, "u@example.com"), make_cluster(db), state="suspended")
    m.suspend_reason = "bandwidth"; m.bandwidth_limit_gb = 1; m.traffic_rx_bytes = 2 * GB; m.traffic_last_rx = 5; db.commit()
    csrf = login(client, db, admin)
    r = client.post(f"/administrator/machines/{m.id}/traffic/reset", data={"csrf_token": csrf})
    assert r.status_code == 200 and "reset" in r.text
    db.expire_all()
    m = db.get(Machine, m.id)
    assert m.traffic_used_bytes() == 0 and m.state == "stopped" and m.suspend_reason == ""
    assert m.traffic_last_rx == 5  # raw counter kept: the next sample adds only new bytes


def test_month_rollover_resets_usage_and_restores(db):
    from plexus.services.traffic import rollover
    m = make_machine(db, make_user(db, "u@example.com"), make_cluster(db), state="suspended")
    m.suspend_reason = "bandwidth"; m.traffic_period = "2026-10"; m.traffic_rx_bytes = 9 * GB; db.commit()
    rollover(db, now=datetime(2026, 11, 1, 0, 5, tzinfo=timezone.utc)); db.commit()
    assert m.traffic_period == "2026-11" and m.traffic_used_bytes() == 0 and m.state == "stopped"


def test_bandwidth_graph_has_30_days(client, db):
    owner = make_user(db, "u@example.com")
    m = make_machine(db, owner, make_cluster(db))
    login(client, db, owner)
    body = client.get(f"/machines/{m.id}?tab=metrics").text
    assert body.count('class="bar-in"') == 30 and body.count('class="bar-out"') == 30


def test_speed_caps_in_domain_xml():
    from plexus.services.libvirt import domain_xml
    xml = domain_xml({"vm_name": "vm100001", "guest_ip": "192.168.122.101", "memory_mb": 1024, "vcpu": 1, "speed_in_mbps": 1000, "speed_out_mbps": 480})
    assert "<inbound average='125000' peak='125000'" in xml
    assert "<outbound average='60000' peak='60000'" in xml
    assert "<port isolated='yes'/>" in xml and "clean-traffic" in xml and "<on_crash>destroy</on_crash>" in xml
    unlimited = domain_xml({"vm_name": "vm100001", "guest_ip": "192.168.122.101", "memory_mb": 1024, "vcpu": 1})
    assert "<bandwidth>" not in unlimited


def test_human_speed_labels():
    from plexus.services.traffic import human_speed
    assert human_speed(480) == "480 Mbps" and human_speed(1000) == "1 Gbps" and human_speed(0) == "Unlimited"


# ---------------------------------------------------------------- notices (Others section)

def test_notice_shown_on_every_page_and_escaped(client, db):
    admin, user = make_user(db, "a@example.com", "admin"), make_user(db, "u@example.com")
    csrf = login(client, db, admin)
    r = client.post("/administrator/notices", data={"csrf_token": csrf, "kind": "maintenance", "title": "<script>alert(1)</script>", "message": "Node nyc-01 reboots at 02:00"}, follow_redirects=False)
    assert r.status_code == 303
    client.cookies.clear(); login(client, db, user)
    for path in ["/dashboard", "/account"]:
        body = client.get(path).text
        assert 'class="notice notice-maintenance"' in body and "Node nyc-01 reboots at 02:00" in body
        assert "<script>alert(1)</script>" not in body and "&lt;script&gt;" in body


@pytest.mark.parametrize("kind", ["info", "update", "maintenance", "warning", "alert", "success"])
def test_every_notice_type_has_label_icon_and_style(kind):
    import re
    from plexus.services.panel_settings import NOTICE_KINDS
    label, icon = NOTICE_KINDS[kind]
    assert label and icon
    css = open(PANEL_ROOT / "plexus" / "static" / "app.css").read()
    assert re.search(rf"\.notice-{kind}\{{", css)


def test_notice_toggle_delete_and_validation(client, db):
    csrf = login(client, db, make_user(db, "a@example.com", "admin"))
    assert client.post("/administrator/notices", data={"csrf_token": csrf, "kind": "nope", "title": "x"}).status_code == 422
    assert client.post("/administrator/notices", data={"csrf_token": csrf, "kind": "info", "title": ""}).status_code == 422
    client.post("/administrator/notices", data={"csrf_token": csrf, "kind": "info", "title": "Hello"})
    notice = db.query(Notice).one()
    client.post(f"/administrator/notices/{notice.id}/toggle", data={"csrf_token": csrf})
    db.expire_all()
    assert db.get(Notice, notice.id).active is False
    assert 'class="notice notice-info"' not in client.get("/dashboard").text.split('<div class="content">')[0]
    client.post(f"/administrator/notices/{notice.id}/delete", data={"csrf_token": csrf})
    db.expire_all()
    assert db.query(Notice).count() == 0


def test_user_cannot_publish_notice(client, db):
    csrf = login(client, db, make_user(db, "u@example.com"))
    assert client.post("/administrator/notices", data={"csrf_token": csrf, "kind": "info", "title": "x"}).status_code == 403


def test_discord_setting_lives_in_others(client, db):
    login(client, db, make_user(db, "a@example.com", "admin"))
    assert 'name="support_url"' in client.get("/administrator/others").text
    assert 'name="support_url"' not in client.get("/administrator/overview").text


# ---------------------------------------------------------------- flags and locations

def test_flag_from_country_code():
    from plexus.services.panel_settings import country_code, flag_url, validate_location
    assert flag_url("IN") == "https://flagcdn.com/w320/in.png"
    assert flag_url("uk") == "https://flagcdn.com/w320/gb.png"
    assert flag_url("") == "" and flag_url("XX") == "" and country_code("javascript") == ""
    assert validate_location("Mumbai, Pune", "in") == ("Mumbai, Pune", "IN")
    for bad in ["IND", "X1", "ZZ"]:
        with pytest.raises(HTTPException):
            validate_location("Somewhere", bad)


def test_cluster_edit_updates_location(client, db):
    cluster = make_cluster(db)
    csrf = login(client, db, make_user(db, "a@example.com", "admin"))
    r = client.post(f"/administrator/clusters/{cluster.id}/edit", data={"csrf_token": csrf, "name": "mum-01", "ssh_port": 22, "location": "Mumbai, Pune", "location_id": "in", "disk_capacity_gb": 500})
    assert r.status_code == 200
    db.expire_all()
    c = db.get(Cluster, cluster.id)
    assert (c.name, c.location, c.location_id, c.disk_capacity_gb, c.state) == ("mum-01", "Mumbai, Pune", "IN", 500, "active")
    r = client.post(f"/administrator/clusters/{cluster.id}/edit", data={"csrf_token": csrf, "name": "mum-01", "ssh_port": 2222, "location_id": "IN"})
    db.expire_all()
    assert db.get(Cluster, cluster.id).state == "pending"  # new port must be verified again


def test_no_manual_flag_url_field_anywhere(client, db):
    cluster = make_cluster(db)
    login(client, db, make_user(db, "a@example.com", "admin"))
    for path in ["/administrator/clusters/new", f"/administrator/clusters/{cluster.id}/edit"]:
        body = client.get(path).text
        assert 'name="flag_url"' not in body and 'name="location_id"' in body and 'name="location"' in body


def test_guest_subnet_must_be_private_and_separate():
    from plexus.services.clusters import validate_cluster
    validate_cluster("203.0.113.10", 22, "192.168.122.0/24", "eth0")
    for subnet in ["8.8.8.0/24", "203.0.113.0/24", "10.0.0.0/8"]:
        with pytest.raises(ValueError):
            validate_cluster("203.0.113.10", 22, subnet, "eth0")
    with pytest.raises(ValueError):
        validate_cluster("10.0.0.4", 22, "10.0.0.0/24", "eth0")


# ---------------------------------------------------------------- accounts

def _edit_account(client, csrf, target, **over):
    data = {"csrf_token": csrf, "email": target.email, "username": target.username or "", "role": target.role, "active": "on" if target.active else "",
            "max_vms": 0, "max_vcpu": 0, "max_memory_mb": 0, "max_disk_gb": 0, "max_ips": 0}
    data.update(over)
    return client.post(f"/administrator/accounts/{target.id}/edit", data=data)


def test_account_edit_all_fields_and_username_sign_in(client, db):
    admin, target = make_user(db, "a@example.com", "admin"), make_user(db, "u@example.com")
    csrf = login(client, db, admin)
    r = _edit_account(client, csrf, target, email="New@Example.com", username="jdoe", role="admin", new_password="a-brand-new-password", force_change="", max_vms=3, max_memory_mb=8192)
    assert r.status_code == 200 and "signed out" in r.text
    db.expire_all()
    t = db.get(User, target.id)
    assert (t.email, t.username, t.role, t.max_vms, t.max_memory_mb, t.force_password_change) == ("new@example.com", "jdoe", "admin", 3, 8192, False)
    client.cookies.clear()
    page = client.get("/auth")
    r = client.post("/auth", data={"email": "JDOE", "password": "a-brand-new-password", "csrf_token": page.cookies.get("plexus_csrf")}, follow_redirects=False)
    assert r.status_code == 303 and r.headers["location"] == "/dashboard"


def test_password_reset_signs_target_out(client, db):
    from plexus.security import new_session
    admin, target = make_user(db, "a@example.com", "admin"), make_user(db, "u@example.com")
    new_session(db, target); db.commit()
    csrf = login(client, db, admin)
    _edit_account(client, csrf, target, new_password="another-good-password", force_change="on")
    db.expire_all()
    assert db.query(LoginSession).filter_by(user_id=target.id).count() == 0
    assert db.get(User, target.id).force_password_change is True


def test_last_active_admin_is_protected(client, db):
    admin = make_user(db, "a@example.com", "admin")
    csrf = login(client, db, admin)
    assert _edit_account(client, csrf, admin, role="user").status_code == 422
    assert _edit_account(client, csrf, admin, active="").status_code == 422
    db.expire_all()
    assert db.get(User, admin.id).role == "admin" and db.get(User, admin.id).active


def test_other_admin_can_be_demoted_when_another_remains(client, db):
    admin, second = make_user(db, "a@example.com", "admin"), make_user(db, "b@example.com", "admin")
    csrf = login(client, db, admin)
    assert _edit_account(client, csrf, second, role="user").status_code == 200


def test_duplicate_email_and_username_rejected(client, db):
    admin, target = make_user(db, "a@example.com", "admin"), make_user(db, "u@example.com")
    other = make_user(db, "o@example.com"); other.username = "taken"; db.commit()
    csrf = login(client, db, admin)
    assert _edit_account(client, csrf, target, email="o@example.com").status_code == 409
    assert _edit_account(client, csrf, target, username="taken").status_code == 409
    assert _edit_account(client, csrf, target, username="Bad Name!").status_code == 422


def test_delete_account_rules(client, db):
    admin, owner, empty = make_user(db, "a@example.com", "admin"), make_user(db, "u@example.com"), make_user(db, "e@example.com")
    empty_id, admin_id, admin_email = empty.id, admin.id, admin.email
    make_machine(db, owner, make_cluster(db))
    csrf = login(client, db, admin)
    assert client.post(f"/administrator/accounts/{owner.id}/delete", data={"csrf_token": csrf, "confirm_email": owner.email}).status_code == 409
    assert client.post(f"/administrator/accounts/{empty.id}/delete", data={"csrf_token": csrf, "confirm_email": "wrong@example.com"}).status_code == 422
    assert client.post(f"/administrator/accounts/{empty.id}/delete", data={"csrf_token": csrf, "confirm_email": empty.email}, follow_redirects=False).status_code == 303
    assert client.post(f"/administrator/accounts/{admin_id}/delete", data={"csrf_token": csrf, "confirm_email": admin_email}).status_code == 404
    db.expire_all()
    assert db.get(User, empty_id) is None


# ---------------------------------------------------------------- suspension

def test_suspended_machine_cannot_be_started_by_owner(client, db):
    owner = make_user(db, "u@example.com")
    m = make_machine(db, owner, make_cluster(db), state="suspended")
    csrf = login(client, db, owner)
    assert client.post(f"/machines/{m.id}/actions", data={"csrf_token": csrf, "action": "start"}).status_code == 409


def test_admin_suspend_and_unsuspend(client, db):
    admin = make_user(db, "a@example.com", "admin")
    m = make_machine(db, make_user(db, "u@example.com"), make_cluster(db))
    csrf = login(client, db, admin)
    client.post(f"/administrator/machines/{m.id}/suspend", data={"csrf_token": csrf})
    db.expire_all()
    assert db.get(Machine, m.id).state == "suspended" and db.get(Machine, m.id).suspend_reason == "admin"
    assert db.query(Job).filter_by(machine_id=m.id, kind="force-stop").count() == 1
    db.query(Job).delete(); db.commit()
    client.post(f"/administrator/machines/{m.id}/suspend", data={"csrf_token": csrf})
    db.expire_all()
    assert db.get(Machine, m.id).state == "stopped"


def test_suspend_refused_while_transfer_queued(client, db):
    admin = make_user(db, "a@example.com", "admin")
    m = make_machine(db, make_user(db, "u@example.com"), make_cluster(db))
    db.add(Job(kind="transfer", machine_id=m.id, state="queued", payload="{}")); db.commit()
    csrf = login(client, db, admin)
    assert client.post(f"/administrator/machines/{m.id}/suspend", data={"csrf_token": csrf}).status_code == 409


def test_worker_never_boots_a_suspended_machine(db, monkeypatch):
    from plexus import worker
    m = make_machine(db, make_user(db, "u@example.com"), make_cluster(db), state="suspended")
    job = Job(kind="start", machine_id=m.id, state="running"); db.add(job); db.commit()
    called = []
    monkeypatch.setattr(worker, "power_action", lambda *a: called.append(a) or "running")
    asyncio.run(worker._run_job(job.id))
    db.expire_all()
    assert called == [] and db.get(Machine, m.id).state == "suspended"
    assert db.get(Job, job.id).state == "complete" and "suspended" in db.get(Job, job.id).result


# ---------------------------------------------------------------- worker robustness

def test_delete_is_recorded_even_if_rule_push_fails(db, monkeypatch):
    from plexus import worker
    m = make_machine(db, make_user(db, "u@example.com"), make_cluster(db), state="deleting")
    machine_id = m.id
    job = Job(kind="delete", machine_id=m.id, state="running"); db.add(job); db.commit()
    async def delete(c, vm): return None
    async def push(cluster_id): raise RuntimeError("node offline")
    monkeypatch.setattr(worker.hv, "delete", delete)
    monkeypatch.setattr(worker, "push_cluster_rules", push)
    asyncio.run(worker._run_job(job.id))
    db.expire_all()
    assert db.get(Machine, machine_id) is None
    assert db.query(ClusterIP).filter(ClusterIP.machine_id.is_not(None)).count() == 0
    assert db.query(Job).filter_by(kind="push-rules", state="queued").count() == 1


def test_crash_is_logged_and_shown_as_stopped(db, monkeypatch):
    from plexus import worker
    m = make_machine(db, make_user(db, "u@example.com"), make_cluster(db), state="running")
    monkeypatch.setattr(worker, "_statuses", lambda cluster, machines: ({mm.id: "crashed" for mm in machines}, True))
    asyncio.run(worker._reconcile())
    db.expire_all()
    assert db.get(Machine, m.id).state == "stopped"
    assert db.query(AuditLog).filter_by(action="machine.crashed", target=m.id).count() == 1


def test_interrupted_jobs_are_requeued_on_start(db):
    from plexus.worker import recover_interrupted
    db.add(Job(kind="push-rules", state="running", payload="{}")); db.commit()
    recover_interrupted(db); db.commit()
    assert db.query(Job).filter_by(state="queued").count() == 1


def test_housekeeping_purges_expired_sessions(db):
    from plexus.models import LoginAttempt
    from plexus.security import new_session
    from plexus.worker import housekeeping
    user = make_user(db, "u@example.com")
    _raw, _csrf, row = new_session(db, user); row.expires_at = datetime.now(timezone.utc) - timedelta(hours=1)
    db.add(LoginAttempt(account_key="a", ip_key="b", attempted_at=datetime.now(timezone.utc) - timedelta(days=5)))
    db.commit()
    housekeeping(db); db.commit()
    assert db.query(LoginSession).count() == 0 and db.query(LoginAttempt).count() == 0


# ---------------------------------------------------------------- guest isolation rules

def test_isolation_rules_block_azure_internals_and_ipv6():
    from plexus.services.network import render_nat_rules
    rules = render_nat_rules([("10.0.0.11", "198.51.100.11", "192.168.122.101")], "192.168.122.0/24", "eth0", {"192.168.122.101": [("tcp", 22)]})
    for cidr in ["169.254.0.0/16", "168.63.129.16/32", "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"]:
        assert cidr in rules
    assert "chain input { type filter hook input" in rules and "iifname kbr0 drop" in rules          # guests cannot reach the node
    assert "iifname kbr0 ip daddr @blocked drop" in rules                                          # IMDS / WireServer / VNet
    assert "iifname kbr0 ip saddr != 192.168.122.0/24 drop" in rules                               # anti-spoofing
    assert "ip saddr 192.168.122.0/24 ip daddr 192.168.122.0/24 drop" in rules                     # guest-to-guest
    assert "table ip6 plexus6" in rules and "oifname kbr0 drop" in rules                          # no IPv6
    assert "tcp dport 22 accept" in rules


def test_rules_reject_injection():
    from plexus.services.network import render_nat_rules
    with pytest.raises(ValueError):
        render_nat_rules([], "192.168.122.0/24", "eth0; flush ruleset")
    with pytest.raises(ValueError):
        render_nat_rules([("10.0.0.11", "x", "8.8.8.8")], "192.168.122.0/24", "eth0")


def test_node_setup_disables_ipv6_on_guest_bridge(db):
    import re
    text = open(NODE_ROOT / "setup.sh.j2").read()
    assert "disable_ipv6" in text and "accept_ra" in text
    assert re.search(r"rp_filter", text)


# ---------------------------------------------------------------- logos, icon and footer

def test_os_logos_and_user_icon_are_bundled_png(client):
    for path in ["/static/os/ubuntu.png", "/static/os/debian.png", "/static/os/almalinux.png", "/static/user_icon.png"]:
        r = client.get(path)
        assert r.status_code == 200 and r.content[:8] == b"\x89PNG\r\n\x1a\n"


def test_os_logo_on_dashboard_and_image_list(client, db):
    admin = make_user(db, "a@example.com", "admin")
    _image(db)
    make_machine(db, admin, make_cluster(db))
    login(client, db, admin)
    assert 'src="/static/os/ubuntu.png"' in client.get("/dashboard").text
    assert 'src="/static/os/ubuntu.png"' in client.get("/administrator/images").text


def test_os_detection():
    from plexus.services.images import detect_os
    assert detect_os("Ubuntu 24.04") == "ubuntu" and detect_os("Debian 12") == "debian"
    assert detect_os("AlmaLinux 9") == "almalinux" and detect_os("Alma 9") == "almalinux" and detect_os("Rocky") == "other"


def test_user_chip_shows_icon_and_name(client, db):
    user = make_user(db, "u@example.com"); user.username = "jdoe"; db.commit()
    login(client, db, user)
    body = client.get("/dashboard").text
    assert 'class="user-icon" src="/static/user_icon.png"' in body and "<strong>jdoe</strong>" in body and "u@example.com" in body


def test_footer_on_every_kind_of_page(client, db):
    assert "Plexus Virtualization • © PlexScale. All Rights Reserved." in client.get("/auth").text
    assert "Plexus Virtualization • © PlexScale. All Rights Reserved." in client.get("/does-not-exist").text
    user = make_user(db, "u@example.com")
    m = make_machine(db, user, make_cluster(db))
    login(client, db, user)
    for path in ["/dashboard", "/account"] + [f"/machines/{m.id}?tab={t}" for t in ["overview", "metrics", "console", "network", "media", "settings"]]:
        assert 'Plexus Virtualization • © PlexScale. All Rights Reserved.</footer>' in client.get(path).text, path


# ---------------------------------------------------------------- hardening

def test_security_headers(client):
    r = client.get("/auth")
    csp = r.headers["content-security-policy"]
    assert "script-src 'self'" in csp and "unsafe" not in csp and "frame-ancestors 'none'" in csp and "img-src 'self' data: https://flagcdn.com" in csp
    assert r.headers["x-frame-options"] == "DENY" and r.headers["x-content-type-options"] == "nosniff"
    assert r.headers["cache-control"] == "no-store"


def test_oversized_body_rejected(client):
    r = client.post("/auth", content=b"x" * (2 * 1024 * 1024), headers={"content-type": "application/x-www-form-urlencoded"})
    assert r.status_code == 413


def test_healthz(client):
    r = client.get("/healthz")
    assert r.status_code == 200 and r.text == "ok"


def test_unknown_account_and_wrong_password_look_the_same(client, db):
    make_user(db, "u@example.com")
    def attempt(email):
        page = client.get("/auth")
        return client.post("/auth", data={"email": email, "password": "wrong-password-123", "csrf_token": page.cookies.get("plexus_csrf")})
    a, b = attempt("u@example.com"), attempt("nobody@example.com")
    assert a.status_code == b.status_code == 401
    assert "Sign-in failed" in a.text and "Sign-in failed" in b.text


def test_suspended_account_cannot_sign_in(client, db):
    user = make_user(db, "u@example.com"); user.active = False; db.commit()
    page = client.get("/auth")
    r = client.post("/auth", data={"email": "u@example.com", "password": "correct-horse-battery", "csrf_token": page.cookies.get("plexus_csrf")}, follow_redirects=False)
    assert r.status_code == 401


def test_login_without_csrf_fails(client, db):
    make_user(db, "u@example.com")
    client.get("/auth")
    r = client.post("/auth", data={"email": "u@example.com", "password": "correct-horse-battery", "csrf_token": "forged"}, follow_redirects=False)
    assert r.status_code == 401


def test_cross_origin_post_rejected(client, db):
    csrf = login(client, db, make_user(db, "a@example.com", "admin"))
    r = client.post("/administrator/settings", data={"csrf_token": csrf, "support_url": ""}, headers={"origin": "https://evil.example"})
    assert r.status_code == 403


def test_user_cannot_touch_someone_elses_machine(client, db):
    owner = make_user(db, "o@example.com")
    m = make_machine(db, owner, make_cluster(db))
    csrf = login(client, db, make_user(db, "u@example.com"))
    for path, data in [(f"/machines/{m.id}/actions", {"action": "stop"}), (f"/machines/{m.id}/password", {"password": "x" * 16}),
                       (f"/machines/{m.id}/firewall", {"protocol": "tcp", "port": 22}), (f"/machines/{m.id}/metrics/live", None)]:
        r = client.post(path, data={"csrf_token": csrf, **data}) if data is not None else client.get(path)
        assert r.status_code == 404, path
    assert db.query(Job).count() == 0


def test_user_cannot_reach_admin_machine_routes(client, db):
    owner = make_user(db, "u@example.com")
    m = make_machine(db, owner, make_cluster(db))
    csrf = login(client, db, owner)
    for path in [f"/administrator/machines/{m.id}/edit", f"/administrator/machines/{m.id}/suspend", f"/administrator/machines/{m.id}/traffic/reset", f"/administrator/machines/{m.id}/transfer"]:
        assert client.post(path, data={"csrf_token": csrf}).status_code == 403, path


def test_remove_only_free_ips(client, db):
    admin = make_user(db, "a@example.com", "admin")
    cluster = make_cluster(db, ips=2)
    m = make_machine(db, make_user(db, "u@example.com"), cluster)
    csrf = login(client, db, admin)
    assert client.post(f"/administrator/network/ips/{m.cluster_ip.id}/delete", data={"csrf_token": csrf}).status_code == 409
    free = db.query(ClusterIP).filter(ClusterIP.machine_id.is_(None)).one()
    assert client.post(f"/administrator/network/ips/{free.id}/delete", data={"csrf_token": csrf}, follow_redirects=False).status_code == 303
    db.expire_all()
    assert db.query(ClusterIP).count() == 1


def test_console_watchdog_revokes_on_suspend(db):
    from plexus.routes.sockets import console_allowed
    from plexus.security import digest_token, new_session
    owner = make_user(db, "u@example.com")
    m = make_machine(db, owner, make_cluster(db))
    raw, _csrf, _row = new_session(db, owner); db.commit()
    assert console_allowed(digest_token(raw), m.id) is True
    owner.active = False; db.commit()
    assert console_allowed(digest_token(raw), m.id) is False


def test_production_refuses_placeholder_secrets():
    from plexus.config import Settings, production_problems
    bad = Settings(environment="production", secret_key="replace-with-a-long-random-value", encryption_key="nope", secure_cookies=False, trusted_host="vps.mydomain.xyz")
    assert len(production_problems(bad)) == 4
    good = Settings(environment="production", secret_key="s" * 48, encryption_key="Ufz3m0t2b8iZbJk1lW3c0bT6jQwq9r0D7kJmE4yH5aE=", secure_cookies=True, trusted_host="panel.example.net")
    assert production_problems(good) == []


def test_migrations_match_models(tmp_path):
    import os, subprocess, sys
    env = dict(os.environ, PLEXUS_DATABASE_URL=f"sqlite:///{tmp_path}/m.db")
    up = subprocess.run([sys.executable, "-m", "alembic", "-c", "alembic.ini", "upgrade", "head"], env=env, capture_output=True, text=True)
    assert up.returncode == 0, up.stderr
    check = subprocess.run([sys.executable, "-m", "alembic", "-c", "alembic.ini", "check"], env=env, capture_output=True, text=True)
    assert check.returncode == 0, check.stdout + check.stderr


def test_setup_script_renders_valid_shell(db, tmp_path):
    import subprocess
    import asyncssh
    from plexus.security import encrypt_node_key
    from plexus.services.clusters import render_setup_script
    key = asyncssh.generate_private_key("ssh-ed25519").export_private_key().decode()
    cluster = make_cluster(db)
    cluster.ssh_key_encrypted = encrypt_node_key(key); db.commit()
    _image(db, "Debian 12")
    script = render_setup_script(db, cluster)
    path = tmp_path / "setup.sh"; path.write_text(script)
    assert subprocess.run(["bash", "-n", str(path)], capture_output=True).returncode == 0
    assert "table ip plexus" in script and "disable_ipv6=1" in script and "fetch 1 cloud" in script


def test_setup_script_refuses_unquoted_values():
    from plexus.services.clusters import _finalize, heredoc, Shell
    assert _finalize("192.168.122.1") == "192.168.122.1" and _finalize(24) == 24 and _finalize(Shell("'a b'")) == "'a b'"
    for bad in ["$(reboot)", "a b", "x;y", "`id`"]:
        with pytest.raises(ValueError):
            _finalize(bad)
    with pytest.raises(ValueError):
        heredoc("ok\nRULES\nrm -rf /", "RULES")


def test_node_files_live_in_the_separate_node_directory():
    from plexus.services.clusters import NODE_FILES, node_dir
    assert node_dir().resolve() == NODE_ROOT.resolve()
    assert (NODE_ROOT / "setup.sh.j2").is_file()
    for relative, _terminator in NODE_FILES.values():
        assert (NODE_ROOT / relative).is_file(), relative
    # Nothing node-side ships inside the web panel package any more.
    assert not (PANEL_ROOT / "plexus" / "node").exists()


def test_rendered_setup_embeds_every_node_file(db, tmp_path):
    import asyncssh, subprocess
    from plexus.security import encrypt_node_key
    from plexus.services.clusters import render_setup_script
    cluster = make_cluster(db)
    cluster.ssh_key_encrypted = encrypt_node_key(asyncssh.generate_private_key("ssh-ed25519").export_private_key().decode()); db.commit()
    script = render_setup_script(db, cluster)
    for relative in ("bin/plexus-node", "bin/plexus-node-selftest", "systemd/plexus-node.service", "systemd/plexus-rules.path", "systemd/plexus-node-refresh.service"):
        assert (NODE_ROOT / relative).read_text() in script, relative
    path = tmp_path / "setup.sh"; path.write_text(script)
    assert subprocess.run(["bash", "-n", str(path)], capture_output=True).returncode == 0


# ---------------------------------------------------------------- setup CLI and machine deletion placement

def test_create_admin_cli_validates_and_accepts_username(db, monkeypatch):
    from plexus import setup
    answers = iter(["a-long-enough-password", "a-long-enough-password"])
    monkeypatch.setattr(setup.getpass, "getpass", lambda prompt="": next(answers))
    setup.create_admin("Root@Example.com", "root")
    db.expire_all()
    admin = db.query(User).filter_by(email="root@example.com").one()
    assert admin.role == "admin" and admin.username == "root"
    with pytest.raises(SystemExit, match="valid email"):
        setup.create_admin("not-an-email")
    with pytest.raises(SystemExit, match="already exists"):
        setup.create_admin("root@example.com")
    with pytest.raises(SystemExit, match="Username"):
        setup.create_admin("other@example.com", "x")


def test_create_admin_cli_rejects_short_or_mismatched_password(monkeypatch):
    from plexus import setup
    for first, second in [("short", "short"), ("a-long-enough-password", "a-different-password!")]:
        answers = iter([first, second])
        monkeypatch.setattr(setup.getpass, "getpass", lambda prompt="", a=answers: next(a))
        with pytest.raises(SystemExit, match="12"):
            setup.create_admin("new@example.com")


def test_machine_delete_lives_on_manage_page_and_needs_exact_name(client, db):
    admin = make_user(db, "a@example.com", "admin")
    owner = make_user(db, "u@example.com")
    machine = make_machine(db, owner, make_cluster(db), state="stopped")
    csrf = login(client, db, admin)
    assert f"/administrator/machines/{machine.id}/delete" not in client.get("/administrator/machines").text
    assert f"/administrator/machines/{machine.id}/delete" in client.get(f"/administrator/machines/{machine.id}/edit").text
    r = client.post(f"/administrator/machines/{machine.id}/delete", data={"csrf_token": csrf, "confirm_name": "vm999999"})
    assert r.status_code == 422
    r = client.post(f"/administrator/machines/{machine.id}/delete", data={"csrf_token": csrf, "confirm_name": machine.vm_name}, follow_redirects=False)
    assert r.status_code == 303
    db.expire_all()
    assert db.get(Machine, machine.id).state == "deleting"
    assert db.query(Job).filter_by(machine_id=machine.id, kind="delete").count() == 1


def test_activity_log_names_the_actor(client, db):
    admin = make_user(db, "a@example.com", "admin"); admin.username = "boss"; db.commit()
    db.add(AuditLog(actor_id=admin.id, action="machine.create", target="vm-xyz12"))
    db.add(AuditLog(actor_id=None, action="machine.crashed", target="vm-xyz12", result="failed"))
    db.commit()
    login(client, db, admin)
    for page in ("/administrator/logs", "/administrator/overview"):
        text = client.get(page).text
        assert "<td>boss</td>" in text and "<td>System</td>" in text
