"""Fast, accurate and private live states and metrics."""
import asyncio
from datetime import timedelta
from types import SimpleNamespace

from plexus.models import Job, Machine, MetricSample, Setting, utcnow
from conftest import login, make_cluster, make_machine, make_user


# ---------------------------------------------------------------- live state endpoints

def test_dashboard_live_respects_visibility(client, db):
    alice, bob = make_user(db, "alice@example.com"), make_user(db, "bob@example.com")
    cluster = make_cluster(db, ips=3)
    a = make_machine(db, alice, cluster, mid="vm-alice", vm="vm100001")
    b = make_machine(db, bob, cluster, mid="vm-bobbb", vm="vm100002", state="stopped")
    login(client, db, alice)
    ids = {m["id"] for m in client.get("/dashboard/live").json()["machines"]}
    assert ids == {a.id}
    # A normal user cannot widen the scope.
    assert {m["id"] for m in client.get("/dashboard/live?scope=all").json()["machines"]} == {a.id}
    login(client, db, make_user(db, "root@example.com", "admin"))
    data = client.get("/dashboard/live?scope=all").json()
    assert {m["id"] for m in data["machines"]} == {a.id, b.id} and data["running"] == 1


def test_machine_live_is_owner_only_and_not_cached(client, db):
    alice, bob = make_user(db, "alice@example.com"), make_user(db, "bob@example.com")
    m = make_machine(db, alice, make_cluster(db))
    login(client, db, bob)
    assert client.get(f"/machines/{m.id}/live").status_code == 404
    login(client, db, alice)
    r = client.get(f"/machines/{m.id}/live")
    assert r.status_code == 200 and r.headers["cache-control"] == "no-store"
    assert r.json()["state"] == "running" and r.json()["busy"] is False


def test_live_endpoints_require_sign_in(client, db):
    m = make_machine(db, make_user(db, "u@example.com"), make_cluster(db))
    assert client.get("/dashboard/live", follow_redirects=False).status_code == 303
    assert client.get(f"/machines/{m.id}/live", follow_redirects=False).status_code == 303


def test_pages_carry_live_hooks(client, db):
    owner = make_user(db, "u@example.com")
    m = make_machine(db, owner, make_cluster(db))
    login(client, db, owner)
    assert f'data-live-state="{m.id}"' in client.get("/dashboard").text
    page = client.get(f"/machines/{m.id}").text
    assert f'data-live-machine="/machines/{m.id}/live"' in page and "data-live-uptime" in page


# ---------------------------------------------------------------- reconcile

def test_fast_reconcile_only_reads_transitional_machines(db, monkeypatch):
    from plexus import worker
    cluster = make_cluster(db, ips=3)
    owner = make_user(db, "u@example.com")
    settled = make_machine(db, owner, cluster, mid="vm-setld", vm="vm100001", state="running")
    moving = make_machine(db, owner, cluster, mid="vm-movng", vm="vm100002", state="stopping")
    asked = []

    def statuses(c, machines):
        asked.extend(m.id for m in machines)
        return {m.id: "stopped" for m in machines}, True
    monkeypatch.setattr(worker, "_statuses", statuses)
    asyncio.run(worker._reconcile(full=False))
    db.expire_all()
    assert asked == [moving.id]
    assert db.get(Machine, moving.id).state == "stopped" and db.get(Machine, settled.id).state == "running"
    assert db.get(Setting, worker.HEARTBEAT_KEY) is not None


def test_reconcile_never_overrides_a_pending_job(db, monkeypatch):
    from plexus import worker
    m = make_machine(db, make_user(db, "u@example.com"), make_cluster(db), state="starting")
    db.add(Job(kind="start", machine_id=m.id, state="running")); db.commit()
    monkeypatch.setattr(worker, "_statuses", lambda c, machines: ({x.id: "stopped" for x in machines}, True))
    asyncio.run(worker._reconcile(full=False))
    db.expire_all()
    assert db.get(Machine, m.id).state == "starting"


# ---------------------------------------------------------------- metric accuracy

def _sample(cpu_ns, seconds_ago, **extra):
    return SimpleNamespace(cpu_time_ns=cpu_ns, sampled_at=utcnow() - timedelta(seconds=seconds_ago), **extra)


def test_cpu_percent_is_exact_and_safe():
    from plexus.services.metrics import cpu_percent
    now = utcnow()
    prev = SimpleNamespace(cpu_time_ns=1_000_000_000, sampled_at=now - timedelta(seconds=10))
    # 2 vCPUs, 10 s, 5 s of CPU time used = 25 %
    assert cpu_percent(6_000_000_000, now, prev, 2) == 25.0
    assert cpu_percent(500, now, prev, 2) is None  # QEMU restarted (counter reset)
    old = SimpleNamespace(cpu_time_ns=0, sampled_at=now - timedelta(hours=3))
    assert cpu_percent(10**12, now, old, 2) is None  # gap: no fake low average
    assert cpu_percent(10**18, now, prev, 1) == 100.0  # never above 100 %
    assert cpu_percent(1, now, None, 1) is None


def test_guest_memory_uses_balloon_statistics():
    from plexus.services.metrics import guest_memory_used_mb
    assert guest_memory_used_mb({"available": 2048 * 1024, "usable": 1536 * 1024, "rss": 2300 * 1024}, 2048) == 512
    assert guest_memory_used_mb({"available": 2048 * 1024, "unused": 1024 * 1024, "disk_caches": 512 * 1024}, 2048) == 512
    assert guest_memory_used_mb({"rss": 4096 * 1024}, 2048) == 2048  # fallback never exceeds configured
    assert guest_memory_used_mb({}, 2048) == 0


def test_live_rates_never_present_stale_samples():
    from plexus.services.metrics import live_rates
    running = SimpleNamespace(state="running", memory_mb=2048)
    a = _sample(0, 20, memory_used_mb=100, disk_read_bytes=0, disk_write_bytes=0, network_rx_bytes=1000, network_tx_bytes=0, cpu_percent=None)
    b = _sample(0, 10, memory_used_mb=1024, disk_read_bytes=10_240, disk_write_bytes=0, network_rx_bytes=11_000, network_tx_bytes=500, cpu_percent=12.5)
    rates = live_rates(running, [a, b])
    assert rates["live"] and rates["cpu"] == 12.5 and rates["memory_pct"] == 50.0
    assert round(rates["net_in_bps"]) == 1000 and round(rates["disk_read_bps"]) == 1024
    assert live_rates(SimpleNamespace(state="stopped", memory_mb=2048), [a, b])["live"] is False
    stale = _sample(0, 3600, memory_used_mb=1, disk_read_bytes=0, disk_write_bytes=0, network_rx_bytes=0, network_tx_bytes=0, cpu_percent=99.0)
    assert live_rates(running, [stale])["live"] is False
    reset = _sample(0, 1, memory_used_mb=1, disk_read_bytes=0, disk_write_bytes=0, network_rx_bytes=10, network_tx_bytes=0, cpu_percent=1.0)
    assert live_rates(running, [b, reset])["net_in_bps"] is None  # counter went backwards


def test_metrics_tab_says_when_data_is_not_live(client, db):
    owner = make_user(db, "u@example.com")
    m = make_machine(db, owner, make_cluster(db), state="stopped")
    db.add(MetricSample(machine_id=m.id, cpu_percent=88.0, cpu_time_ns=1, memory_used_mb=900, sampled_at=utcnow() - timedelta(hours=2))); db.commit()
    login(client, db, owner)
    text = client.get(f"/machines/{m.id}/metrics/live").text
    assert "No live usage while the machine is stopped" in text and "88.0" not in text


def test_metrics_poll_drops_samples_for_machines_that_changed(db, monkeypatch):
    from plexus import worker
    cluster = make_cluster(db)
    m = make_machine(db, make_user(db, "u@example.com"), cluster, state="running")

    def collect(c, items):
        # The machine is stopped while the node is being read.
        s = worker.SessionLocal(); row = s.get(Machine, m.id); row.state = "stopped"; s.commit(); s.close()
        return {m.id: {"cpu_percent": 5.0, "cpu_time_ns": 1, "memory_used_mb": 1, "disk_read_bytes": 0, "disk_write_bytes": 0,
                       "network_rx_bytes": 10**9, "network_tx_bytes": 0, "sampled_at": utcnow(), "epoch": f"{c.id}:1"}}, None
    monkeypatch.setattr(worker, "_collect_cluster", collect)
    asyncio.run(worker._poll_metrics())
    db.expire_all()
    assert db.query(MetricSample).count() == 0 and db.get(Machine, m.id).traffic_rx_bytes == 0


def test_metrics_poll_uses_exact_sample_time(db, monkeypatch):
    from plexus import worker
    cluster = make_cluster(db)
    m = make_machine(db, make_user(db, "u@example.com"), cluster, state="running")
    stamp = utcnow() - timedelta(seconds=3)
    monkeypatch.setattr(worker, "_collect_cluster", lambda c, items: ({m.id: {"cpu_percent": 1.0, "cpu_time_ns": 1, "memory_used_mb": 1, "disk_read_bytes": 0, "disk_write_bytes": 0,
                                                                            "network_rx_bytes": 0, "network_tx_bytes": 0, "sampled_at": stamp, "epoch": None}}, None))
    asyncio.run(worker._poll_metrics())
    db.expire_all()
    saved = db.query(MetricSample).one().sampled_at
    assert abs((saved.replace(tzinfo=None) - stamp.replace(tzinfo=None)).total_seconds()) < 0.01
