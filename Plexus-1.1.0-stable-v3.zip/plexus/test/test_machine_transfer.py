"""Machine Transfer: validation, the full move, every rollback path, resume, progress and the dialog."""
import asyncio
import json
from datetime import timedelta

import pytest

from plexus.models import AuditLog, ClusterIP, Job, Machine, utcnow
from conftest import login, make_cluster, make_machine, make_user


# ---------------------------------------------------------------- helpers

def _setup(db, state="running", target_ips=1):
    source = make_cluster(db, "src")
    target = make_cluster(db, "dst", ips=target_ips)
    for n, row in enumerate(db.query(ClusterIP).filter_by(cluster_id=target.id).order_by(ClusterIP.id).all()):
        row.public_ipv4 = f"203.0.113.{77 + n}"
    db.commit()
    machine = make_machine(db, make_user(db, "u@example.com"), source, state=state)
    if state == "running":
        machine.started_at = utcnow() - timedelta(hours=5); db.commit()
    old_ip = machine.cluster_ip.id
    job = Job(kind="transfer", machine_id=machine.id, state="running", payload=json.dumps({"target_cluster_id": target.id}))
    db.add(job); db.commit()
    return source, target, machine, old_ip, job


def _fake_hv(monkeypatch, fail=None):
    from plexus import worker
    hv = worker.hv
    calls = []

    async def preflight(s, t, vm, disk_gb, iso):
        calls.append(("preflight", s.name, t.name))
        if fail == "preflight":
            raise hv.NotStartedError("Transfer did not start, the machine was not changed: node unreachable")
        return {"virtual": 1, "actual": 1}

    async def stop(c, vm, grace=120, progress=None):
        calls.append(("stop", c.name))
        if progress:
            await progress(1.0, "Guest shut down cleanly")

    async def snapshot(s, vm, progress=None):
        calls.append(("snapshot", s.name))
        if progress:
            await progress(1.0, "")
        return 4096

    async def copy(s, t, vm, size, progress=None):
        calls.append(("copy", s.name, t.name, size))
        if fail == "copy":
            raise hv.HypervisorError("Transferred disk failed its checksum")
        if progress:
            await progress(0.5, "2.0 KiB of 4.0 KiB · 1.0 KiB/s")
            await progress(1.0, "4.0 KiB of 4.0 KiB")
        return "ab" * 32

    async def remove_scratch(s, vm): calls.append(("scratch", s.name))

    async def boot(t, spec):
        calls.append(("boot", t.name, spec["guest_ip"], spec["gateway"]))
        if fail == "boot":
            raise RuntimeError("boot failed")
        return "ssh-ed25519 AAAANEW"

    async def confirm(c, vm, ip, timeout=150, progress=None):
        calls.append(("confirm", c.name, ip)); return True

    async def delete(c, vm): calls.append(("delete", c.name))
    async def discard(c, vm): calls.append(("discard", c.name))
    async def push(cluster_id): calls.append(("rules", cluster_id))

    def power(cluster, vm, action):
        calls.append(("power", cluster.name, action))
        return {"start": "running", "stop": "stopping", "force-stop": "stopped", "restart": "restarting"}[action]

    monkeypatch.setattr(hv, "transfer_preflight", preflight)
    monkeypatch.setattr(hv, "stop_for_transfer", stop)
    monkeypatch.setattr(hv, "snapshot_disk", snapshot)
    monkeypatch.setattr(hv, "copy_disk", copy)
    monkeypatch.setattr(hv, "remove_scratch", remove_scratch)
    monkeypatch.setattr(hv, "boot_transferred", boot)
    monkeypatch.setattr(hv, "wait_for_guest_address", confirm)
    monkeypatch.setattr(hv, "delete", delete)
    monkeypatch.setattr(hv, "discard_copy", discard)
    monkeypatch.setattr(worker, "push_cluster_rules", push)
    monkeypatch.setattr(worker, "power_action", power)
    return calls


def _run(job):
    from plexus import worker
    asyncio.run(worker._run_job(job.id))


# ---------------------------------------------------------------- request validation

def test_transfer_request_validation(client, db):
    admin = make_user(db, "a@example.com", "admin")
    source = make_cluster(db, "src")
    target = make_cluster(db, "dst", ips=0)
    m = make_machine(db, make_user(db, "u@example.com"), source)
    csrf = login(client, db, admin)
    url = f"/administrator/machines/{m.id}/transfer"
    assert client.post(url, data={"csrf_token": csrf, "target_cluster_id": target.id, "confirm_name": "wrong"}).status_code == 422
    assert client.post(url, data={"csrf_token": csrf, "target_cluster_id": source.id, "confirm_name": m.vm_name}).status_code == 422
    r = client.post(url, data={"csrf_token": csrf, "target_cluster_id": target.id, "confirm_name": m.vm_name})
    assert r.status_code == 409 and "no free IPv4" in r.text
    # A held address is not free either.
    db.add(ClusterIP(cluster_id=target.id, private_ipv4="10.0.0.50", public_ipv4="198.51.100.50", guest_ipv4="192.168.122.150", held_for="vm-other")); db.commit()
    assert client.post(url, data={"csrf_token": csrf, "target_cluster_id": target.id, "confirm_name": m.vm_name}).status_code == 409
    db.add(ClusterIP(cluster_id=target.id, private_ipv4="10.0.0.51", public_ipv4="198.51.100.51", guest_ipv4="192.168.122.151")); db.commit()
    r = client.post(url, data={"csrf_token": csrf, "target_cluster_id": target.id, "confirm_name": m.vm_name})
    assert r.status_code == 200 and "Machine Transfer in Progress..." in r.text and 'data-auto-open="true"' in r.text
    db.expire_all()
    assert db.query(Job).filter_by(machine_id=m.id, kind="transfer").count() == 1
    assert db.query(AuditLog).filter_by(action="machine.transfer").count() == 1
    # A second transfer while one is pending is refused.
    assert client.post(url, data={"csrf_token": csrf, "target_cluster_id": target.id, "confirm_name": m.vm_name}).status_code == 409


def test_transfer_requires_admin_and_csrf(client, db):
    owner = make_user(db, "u@example.com")
    source, target = make_cluster(db, "src"), make_cluster(db, "dst")
    m = make_machine(db, owner, source)
    csrf = login(client, db, owner)
    assert client.post(f"/administrator/machines/{m.id}/transfer", data={"csrf_token": csrf, "target_cluster_id": target.id, "confirm_name": m.vm_name}).status_code == 403
    assert client.get(f"/administrator/machines/{m.id}/transfer/status").status_code == 403
    admin = make_user(db, "a@example.com", "admin")
    login(client, db, admin)
    assert client.post(f"/administrator/machines/{m.id}/transfer", data={"csrf_token": "forged", "target_cluster_id": target.id, "confirm_name": m.vm_name}).status_code == 403
    assert db.query(Job).filter_by(kind="transfer").count() == 0


def test_edit_page_lists_targets_with_next_ipv4(client, db):
    admin = make_user(db, "a@example.com", "admin")
    source, target = make_cluster(db, "src"), make_cluster(db, "dst", ips=2)
    full = make_cluster(db, "full", ips=0)
    m = make_machine(db, make_user(db, "u@example.com"), source)
    login(client, db, admin)
    page = client.get(f"/administrator/machines/{m.id}/edit").text
    first_free = db.query(ClusterIP).filter_by(cluster_id=target.id).order_by(ClusterIP.id).first().public_ipv4
    assert "Machine Transfer" in page and f"new IPv4 {first_free}" in page
    assert "no free IPv4" in page and f'value="{full.id}"' not in page
    assert 'data-auto-open="false"' in page


# ---------------------------------------------------------------- the move itself

def test_running_machine_moves_with_data_and_new_network(db, monkeypatch):
    source, target, m, old_ip, job = _setup(db)
    calls = _fake_hv(monkeypatch)
    _run(job)
    db.expire_all()
    moved, done = db.get(Machine, m.id), db.get(Job, job.id)
    assert done.state == "complete" and done.progress == 100 and done.stage == "complete"
    # Only the route summary is kept: no phase, power or secret data.
    assert set(json.loads(done.payload)) == {"target_cluster_id", "source_cluster_id", "old_ipv4"}
    assert moved.cluster_id == target.id and moved.state == "running"
    assert moved.cluster_ip.public_ipv4 == "203.0.113.77" and moved.guest_host_key == "ssh-ed25519 AAAANEW"
    assert moved.traffic_epoch == ""
    old = db.get(ClusterIP, old_ip)
    assert old.machine_id is None and old.held_for is None  # released only at the end
    names = [c[0] for c in calls]
    assert names.index("preflight") < names.index("stop") < names.index("snapshot") < names.index("copy") < names.index("boot") < names.index("delete")
    # New network configuration comes from the target's own subnet and gateway.
    boot = next(c for c in calls if c[0] == "boot")
    assert boot[1] == "dst" and boot[2] == moved.cluster_ip.guest_ipv4 and boot[3] == "192.168.122.1"
    assert ("delete", "src") in calls and ("rules", target.id) in calls and ("rules", source.id) in calls
    assert "203.0.113.77" in done.result
    from plexus.services.transfer import transfer_status
    status = transfer_status(db, moved, done)
    assert (status["source"], status["target"]) == ("src", "dst")
    assert status["old_ipv4"] == old.public_ipv4 and status["new_ipv4"] == "203.0.113.77" and status["new_ipv4_expected"] == ""


def test_stopped_machine_is_stopped_again_after_the_move(db, monkeypatch):
    source, target, m, old_ip, job = _setup(db, state="stopped")
    calls = _fake_hv(monkeypatch)
    _run(job)
    db.expire_all()
    moved = db.get(Machine, m.id)
    assert moved.cluster_id == target.id and moved.state == "stopped"
    assert ("stop", "dst") in calls  # booted once for the new network, then powered off


def test_preflight_failure_changes_nothing(db, monkeypatch):
    source, target, m, old_ip, job = _setup(db)
    started = db.get(Machine, m.id).started_at
    calls = _fake_hv(monkeypatch, fail="preflight")
    _run(job)
    db.expire_all()
    back = db.get(Machine, m.id)
    assert db.get(Job, job.id).state == "failed" and "did not start" in db.get(Job, job.id).result
    assert back.cluster_id == source.id and back.state == "running" and back.cluster_ip.id == old_ip
    assert abs((back.started_at.replace(tzinfo=None) - started.replace(tzinfo=None)).total_seconds()) < 1  # uptime kept
    assert [c[0] for c in calls] == ["preflight"]  # never stopped, never touched the target


def test_failed_copy_restores_the_machine_on_the_source(db, monkeypatch):
    source, target, m, old_ip, job = _setup(db)
    calls = _fake_hv(monkeypatch, fail="copy")
    _run(job)
    db.expire_all()
    back = db.get(Machine, m.id)
    assert db.get(Job, job.id).state == "failed" and "checksum" in db.get(Job, job.id).result
    assert back.cluster_id == source.id and back.state == "running" and back.cluster_ip.id == old_ip
    assert ("discard", "dst") in calls and ("power", "src", "start") in calls and ("delete", "src") not in calls
    assert db.query(ClusterIP).filter_by(cluster_id=target.id).one().machine_id is None


def test_failed_boot_returns_to_the_exact_old_address(db, monkeypatch):
    source, target, m, old_ip, job = _setup(db)
    calls = _fake_hv(monkeypatch, fail="boot")
    _run(job)
    db.expire_all()
    back = db.get(Machine, m.id)
    assert db.get(Job, job.id).state == "failed"
    assert back.cluster_id == source.id and back.state == "running" and back.cluster_ip.id == old_ip
    assert db.query(ClusterIP).filter(ClusterIP.held_for.isnot(None)).count() == 0
    assert db.query(ClusterIP).filter_by(cluster_id=target.id).one().machine_id is None
    assert ("discard", "dst") in calls and ("delete", "src") not in calls


def test_held_address_is_never_handed_to_another_machine(db):
    from fastapi import HTTPException
    from plexus.services.machines import allocate_ip
    cluster = make_cluster(db, "solo", ips=1)
    row = db.query(ClusterIP).filter_by(cluster_id=cluster.id).one()
    row.held_for = "vm-moving"; db.commit()
    other = Machine(id="vm-other", vm_name="vm222222", owner_id=make_user(db, "x@example.com").id, cluster_id=cluster.id, vcpu=1, memory_mb=1024, disk_gb=10, state="provisioning")
    db.add(other); db.flush()
    with pytest.raises(HTTPException):
        allocate_ip(db, cluster.id, other.id)


def test_refuses_suspended_machine(db, monkeypatch):
    source, target, m, old_ip, job = _setup(db)
    m.state = "suspended"; db.commit()
    calls = _fake_hv(monkeypatch)
    _run(job)
    db.expire_all()
    assert db.get(Job, job.id).state == "failed" and calls == [] and db.get(Machine, m.id).state == "suspended"


def test_resume_after_swap_finishes_on_the_target(db, monkeypatch):
    source, target, m, old_ip, job = _setup(db)
    old = db.get(ClusterIP, old_ip)
    old.machine_id, old.held_for = None, m.id
    new = db.query(ClusterIP).filter_by(cluster_id=target.id).one()
    new.machine_id = m.id
    m.cluster_id, m.state = target.id, "transferring"
    job.payload = json.dumps({"target_cluster_id": target.id, "source_cluster_id": source.id, "previous_state": "running", "phase": "swapped"})
    db.commit()
    calls = _fake_hv(monkeypatch)
    _run(job)
    db.expire_all()
    moved = db.get(Machine, m.id)
    assert db.get(Job, job.id).state == "complete" and moved.cluster_id == target.id and moved.state == "running"
    assert "copy" not in [c[0] for c in calls] and ("delete", "src") in calls
    assert db.get(ClusterIP, old_ip).held_for is None


def test_resume_before_swap_copies_again(db, monkeypatch):
    source, target, m, old_ip, job = _setup(db)
    m.state = "transferring"
    job.payload = json.dumps({"target_cluster_id": target.id, "source_cluster_id": source.id, "previous_state": "running", "phase": "copy"})
    db.commit()
    calls = _fake_hv(monkeypatch)
    _run(job)
    db.expire_all()
    assert db.get(Job, job.id).state == "complete" and db.get(Machine, m.id).cluster_id == target.id
    assert "copy" in [c[0] for c in calls]


def test_worker_stop_requeues_instead_of_failing(db, monkeypatch):
    from plexus import worker
    m = make_machine(db, make_user(db, "u@example.com"), make_cluster(db), state="running")
    job = Job(kind="restart", machine_id=m.id, state="running", payload="{}"); db.add(job); db.commit()

    def cancelled(*_a):
        raise asyncio.CancelledError()
    monkeypatch.setattr(worker, "power_action", cancelled)
    with pytest.raises(asyncio.CancelledError):
        asyncio.run(worker._run_job(job.id))
    db.expire_all()
    assert db.get(Job, job.id).state == "queued"


def test_cleanup_job_never_removes_the_live_copy(db, monkeypatch):
    from plexus import worker
    cluster = make_cluster(db, "live")
    m = make_machine(db, make_user(db, "u@example.com"), cluster)
    removed = []

    async def discard(c, vm): removed.append(vm)
    monkeypatch.setattr(worker.hv, "discard_copy", discard)
    assert "Skipped" in asyncio.run(worker._cleanup_copy(db, {"cluster_id": cluster.id, "vm_name": m.vm_name, "machine_id": m.id}))
    other = make_cluster(db, "old")
    assert "removed" in asyncio.run(worker._cleanup_copy(db, {"cluster_id": other.id, "vm_name": m.vm_name, "machine_id": m.id}))
    assert removed == [m.vm_name]


# ---------------------------------------------------------------- progress and status

def test_progress_is_monotonic_and_mapped_to_stages(db, monkeypatch):
    from plexus import worker
    from plexus.services.transfer import STAGES
    writes = []
    monkeypatch.setattr(worker, "_write_progress", lambda job_id, pct, stage, detail: writes.append((pct, stage)))
    progress = worker.TransferProgress(1)

    async def go():
        await progress.set("copy", 0.5, force=True)
        await progress.set("snapshot", 1.0, force=True)  # an earlier stage never moves the bar back
        await progress.set("verify", 1.0, force=True)
    asyncio.run(go())
    start, end, _ = STAGES["copy"]
    assert writes[0] == (start + (end - start) // 2, "copy")
    assert writes[1][0] >= writes[0][0]
    assert writes[-1] == (STAGES["verify"][1], "verify")
    assert all(a[0] <= b[0] for a, b in zip(writes, writes[1:]))


def test_status_endpoint_and_owner_view(client, db, monkeypatch):
    source, target, m, old_ip, job = _setup(db)
    job.progress, job.stage, job.detail = 47, "copy", "9.4 GiB of 20.0 GiB · 180 MiB/s"
    job.payload = json.dumps({"target_cluster_id": target.id, "source_cluster_id": source.id, "phase": "copy"})
    m.state = "transferring"; db.commit()
    admin = make_user(db, "a@example.com", "admin")
    login(client, db, admin)
    status = client.get(f"/administrator/machines/{m.id}/transfer/status").json()
    assert status["state"] == "running" and status["percent"] == 47 and status["stage"] == "copy"
    assert status["source"] == "src" and status["target"] == "dst" and "GiB" in status["detail"]
    assert status["new_ipv4"] == "" and status["new_ipv4_expected"] == "203.0.113.77"
    assert [s["status"] for s in status["steps"]][:5] == ["done", "done", "done", "active", "pending"]
    page = client.get(f"/administrator/machines/{m.id}/edit").text
    assert 'data-auto-open="true"' in page and "47" in page
    # The owner sees the percentage, never node names or other details.
    owner = db.get(Machine, m.id).owner
    login(client, db, owner)
    live = client.get(f"/machines/{m.id}/live").json()
    assert live["state"] == "transferring" and live["transfer"]["percent"] == 47
    assert "src" not in json.dumps(live) and "dst" not in json.dumps(live)
    assert "Machine transfer in progress" in client.get(f"/machines/{m.id}").text
