"""Regression tests for previously fixed bugs (console, pool, power states, IP allocation, rules, login)."""
import asyncio
import pytest
from fastapi import HTTPException
from plexus.models import ClusterIP, LoginAttempt, Machine, User
from conftest import login, make_cluster, make_machine, make_user


# 1 — console releases its DB connection before streaming
def test_console_releases_db_connection_before_streaming(client, db, monkeypatch):
    from plexus.db import engine
    from plexus.routes import sockets
    from plexus.services.libvirt import HypervisorError
    owner = make_user(db, "u@example.com")
    machine = make_machine(db, owner, make_cluster(db))
    login(client, db, owner)
    db.close()
    seen = {}
    async def fake_open_console(cluster, m):
        seen["checked_out"] = engine.pool.checkedout()
        seen["ip"] = m.cluster_ip.guest_ipv4  # detached object still usable
        raise HypervisorError("stop here")
    monkeypatch.setattr(sockets, "open_console", fake_open_console)
    with pytest.raises(Exception):  # noqa: B017 - any disconnect type is acceptable
        with client.websocket_connect(f"/ws/machines/{machine.id}/console", headers={"origin": "http://testserver"}) as ws:
            ws.receive_bytes()
    assert seen["checked_out"] == 0
    assert seen["ip"].startswith("192.168.122.")


def test_pool_is_sized_for_concurrency():
    from plexus.db import engine
    assert engine.pool.size() >= 20


# 2 — shutdown/reboot report a transition, reconcile confirms
class _Domain:
    def create(self): pass
    def shutdown(self): pass
    def reboot(self, _flags): pass
    def destroy(self): pass

class _Conn:
    def lookupByName(self, _name): return _Domain()
    def close(self): pass

@pytest.mark.parametrize("action,expected", [("start", "running"), ("stop", "stopping"), ("restart", "restarting"), ("force-stop", "stopped")])
def test_power_action_reports_transition(monkeypatch, action, expected):
    from plexus.services import libvirt as hv
    monkeypatch.setattr(hv, "_connect", lambda cluster: _Conn())
    assert hv.power_action(None, "vm100001", action) == expected


def test_reconcile_keeps_stopping_while_guest_shuts_down():
    from plexus.worker import next_power_state
    assert next_power_state("stopping", "running", 20) is None          # no flap back to running
    assert next_power_state("stopping", "stopped", 20) == "stopped"     # confirmed
    assert next_power_state("stopping", "running", 600) == "running"    # guest ignored ACPI
    assert next_power_state("restarting", "running", 5) == "running"
    assert next_power_state("suspended", "running", None) is None


# 3 — concurrent creates cannot claim the same IP
def test_allocate_ip_skips_address_claimed_concurrently(db):
    from plexus.db import SessionLocal
    from plexus.services.machines import allocate_ip
    owner = make_user(db, "u@example.com")
    cluster = make_cluster(db, ips=2)
    other = SessionLocal()
    try:
        a = Machine(id="vm-aaaa1", vm_name="vm100001", owner_id=owner.id, cluster_id=cluster.id, vcpu=1, memory_mb=512, disk_gb=5)
        b = Machine(id="vm-bbbb2", vm_name="vm100002", owner_id=owner.id, cluster_id=cluster.id, vcpu=1, memory_mb=512, disk_gb=5)
        db.add(a); db.commit(); other.add(b); other.commit()
        first = allocate_ip(db, cluster.id, a.id); db.commit()
        second = allocate_ip(other, cluster.id, b.id); other.commit()
        assert first.id != second.id
        third = Machine(id="vm-cccc3", vm_name="vm100003", owner_id=owner.id, cluster_id=cluster.id, vcpu=1, memory_mb=512, disk_gb=5)
        db.add(third); db.commit()
        with pytest.raises(HTTPException) as exc:
            allocate_ip(db, cluster.id, third.id)
        assert exc.value.status_code == 409
    finally:
        other.close()


# 4 — node's own primary IP is rejected
def test_parse_ip_pairs_rejects_node_primary_ip():
    from plexus.services.network import parse_ip_pairs
    with pytest.raises(HTTPException) as exc:
        parse_ip_pairs("10.0.0.1,198.51.100.1", "10.0.0.0/24", "10.0.0.1")
    assert exc.value.status_code == 422
    with pytest.raises(HTTPException):
        parse_ip_pairs("10.0.0.5,10.0.0.1", "10.0.0.0/24", "10.0.0.1")
    assert parse_ip_pairs("10.0.0.5,198.51.100.5", "10.0.0.0/24", "10.0.0.1") == [("10.0.0.5", "198.51.100.5")]


# 5 — push_rules waits until the private IPs are on the uplink too
def test_push_rules_waits_for_private_ips(monkeypatch):
    import hashlib
    from plexus.services import libvirt as hv
    rules = "table ip plexus {}\n"
    state = {"polls": 0}
    class Result:
        def __init__(self, out, code=0): self.stdout, self.exit_status = out, code
    class SFTPFile:
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
        async def write(self, _): pass
    class SFTP:
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
        def open(self, *a): return SFTPFile()
        async def chmod(self, *a): pass
    class Conn:
        def start_sftp_client(self): return SFTP()
        async def run(self, cmd, **kw):
            if cmd.startswith("cat"):
                return Result(hashlib.sha256(rules.encode()).hexdigest())
            state["polls"] += 1
            ips = "10.0.0.10/24" if state["polls"] >= 3 else ""
            return Result(f"2: eth0    inet {ips} brd 10.0.0.255 scope global eth0" if ips else "")
        def close(self): pass
    async def fake_conn(_c): return Conn()
    monkeypatch.setattr(hv, "_node_connection", fake_conn)
    async def fast_sleep(*_a): return None
    monkeypatch.setattr(hv.asyncio, "sleep", fast_sleep)
    class Cluster: uplink_interface = "eth0"
    asyncio.run(hv.push_rules(Cluster(), rules, ["10.0.0.10"]))
    assert state["polls"] >= 3  # did not return on the rules hash alone



# 6 — admins are not locked out by deliberate wrong guesses
def _attempt(client, email, password):
    page = client.get("/auth")
    csrf = page.cookies.get("plexus_csrf") or client.cookies.get("plexus_csrf")
    return client.post("/auth", data={"email": email, "password": password, "csrf_token": csrf}, follow_redirects=False)

def test_admin_not_locked_by_failed_logins(client, db):
    from plexus.config import settings
    make_user(db, "admin@example.com", "admin")
    for _ in range(settings.login_account_limit + 2):
        _attempt(client, "admin@example.com", "wrong-password-123")
        # simulate an attacker rotating source IPs so only the account limit could apply
        db.query(LoginAttempt).update({"ip_key": "rotated", "blocked_until": None}); db.commit()
    db.expire_all()
    admin = db.query(User).filter_by(email="admin@example.com").one()
    assert admin.locked_until is None
    assert _attempt(client, "admin@example.com", "correct-horse-battery").status_code == 303

def test_regular_user_still_locked(client, db):
    from plexus.config import settings
    make_user(db, "user@example.com")
    for _ in range(settings.login_account_limit):
        _attempt(client, "user@example.com", "wrong-password-123")
    db.expire_all()
    assert db.query(User).filter_by(email="user@example.com").one().locked_until is not None


# 8 — Starlette's own 404/405/422 render the HTML error page
def test_router_404_and_405_render_error_page(client):
    r = client.get("/no-such-page")
    assert r.status_code == 404 and "text/html" in r.headers["content-type"] and "Plexus" in r.text
    r = client.put("/auth")
    assert r.status_code == 405 and "text/html" in r.headers["content-type"]

def test_validation_error_renders_error_page(client):
    r = client.post("/auth", data={})
    assert r.status_code == 422 and "text/html" in r.headers["content-type"]


# one-time password page is never cached
def test_machine_create_response_is_no_store(client, db):
    admin = make_user(db, "admin@example.com", "admin")
    owner = make_user(db, "u@example.com")
    cluster = make_cluster(db)
    from plexus.models import Image
    image = Image(name="Ubuntu", url="https://x/y.img", checksum="a" * 64, kind="cloud"); db.add(image); db.commit()
    csrf = login(client, db, admin)
    r = client.post("/administrator/machines", data={"csrf_token": csrf, "owner_id": owner.id, "cluster_id": cluster.id, "image_id": image.id, "vcpu": 2, "memory_mb": 2048, "disk_gb": 20})
    assert r.status_code == 200
    assert r.headers["cache-control"] == "no-store"
    assert "ubuntu with this password" in r.text
    db.expire_all()
    assert db.query(ClusterIP).filter(ClusterIP.machine_id.is_not(None)).count() == 1
