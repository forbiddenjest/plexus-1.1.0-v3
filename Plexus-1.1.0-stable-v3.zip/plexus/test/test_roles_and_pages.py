"""Roles, page access and page layout."""
import pytest
from fastapi import HTTPException
from conftest import login, make_cluster, make_machine, make_user

ADMIN_PAGES = ["overview", "machines", "clusters", "network", "images", "accounts", "logs", "metrics", "others"]
NEW_PAGES = ["machines", "clusters", "network", "images", "accounts"]


@pytest.mark.parametrize("page", ADMIN_PAGES + [f"{p}/new" for p in NEW_PAGES])
def test_user_cannot_open_admin_pages(client, db, page):
    login(client, db, make_user(db, "u@example.com"))
    assert client.get(f"/administrator/{page}", follow_redirects=False).status_code == 403


@pytest.mark.parametrize("page", ADMIN_PAGES + [f"{p}/new" for p in NEW_PAGES])
def test_admin_pages_render(client, db, page):
    make_cluster(db)
    login(client, db, make_user(db, "a@example.com", "admin"))
    r = client.get(f"/administrator/{page}")
    assert r.status_code == 200
    assert "Plexus Virtualization • © PlexScale. All Rights Reserved." in r.text


def test_user_cannot_post_admin_actions(client, db):
    csrf = login(client, db, make_user(db, "u@example.com"))
    r = client.post("/administrator/accounts", data={"csrf_token": csrf, "email": "x@example.com", "role": "admin"}, follow_redirects=False)
    assert r.status_code == 403


def test_list_pages_link_to_separate_create_page(client, db):
    login(client, db, make_user(db, "a@example.com", "admin"))
    for page in NEW_PAGES:
        body = client.get(f"/administrator/{page}").text
        assert f'href="/administrator/{page}/new"' in body
        assert 'class="form-grid"' not in body  # forms live on the /new page only


def test_login_lands_on_dashboard_for_both_roles(client, db):
    for email, role in [("a@example.com", "admin"), ("u@example.com", "user")]:
        make_user(db, email, role)
        client.cookies.clear()
        page = client.get("/auth")
        r = client.post("/auth", data={"email": email, "password": "correct-horse-battery", "csrf_token": page.cookies.get("plexus_csrf")}, follow_redirects=False)
        assert r.status_code == 303 and r.headers["location"] == "/dashboard"


def test_dashboard_scope(client, db):
    admin = make_user(db, "a@example.com", "admin")
    user = make_user(db, "u@example.com")
    cluster = make_cluster(db)
    make_machine(db, user, cluster, "vm-user1", "vm100001")
    make_machine(db, admin, cluster, "vm-admn1", "vm100002")
    login(client, db, user)
    body = client.get("/dashboard?scope=all").text  # scope ignored for users
    assert "vm-user1" in body and "vm-admn1" not in body and "All VMs" not in body
    client.cookies.clear(); login(client, db, admin)
    mine = client.get("/dashboard").text
    assert "vm-admn1" in mine and "vm-user1" not in mine and "Your VMs" in mine
    everything = client.get("/dashboard?scope=all").text
    assert "vm-admn1" in everything and "vm-user1" in everything


def test_user_cannot_open_someone_elses_machine(client, db):
    owner = make_user(db, "o@example.com")
    machine = make_machine(db, owner, make_cluster(db))
    login(client, db, make_user(db, "u@example.com"))
    assert client.get(f"/machines/{machine.id}").status_code == 404


def test_machine_overview_shows_location_not_guest_ip(client, db):
    owner = make_user(db, "o@example.com")
    cluster = make_cluster(db, location="Mumbai, Pune", location_id="IN")
    machine = make_machine(db, owner, cluster)
    login(client, db, owner)
    body = client.get(f"/machines/{machine.id}").text
    assert "Location" in body and "Mumbai, Pune" in body and ">IN<" in body
    assert "https://flagcdn.com/w320/in.png" in body
    assert "Guest IPv4" not in body and machine.cluster_ip.guest_ipv4 not in body
    assert "<h2 class=\"box-title\">Overview</h2>" in body and ">Domain<" not in body


def test_support_link_validation_and_display(client, db):
    from plexus.services.panel_settings import validate_support_url
    assert validate_support_url("https://discord.gg/abc123") == "https://discord.gg/abc123"
    assert validate_support_url("") == ""
    for bad in ["http://discord.gg/abc", "https://evil.com/x", "https://discord.com/channels/1", "javascript:alert(1)", "https://discord.gg/"]:
        with pytest.raises(HTTPException):
            validate_support_url(bad)
    csrf = login(client, db, make_user(db, "a@example.com", "admin"))
    assert client.post("/administrator/settings", data={"csrf_token": csrf, "support_url": "https://discord.gg/plexus"}).status_code == 200
    client.cookies.clear(); login(client, db, make_user(db, "u@example.com"))
    assert 'href="https://discord.gg/plexus"' in client.get("/dashboard").text


def test_create_account_with_role_and_no_store(client, db):
    csrf = login(client, db, make_user(db, "a@example.com", "admin"))
    r = client.post("/administrator/accounts", data={"csrf_token": csrf, "email": "New@Example.com", "role": "admin"})
    assert r.status_code == 200 and r.headers["cache-control"] == "no-store"
    from plexus.models import User
    db.expire_all()
    created = db.query(User).filter_by(email="new@example.com").one()
    assert created.role == "admin" and created.force_password_change


def test_create_form_error_rerenders_form(client, db):
    csrf = login(client, db, make_user(db, "a@example.com", "admin"))
    r = client.post("/administrator/network/ips", data={"csrf_token": csrf, "cluster_id": make_cluster(db).id, "pairs": "10.0.0.1,198.51.100.99"})
    assert r.status_code == 422 and "primary IP" in r.text and 'name="pairs"' in r.text


def test_role_change_signs_target_out(client, db):
    from plexus.models import Session as LoginSession
    admin = make_user(db, "a@example.com", "admin")
    target = make_user(db, "u@example.com")
    from plexus.security import new_session
    new_session(db, target); db.commit()
    csrf = login(client, db, admin)
    client.post("/administrator/accounts/%d/role" % target.id, data={"csrf_token": csrf, "role": "admin"})
    db.expire_all()
    assert db.query(LoginSession).filter_by(user_id=target.id).count() == 0


def test_csrf_required(client, db):
    login(client, db, make_user(db, "a@example.com", "admin"))
    assert client.post("/administrator/settings", data={"support_url": ""}).status_code == 403


def test_alembic_upgrade_head(tmp_path):
    import subprocess, sys, os
    env = dict(os.environ, PLEXUS_DATABASE_URL=f"sqlite:///{tmp_path}/m.db")
    out = subprocess.run([sys.executable, "-m", "alembic", "-c", "alembic.ini", "upgrade", "head"], env=env, capture_output=True, text=True)
    assert out.returncode == 0, out.stderr
