"""Service units, version, sidebar, status and metrics pages, IP display, time zone and CLI."""
from pathlib import Path

from plexus import __version__
from plexus.models import AuditLog, Machine
from plexus.services.clusters import node_unit_alias
from conftest import NODE_ROOT, WEB_ROOT, login, make_cluster, make_machine, make_user

ROOT = WEB_ROOT
FOOTER = "Plexus Virtualization • © PlexScale. All Rights Reserved."


def test_version_is_1_1_0_everywhere():
    assert __version__ == "1.1.0"
    assert 'version = "1.1.0"' in (ROOT / "pyproject.toml").read_text()


def test_service_units_use_plexus_prefix():
    systemd = ROOT / "deploy" / "systemd"
    units = sorted(p.name for p in systemd.glob("*.service"))
    assert units == sorted(["plexus-clusters.service", "plexus-web.service", "plexus.service"])
    assert "Alias=clusters.service" in (systemd / "plexus-clusters.service").read_text()
    assert "Alias=Plexus.service" in (systemd / "plexus.service").read_text()
    assert "Wants=plexus-web.service plexus-clusters.service" in (systemd / "plexus.service").read_text()
    assert "uvicorn plexus.main:app" in (systemd / "plexus-web.service").read_text()
    assert "python -m plexus.worker_service" in (systemd / "plexus-clusters.service").read_text()
    for path in [p for p in (ROOT / "deploy").rglob("*") if p.is_file()] + [NODE_ROOT / "setup.sh.j2"]:
        assert "plexus-worker.service" not in path.read_text()


def test_node_alias_cannot_shadow_panel_units():
    for name in ("plexus-clusters", "clusters", "plexus-web", "Plexus"):
        assert node_unit_alias(name) == ""
    assert node_unit_alias("Node 01") == "node-01"


def test_footer_and_title_branding(client, db):
    page = client.get("/auth").text
    assert FOOTER in page and "<title>Plexus</title>" in page and 'class="auth-logo"' in page
    login(client, db, make_user(db, "u@example.com"))
    page = client.get("/dashboard").text
    assert FOOTER in page and "<title>Plexus</title>" in page


def test_status_button_only_when_set(client, db):
    admin = make_user(db, "a@example.com", "admin")
    csrf = login(client, db, admin)
    assert ">Status<" not in client.get("/dashboard").text
    r = client.post("/administrator/settings", data={"csrf_token": csrf, "status_url": "http://status.example.com"})
    assert r.status_code == 422
    client.post("/administrator/settings", data={"csrf_token": csrf, "status_url": "https://status.example.com"})
    page = client.get("/dashboard").text
    assert 'href="https://status.example.com" target="_blank" rel="noopener noreferrer"' in page


def test_metrics_in_sidebar_between_logs_and_others(client, db):
    make_cluster(db)
    login(client, db, make_user(db, "a@example.com", "admin"))
    page = client.get("/administrator/metrics").text
    assert page.index("Activity logs") < page.index(">Metrics<") < page.index(">Others<")
    assert "vCPU cores" in page and "Bandwidth · last 30 days" in page
    assert client.get("/administrator/metrics/live").status_code == 200


def test_ip_blurred_in_lists_but_not_in_overview(client, db):
    owner = make_user(db, "u@example.com")
    cluster = make_cluster(db)
    machine = make_machine(db, owner, cluster)
    login(client, db, owner)
    ip = db.get(Machine, machine.id).cluster_ip.public_ipv4
    assert f'class="ip-blur mono" tabindex="0" title="Hover or focus to reveal">{ip}<' in client.get("/dashboard").text
    assert "ip-blur" not in client.get(f"/machines/{machine.id}").text


def test_others_page_shows_status_and_cpu_fields(client, db):
    login(client, db, make_user(db, "a@example.com", "admin"))
    page = client.get("/administrator/others").text
    assert 'name="status_url"' in page and 'name="support_url"' in page and 'name="cpu_mode"' in page


def test_cli_reset_state_and_audit(db):
    from plexus import cli
    owner = make_user(db, "u@example.com")
    machine = make_machine(db, owner, make_cluster(db), state="failed")
    assert cli.main(["machine", "reset-state", machine.id]) == 0
    db.expire_all()
    assert db.get(Machine, machine.id).state == "unknown"
    assert db.query(AuditLog).filter(AuditLog.action == "cli.machine.reset_state").count() == 1
    assert cli.main(["machine", "reset-state", "vm-nope0"]) == cli.EXIT_NOT_FOUND


def test_cli_version_and_help(capsys):
    from plexus import cli
    assert cli.main(["version"]) == 0
    assert "Plexus Virtualization v_1.1.0" in capsys.readouterr().out
    assert cli.main([]) == 0
