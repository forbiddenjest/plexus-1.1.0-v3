#!/usr/bin/env bash
# Plexus Virtualization - web panel installer and upgrader
# (Ubuntu 24.04 / Debian 12 with Python 3.12).
#
# Run from the unpacked release:   sudo bash plexus/web/deploy/install.sh
# Safe to run again: upgrades the code, applies database updates and restarts the panel.
#
# Layout after install:
#   /opt/plexus            web panel (this release's web/ folder) + .venv
#   /opt/plexus/node       node files (this release's node/ folder), served to nodes at enrollment
#   /etc/plexus/plexus.env settings and secrets (root:plexus 0640)
#   /var/lib/plexus        database and uploaded media
set -euo pipefail
umask 027
if [[ "${EUID}" -ne 0 ]]; then echo "Run as root." >&2; exit 1; fi

RELEASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
PANEL_SRC="$RELEASE/web"
NODE_SRC="$RELEASE/node"
DEST=/opt/plexus
DATA=/var/lib/plexus
CONF=/etc/plexus
ENV_FILE="$CONF/plexus.env"

for required in "$PANEL_SRC/pyproject.toml" "$PANEL_SRC/plexus/main.py" "$NODE_SRC/setup.sh.j2" "$NODE_SRC/bin/plexus-node"; do
  [[ -f "$required" ]] || { echo "Incomplete release: $required is missing. Run this from the unpacked Plexus release." >&2; exit 1; }
done

apt-get update
apt-get install -y python3.12 python3.12-venv python3-pip build-essential pkg-config libvirt-dev libvirt-clients qemu-utils caddy rsync sqlite3 tzdata

getent group plexus >/dev/null || groupadd --system plexus
id -u plexus >/dev/null 2>&1 || useradd --system --gid plexus --home-dir "$DATA" --create-home --shell /usr/sbin/nologin plexus
install -d -o plexus -g plexus -m 0750 "$DATA" "$DATA/media"
install -d -o root -g plexus -m 0750 "$CONF"

# Back up the database before an upgrade touches it (.backup is consistent even with WAL).
if [[ -f "$DATA/plexus.db" ]]; then
  backup="$DATA/plexus.db.pre-$(cat "$RELEASE/VERSION" 2>/dev/null || echo upgrade)-$(date +%Y%m%d%H%M%S)"
  sqlite3 "$DATA/plexus.db" ".backup '$backup'"
  chown plexus:plexus "$backup"; chmod 0640 "$backup"
  echo "Database backed up to $backup"
fi

# Code is owned by root and only readable by the service account, so a compromised
# panel process cannot modify its own code.
install -d -o root -g plexus -m 0750 "$DEST" "$DEST/node"
rsync -a --delete --exclude '.env' --exclude '.venv' --exclude '__pycache__' --exclude '.pytest_cache' --exclude '.git' --exclude '/node/' "$PANEL_SRC/" "$DEST/"
rsync -a --delete --exclude '__pycache__' "$NODE_SRC/" "$DEST/node/"
install -m 0644 "$RELEASE/VERSION" "$DEST/VERSION"
python3.12 -m venv "$DEST/.venv"
"$DEST/.venv/bin/pip" install --upgrade pip==26.3
"$DEST/.venv/bin/pip" install "$DEST"
chown -R root:plexus "$DEST"
chmod -R u=rwX,g=rX,o= "$DEST"
chmod 0750 "$DEST/node/bin/"*

if [[ ! -f "$ENV_FILE" ]]; then
  (cd /tmp && "$DEST/.venv/bin/python" - <<'PY'
import os, secrets
from cryptography.fernet import Fernet
path = "/etc/plexus/plexus.env"
fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o640)
with os.fdopen(fd, "w") as f:
    f.write("PLEXUS_ENVIRONMENT=production\n"
            "PLEXUS_TRUSTED_HOST=vps.mydomain.xyz\n"
            "PLEXUS_DATABASE_URL=sqlite:////var/lib/plexus/plexus.db\n"
            "PLEXUS_TIMEZONE=Asia/Kolkata\n"
            "PLEXUS_NODE_DIR=/opt/plexus/node\n"
            f"PLEXUS_SECRET_KEY={secrets.token_urlsafe(48)}\n"
            f"PLEXUS_ENCRYPTION_KEY={Fernet.generate_key().decode()}\n"
            "PLEXUS_SECURE_COOKIES=true\n")
PY
  )
  chown root:plexus "$ENV_FILE"
  chmod 0640 "$ENV_FILE"
  echo "Created $ENV_FILE with unique secrets. Back it up: the encryption key protects node SSH keys."
fi

# Database schema (new installs and upgrades).
# Secrets are sourced inside the child shell, never passed on a command line.
runuser -u plexus -- sh -c "set -a; . $ENV_FILE; set +a; cd $DEST && .venv/bin/alembic -c alembic.ini upgrade head"

install -m 0644 "$DEST/deploy/systemd/plexus.service" "$DEST/deploy/systemd/plexus-web.service" "$DEST/deploy/systemd/plexus-clusters.service" /etc/systemd/system/
install -m 0755 "$DEST/deploy/bin/plexus" /usr/local/bin/plexus
systemctl daemon-reload
# Enabling creates the short names: Plexus.service (whole panel) and clusters.service (worker).
systemctl enable plexus.service plexus-web.service plexus-clusters.service >/dev/null
# Already running (an upgrade): pick up the new code now.
systemctl try-restart plexus-web.service plexus-clusters.service

cat <<MSG
Plexus Virtualization $(cat "$DEST/VERSION") is installed in $DEST (node files: $DEST/node).
Next steps:
  1. Set PLEXUS_TRUSTED_HOST in $ENV_FILE to the panel hostname
     (the services refuse to start with the placeholder value).
  2. Put the hostname into $DEST/deploy/caddy/Caddyfile and install it as /etc/caddy/Caddyfile,
     then: systemctl reload caddy
  3. Create the first administrator (skip when upgrading):
       sudo plexus create-admin you@example.com --username admin
  4. systemctl start Plexus
  5. Check everything:  sudo plexus doctor

Everyday commands:
  systemctl start|stop|restart Plexus    whole panel (web + clusters service)
  systemctl start|stop|restart clusters  plexus-clusters.service: jobs, transfers, nodes, metrics
  systemctl restart plexus-web           web panel only
  sudo plexus status | doctor | nodes | logs
  sudo plexus node verify <name> | node refresh <name>
  sudo plexus machine reset-state <vm-id> | machine refresh-bandwidth <vm-id>
On a node:   sudo plexus-node-selftest   and   systemctl restart <node name>
MSG
