"""Plexus 1.1.0: live node metrics (Administration > Metrics).

node_samples holds one row per node per metrics cycle: host CPU, memory, disk and the
combined guest network rate. Rows older than PLEXUS_METRICS_RETENTION_DAYS are purged
by the worker, exactly like per-machine samples.
"""
from alembic import op
import sqlalchemy as sa

revision = "0007_node_samples"
down_revision = "0006_traffic_epoch"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "node_samples",
        sa.Column("id", sa.BigInteger().with_variant(sa.Integer(), "sqlite"), primary_key=True),
        sa.Column("cluster_id", sa.Integer(), sa.ForeignKey("clusters.id", ondelete="CASCADE"), nullable=False),
        sa.Column("cpu_threads", sa.Integer(), nullable=False),
        sa.Column("cpu_percent", sa.Float(), nullable=True),
        sa.Column("cpu_busy_ns", sa.BigInteger(), nullable=False),
        sa.Column("cpu_total_ns", sa.BigInteger(), nullable=False),
        sa.Column("memory_total_mb", sa.Integer(), nullable=False),
        sa.Column("memory_used_mb", sa.Integer(), nullable=True),
        sa.Column("disk_total_bytes", sa.BigInteger(), nullable=True),
        sa.Column("disk_used_bytes", sa.BigInteger(), nullable=True),
        sa.Column("net_rx_bps", sa.BigInteger(), nullable=False),
        sa.Column("net_tx_bps", sa.BigInteger(), nullable=False),
        sa.Column("sampled_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_node_samples_cluster_id", "node_samples", ["cluster_id"])
    op.create_index("ix_node_samples_sampled_at", "node_samples", ["sampled_at"])
    op.create_index("ix_node_sample_cluster_time", "node_samples", ["cluster_id", "sampled_at"])


def downgrade():
    op.drop_index("ix_node_sample_cluster_time", table_name="node_samples")
    op.drop_index("ix_node_samples_sampled_at", table_name="node_samples")
    op.drop_index("ix_node_samples_cluster_id", table_name="node_samples")
    op.drop_table("node_samples")
