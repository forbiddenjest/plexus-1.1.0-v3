"""Plexus 1.1.0 (rev 3): machine transfer progress and address holding.

* jobs.progress / jobs.stage / jobs.detail: live progress of long jobs, shown in the
  "Machine Transfer in Progress" dialog (0-100 %, current step, bytes copied and rate).
* cluster_ips.held_for: the address a machine had before a transfer stays reserved for
  it until the move completes, so a failed move restores the exact same IPv4.
"""
from alembic import op
import sqlalchemy as sa

revision = "0008_transfer_progress"
down_revision = "0007_node_samples"
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table("jobs") as batch:
        batch.add_column(sa.Column("progress", sa.Integer(), nullable=False, server_default="0"))
        batch.add_column(sa.Column("stage", sa.String(32), nullable=False, server_default=""))
        batch.add_column(sa.Column("detail", sa.String(200), nullable=False, server_default=""))
    with op.batch_alter_table("cluster_ips") as batch:
        batch.add_column(sa.Column("held_for", sa.String(8), nullable=True))
        batch.create_index("ix_cluster_ips_held_for", ["held_for"])


def downgrade():
    with op.batch_alter_table("cluster_ips") as batch:
        batch.drop_index("ix_cluster_ips_held_for")
        batch.drop_column("held_for")
    with op.batch_alter_table("jobs") as batch:
        batch.drop_column("detail")
        batch.drop_column("stage")
        batch.drop_column("progress")
