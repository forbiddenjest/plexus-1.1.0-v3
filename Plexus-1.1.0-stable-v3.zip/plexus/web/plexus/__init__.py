"""Plexus control plane."""

# Single source of truth for the release number: pyproject.toml reads it (dynamic
# version), the footer shows it as v_<version>, and static asset URLs are versioned by it.
__version__ = "1.1.0"
