"""`plexus` command-line tool (run through /usr/local/bin/plexus as the service account).

    sudo plexus help
    sudo plexus status                      panel version, services, nodes, queue
    sudo plexus doctor                      verify every node (health script + libvirt link)
    sudo plexus nodes                       list nodes
    sudo plexus node verify <name|id>       full Verify for one node
    sudo plexus node refresh <name|id>      re-push network rules and private IPs to a node
    sudo plexus machine reset-state <vm-id> set a stuck machine to "unknown" (reconcile recomputes it)
    sudo plexus machine refresh-bandwidth <vm-id>  zero this month's usage, lift a bandwidth suspension
    sudo plexus create-admin <email> [--username NAME]

Service shortcuts (handled by the shell wrapper, not here):
    sudo plexus start|stop|restart|restart-web|restart-clusters|services|logs|follow
Every change made here is written to the activity log with the actor "plexus-cli".
"""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import shutil
import subprocess  # nosec B404 - fixed argv, no shell
import sys

from plexus import __version__

log = logging.getLogger("plexus.cli")
UNITS = ("plexus.service", "plexus-web.service", "plexus-clusters.service")
EXIT_FAIL = 1
EXIT_USAGE = 64
EXIT_NOT_FOUND = 66


def _db():
    from plexus.db import SessionLocal
    return SessionLocal()


def _audit(db, action: str, target: str, result: str = "ok"):
    from plexus.models import AuditLog
    db.add(AuditLog(actor_id=None, action=action, target=str(target)[:160], remote_ip="plexus-cli", result=result))


def _find_cluster(db, ref: str):
    from plexus.models import Cluster
    ref = (ref or "").strip()
    if ref.isdigit() and len(ref) <= 9:
        found = db.get(Cluster, int(ref))
        if found:
            return found
    from plexus.services.clusters import node_unit_alias
    for cluster in db.query(Cluster).all():
        if ref.lower() in {cluster.name.lower(), node_unit_alias(cluster.name)}:
            return cluster
    return None


def _find_machine(db, ref: str):
    from plexus.models import Machine
    ref = (ref or "").strip().lower()
    if len(ref) > 32:
        return None
    return db.get(Machine, ref) or db.query(Machine).filter(Machine.vm_name == ref).first()


def _unit_state(unit: str) -> str:
    systemctl = shutil.which("systemctl")
    if not systemctl:
        return "n/a"
    try:
        result = subprocess.run([systemctl, "is-active", unit], capture_output=True, text=True, timeout=10, check=False)  # nosec B603
        return result.stdout.strip() or "unknown"
    except (OSError, subprocess.SubprocessError):
        return "unknown"


def cmd_status(_args) -> int:
    from plexus.models import Cluster, Job, Machine
    print(f"Plexus Virtualization v_{__version__}")
    for unit in UNITS:
        print(f"  {unit:<28} {_unit_state(unit)}")
    db = _db()
    try:
        clusters = db.query(Cluster).order_by(Cluster.name).all()
        machines = db.query(Machine).all()
        queued = db.query(Job).filter(Job.state.in_(["queued", "running"])).count()
        failed = [m.id for m in machines if m.state == "failed"]
        print(f"Nodes: {len(clusters)}  Machines: {len(machines)} ({sum(1 for m in machines if m.state == 'running')} running)  Jobs pending: {queued}")
        if failed:
            print("Failed machines (see `plexus machine reset-state <vm-id>`): " + ", ".join(failed))
    finally:
        db.close()
    return 0


def cmd_nodes(_args) -> int:
    from plexus.models import Cluster
    from plexus.services.clusters import node_unit_alias
    db = _db()
    try:
        rows = db.query(Cluster).order_by(Cluster.name).all()
        if not rows:
            print("No nodes yet.")
        for c in rows:
            alias = node_unit_alias(c.name) or "-"
            print(f"{c.id:>4}  {c.name:<24} {c.node_ipv4:<16} {getattr(c, 'status', ''):<10} unit: {alias}")
    finally:
        db.close()
    return 0


def _verify(cluster) -> bool:
    from plexus.services.libvirt import CHECK_LABELS, verify_node
    checks, detail = asyncio.run(verify_node(cluster))
    ok = all(checks.values())
    print(f"{cluster.name}: {'OK' if ok else 'FAILED'}")
    for key, passed in checks.items():
        print(f"  [{'ok' if passed else '!!'}] {CHECK_LABELS.get(key, key)}")
    if detail:
        print(f"  detail: {detail}")
    return ok


def cmd_doctor(_args) -> int:
    from plexus.models import Cluster
    db = _db()
    try:
        clusters = db.query(Cluster).order_by(Cluster.name).all()
        if not clusters:
            print("No nodes to check.")
            return 0
        results = [_verify(c) for c in clusters]
    finally:
        db.close()
    return 0 if all(results) else EXIT_FAIL


def cmd_node(args) -> int:
    db = _db()
    try:
        cluster = _find_cluster(db, args.node)
        if cluster is None:
            print(f"No node named {args.node!r}. Try: plexus nodes", file=sys.stderr)
            return EXIT_NOT_FOUND
        if args.action == "verify":
            ok = _verify(cluster)
            _audit(db, "cli.node.verify", cluster.name, "ok" if ok else "failed"); db.commit()
            return 0 if ok else EXIT_FAIL
        from plexus.worker import push_cluster_rules
        try:
            asyncio.run(push_cluster_rules(cluster.id))
        except Exception as exc:  # report the real error text
            from plexus.services.libvirt import error_detail
            print(f"Refresh failed: {error_detail(exc)}", file=sys.stderr)
            _audit(db, "cli.node.refresh", cluster.name, "failed"); db.commit()
            return EXIT_FAIL
        _audit(db, "cli.node.refresh", cluster.name); db.commit()
        print(f"Rules and private IPs pushed to {cluster.name}. For a full node restart run on the node: systemctl restart plexus-refresh")
        return 0
    finally:
        db.close()


def cmd_machine(args) -> int:
    from plexus.models import Job
    from plexus.routes.administrator import RESETTABLE_FROM
    from plexus.services.traffic import reset_traffic
    db = _db()
    try:
        machine = _find_machine(db, args.machine)
        if machine is None:
            print(f"No machine {args.machine!r}", file=sys.stderr)
            return EXIT_NOT_FOUND
        if args.action == "reset-state":
            if db.query(Job.id).filter(Job.machine_id == machine.id, Job.state.in_(["queued", "running"])).first():
                print("An operation is still pending for this machine; wait for it to finish.", file=sys.stderr)
                return EXIT_FAIL
            if machine.state == "suspended":
                print("Suspended machines are released with Unsuspend in the panel.", file=sys.stderr)
                return EXIT_FAIL
            if machine.state not in RESETTABLE_FROM:
                print(f"Machines cannot be reset from {machine.state}.", file=sys.stderr)
                return EXIT_FAIL
            previous = machine.state
            machine.set_power_state("unknown")
            _audit(db, "cli.machine.reset_state", f"{machine.id}:{previous}"); db.commit()
            print(f"{machine.id}: {previous} -> unknown. The clusters service reads the real state within 30 seconds.")
        else:
            reset_traffic(machine)
            _audit(db, "cli.machine.traffic_reset", machine.id); db.commit()
            print(f"{machine.id}: this month's bandwidth usage was reset.")
        return 0
    finally:
        db.close()


def cmd_create_admin(args) -> int:
    from plexus.setup import create_admin
    create_admin(args.email, args.username)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="plexus", description=f"Plexus Virtualization v_{__version__} administration")
    sub = parser.add_subparsers(dest="command")
    sub.add_parser("help")
    sub.add_parser("version")
    sub.add_parser("status").set_defaults(func=cmd_status)
    sub.add_parser("nodes").set_defaults(func=cmd_nodes)
    sub.add_parser("doctor").set_defaults(func=cmd_doctor)
    node = sub.add_parser("node"); node.add_argument("action", choices=["verify", "refresh"]); node.add_argument("node"); node.set_defaults(func=cmd_node)
    machine = sub.add_parser("machine"); machine.add_argument("action", choices=["reset-state", "refresh-bandwidth"]); machine.add_argument("machine"); machine.set_defaults(func=cmd_machine)
    admin = sub.add_parser("create-admin"); admin.add_argument("email"); admin.add_argument("--username", default=""); admin.set_defaults(func=cmd_create_admin)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command in (None, "help"):
        print(__doc__.strip())
        return 0
    if args.command == "version":
        print(f"Plexus Virtualization v_{__version__}")
        return 0
    logging.basicConfig(level=logging.WARNING, format="%(levelname)s %(name)s: %(message)s")
    try:
        return int(args.func(args) or 0)
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    sys.exit(main())
