"""One log format for the web panel, the worker and the CLI.

Lines look like:  2026-11-07 11:53:04 IST INFO    [plexus.worker] job 42 start completed in 1.8s
Timestamps are in the panel time zone (IST by default). systemd's journal keeps its own
timestamps as well; ours make copied log excerpts unambiguous.
"""
import logging
from datetime import datetime
from plexus.timeutil import LOCAL_TZ

FORMAT = "%(asctime)s %(levelname)-7s [%(name)s] %(message)s"


class LocalTimeFormatter(logging.Formatter):
    def formatTime(self, record, datefmt=None):  # noqa: N802 - logging API name
        return datetime.fromtimestamp(record.created, LOCAL_TZ).strftime(datefmt or "%Y-%m-%d %H:%M:%S %Z")


def configure_logging(level: str = "INFO"):
    handler = logging.StreamHandler()
    handler.setFormatter(LocalTimeFormatter(FORMAT))
    root = logging.getLogger()
    root.handlers[:] = [handler]
    root.setLevel(getattr(logging, str(level).upper(), logging.INFO))
    # asyncssh logs every channel open/close at INFO; keep only its warnings.
    logging.getLogger("asyncssh").setLevel(logging.WARNING)
