"""Fresh-process hypervisor link check, used by the worker (and `plexus doctor`).

    python -m plexus.probe <cluster_id>     exit 0 = link works, 3 = node unreachable

A new process has no state from the long-running worker, so "works here, fails there"
proves the worker's own state went bad (see worker.note_reachability).
"""
import sys


def main(argv: list[str]) -> int:
    if len(argv) != 1 or not argv[0].isdigit():
        print("usage: python -m plexus.probe <cluster_id>", file=sys.stderr)
        return 64
    from plexus.db import SessionLocal
    from plexus.models import Cluster
    from plexus.services.libvirt import HypervisorError, check_link
    db = SessionLocal()
    try:
        cluster = db.get(Cluster, int(argv[0]))
        if cluster is None:
            print("no such cluster", file=sys.stderr)
            return 65
        try:
            hostname = check_link(cluster)
        except HypervisorError as exc:
            print(str(exc), file=sys.stderr)
            return 3
        print(hostname)
        return 0
    finally:
        db.close()


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
