"""Administration > Metrics: live capacity per node and for every node combined.

For CPU, memory and disk the page shows three figures against each other:
  available  - what the node has (live from the hypervisor; admin-set capacity otherwise)
  current    - what is in use right now on the node
  allocated  - what is committed to machines (may exceed available for vCPU)
"""
from datetime import timedelta
from sqlalchemy import func
from plexus.models import Cluster, Machine, NodeSample, utcnow
from plexus.services.traffic import combined_series

GB = 1024 ** 3
# A sample older than this is shown as stale ("waiting for the worker").
LIVE_SECONDS = 120


def _pct(part, whole):
    if part is None or not whole:
        return None
    return max(0.0, min(999.0, float(part) / float(whole) * 100.0))


def _resource(available, current, allocated, unit):
    return {"available": available, "current": current, "allocated": allocated, "unit": unit,
            "current_pct": _pct(current, available), "allocated_pct": _pct(allocated, available),
            "free": (available - current) if available is not None and current is not None else None}


def _latest_samples(db, cluster_ids):
    if not cluster_ids:
        return {}
    newest = (db.query(NodeSample.cluster_id, func.max(NodeSample.sampled_at).label("at"))
              .filter(NodeSample.cluster_id.in_(cluster_ids)).group_by(NodeSample.cluster_id).subquery())
    rows = db.query(NodeSample).join(newest, (NodeSample.cluster_id == newest.c.cluster_id) & (NodeSample.sampled_at == newest.c.at)).all()
    return {row.cluster_id: row for row in rows}


def _aware(value):
    return value if value is None or value.tzinfo else value.replace(tzinfo=utcnow().tzinfo)


def node_figures(cluster, sample, machines, now):
    live = bool(sample and sample.sampled_at and (now - _aware(sample.sampled_at)).total_seconds() <= LIVE_SECONDS)
    use = sample if live else None
    threads = (use.cpu_threads if use and use.cpu_threads else cluster.cpu_capacity) or None
    memory_total = (use.memory_total_mb if use and use.memory_total_mb else cluster.memory_capacity_mb) or None
    disk_total = (use.disk_total_bytes / GB) if use and use.disk_total_bytes else (cluster.disk_capacity_gb or None)
    counted = [m for m in machines if m.state != "deleting"]
    cpu_now = (use.cpu_percent / 100.0 * threads) if use and use.cpu_percent is not None and threads else None
    return {
        "cluster": cluster, "live": live, "sampled_at": sample.sampled_at if sample else None,
        "machines": len(counted), "running": sum(1 for m in counted if m.state == "running"),
        "cpu": _resource(threads, cpu_now, sum(m.vcpu for m in counted), "vCores"),
        "memory": _resource(memory_total / 1024 if memory_total else None,
                            (use.memory_used_mb / 1024) if use and use.memory_used_mb is not None else None,
                            sum(m.memory_mb for m in counted) / 1024, "GB"),
        "disk": _resource(disk_total, (use.disk_used_bytes / GB) if use and use.disk_used_bytes is not None else None,
                          float(sum(m.disk_gb for m in counted)), "GB"),
        "net_in_bps": use.net_rx_bps if use else None, "net_out_bps": use.net_tx_bps if use else None,
        "month_in": sum(int(m.traffic_rx_bytes or 0) for m in counted), "month_out": sum(int(m.traffic_tx_bytes or 0) for m in counted),
    }


def _sum(values):
    values = [v for v in values if v is not None]
    return sum(values) if values else None


def combine(nodes):
    combined = {"live": any(n["live"] for n in nodes), "machines": sum(n["machines"] for n in nodes), "running": sum(n["running"] for n in nodes),
                "month_in": sum(n["month_in"] for n in nodes), "month_out": sum(n["month_out"] for n in nodes),
                "net_in_bps": _sum(n["net_in_bps"] for n in nodes), "net_out_bps": _sum(n["net_out_bps"] for n in nodes),
                "sampled_at": max((n["sampled_at"] for n in nodes if n["sampled_at"]), default=None, key=_aware)}
    for key in ("cpu", "memory", "disk"):
        unit = nodes[0][key]["unit"] if nodes else ("vCores" if key == "cpu" else "GB")
        combined[key] = _resource(_sum(n[key]["available"] for n in nodes), _sum(n[key]["current"] for n in nodes),
                                  sum(n[key]["allocated"] or 0 for n in nodes), unit)
    return combined


def metrics_view(db, scope=None, days: int = 30, now=None):
    """scope=None: every node combined plus one card per node; scope=<Cluster>: that node."""
    now = now or utcnow()
    clusters = [scope] if scope is not None else db.query(Cluster).order_by(Cluster.name).all()
    ids = [c.id for c in clusters]
    machines = db.query(Machine).filter(Machine.cluster_id.in_(ids)).all() if ids else []
    by_cluster = {}
    for machine in machines:
        by_cluster.setdefault(machine.cluster_id, []).append(machine)
    samples = _latest_samples(db, ids)
    nodes = [node_figures(c, samples.get(c.id), by_cluster.get(c.id, []), now) for c in clusters]
    summary = nodes[0] if scope is not None and nodes else combine(nodes)
    series = combined_series(db, [m.id for m in machines], days=days, now=now)
    return {"nodes": nodes, "summary": summary, "series": series, "clusters": db.query(Cluster).order_by(Cluster.name).all(),
            "series_total": sum(d["rx"] + d["tx"] for d in series), "live_window": LIVE_SECONDS,
            "since": now - timedelta(days=days - 1)}
