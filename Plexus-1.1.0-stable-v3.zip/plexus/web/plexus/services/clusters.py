"""Cluster enrollment, setup script rendering and node rule assembly."""
import ipaddress, re, secrets, shlex, sys
from datetime import timedelta
from functools import lru_cache
from pathlib import Path
from jinja2 import Environment, FileSystemLoader, StrictUndefined
from plexus.config import settings
from plexus.models import ClusterIP, FirewallRule, Image, Machine, utcnow
from plexus.security import decrypt_node_key, digest_token
from plexus.services.machines import guest_gateway
from plexus.services.network import GUEST_BRIDGE, render_nat_rules, valid_interface

# Node-side files live in the release's top-level node/ directory, never inside the
# web panel package: a cluster node only ever receives what is in node/. The panel reads
# them to render the one-time enrollment script.
NODE_TEMPLATE = "setup.sh.j2"
NODE_FILES = {"node_helper": ("bin/plexus-node", "SCRIPT"), "node_selftest": ("bin/plexus-node-selftest", "SCRIPT"),
              "node_service": ("systemd/plexus-node.service", "UNIT"), "rules_path_unit": ("systemd/plexus-rules.path", "UNIT"),
              "refresh_unit": ("systemd/plexus-node-refresh.service", "UNIT")}


def node_dir_candidates() -> list[Path]:
    """PLEXUS_NODE_DIR, then <install root>/node (/opt/plexus/node next to the venv), then
    the release checkout (plexus/web/../node) for development and tests."""
    found = [Path(settings.node_dir)] if settings.node_dir else []
    found += [Path(sys.prefix).resolve().parent / "node", Path("/opt/plexus/node"), Path(__file__).resolve().parents[3] / "node"]
    return found


@lru_cache(maxsize=1)
def node_dir() -> Path:
    for candidate in node_dir_candidates():
        if (candidate / NODE_TEMPLATE).is_file():
            return candidate
    raise RuntimeError("Node files not found: set PLEXUS_NODE_DIR to the release's node/ directory")


class Shell(str):
    """Text already made safe for its position in the shell script (quoted or heredoc body)."""


_SAFE_TOKEN = re.compile(r"^[A-Za-z0-9_.:/-]*$")


def _finalize(value):
    """Every {{ }} in the setup script must be a quoted value, a heredoc body, an integer or
    a plain token (IP, interface, netmask). Anything else aborts rendering, so a value
    that was not explicitly quoted can never reach the root shell."""
    if isinstance(value, Shell) or (isinstance(value, int) and not isinstance(value, bool)):
        return value
    text = str(value)
    if _SAFE_TOKEN.fullmatch(text):
        return text
    raise ValueError("Unquoted value in node setup script")


def heredoc(text: str, terminator: str) -> Shell:
    if any(line.strip() == terminator for line in text.splitlines()):
        raise ValueError("Heredoc body contains its terminator")
    return Shell(text)


@lru_cache(maxsize=1)
def _env() -> Environment:
    # Shell output, not HTML, so HTML autoescaping does not apply; _finalize enforces shell
    # safety for every interpolation instead.
    env = Environment(loader=FileSystemLoader(str(node_dir())), autoescape=False, undefined=StrictUndefined, keep_trailing_newline=True, finalize=_finalize)  # nosec B701 - shell script, see _finalize  # noqa: S701 - shell template; _finalize gates every value
    env.filters["q"] = lambda value: Shell(shlex.quote(str(value)))
    return env


def node_file(relative: str, terminator: str) -> Shell:
    """A node file embedded verbatim as a quoted heredoc body."""
    return heredoc((node_dir() / relative).read_text(encoding="utf-8"), terminator)

PRIVATE_GUEST_RANGES = tuple(ipaddress.ip_network(n) for n in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"))


def validate_cluster(node_ipv4: str, ssh_port: int, guest_subnet: str, uplink_interface: str):
    try:
        node = ipaddress.ip_address(node_ipv4); subnet = ipaddress.ip_network(guest_subnet, strict=False)
    except ValueError as exc:
        raise ValueError("Enter a valid node IPv4 address and guest subnet") from exc
    if node.version != 4 or subnet.version != 4: raise ValueError("IPv4 is required")
    if node.is_loopback or node.is_multicast or node.is_unspecified or node.is_link_local: raise ValueError("Node IPv4 must be a routable unicast address")
    if not 1 <= ssh_port <= 65535: raise ValueError("Invalid SSH port")
    if not valid_interface(uplink_interface): raise ValueError("Invalid uplink interface")
    if subnet.prefixlen > 28: raise ValueError("Guest subnet is too small")
    if subnet.prefixlen < 16: raise ValueError("Guest subnet must be /16 or smaller")
    # Guests live on a private bridge; a public range would hijack real internet routes.
    if not any(subnet.subnet_of(r) for r in PRIVATE_GUEST_RANGES): raise ValueError("Guest subnet must be a private (RFC 1918) range")
    node_net = ipaddress.ip_interface(f"{node_ipv4}/24").network
    if subnet.overlaps(node_net) or node in subnet: raise ValueError("Guest subnet must not overlap the node's own network")

def issue_setup_token(cluster):
    token = secrets.token_urlsafe(32)
    cluster.setup_token_hash = digest_token(token)
    cluster.setup_token_expires = utcnow() + timedelta(minutes=15)
    return token

def node_subnet(cluster) -> str:
    return str(ipaddress.ip_interface(cluster.node_ipv4 + "/24").network)

def secondary_private_ips(db, cluster) -> list[str]:
    rows = db.query(ClusterIP).filter(ClusterIP.cluster_id == cluster.id).order_by(ClusterIP.id).all()
    return [row.private_ipv4 for row in rows if row.private_ipv4 != cluster.node_ipv4]

def cluster_rules(db, cluster) -> str:
    addresses = db.query(ClusterIP).filter(ClusterIP.cluster_id == cluster.id).order_by(ClusterIP.id).all()
    firewall: dict[str, list] = {}
    rows = (db.query(ClusterIP.guest_ipv4, FirewallRule.protocol, FirewallRule.port)
            .join(Machine, Machine.id == ClusterIP.machine_id).join(FirewallRule, FirewallRule.machine_id == Machine.id)
            .filter(ClusterIP.cluster_id == cluster.id).all())
    for guest, protocol, port in rows:
        firewall.setdefault(guest, []).append((protocol, port))
    return render_nat_rules(addresses, cluster.guest_subnet, cluster.uplink_interface, firewall)

RESERVED_UNIT_NAMES = {"plexus", "plexus-node", "plexus-rules", "plexus-refresh", "plexus-node-refresh", "plexus-web",
                       "plexus-worker", "plexus-clusters", "clusters", "libvirtd", "ssh", "sshd", "network", "networking", "nftables", "systemd", "dbus", "cron", "caddy"}


def node_unit_alias(name: str) -> str:
    """Systemd alias for the node refresh unit, from the cluster name ("Node 01" -> node-01).
    Empty when the name gives nothing usable or would shadow a well-known unit."""
    alias = re.sub(r"[^a-z0-9]+", "-", (name or "").lower()).strip("-")[:60].strip("-")
    if not alias or alias in RESERVED_UNIT_NAMES or alias.startswith(("systemd-", "user@", "plexus")):
        return ""
    return alias


def render_setup_script(db, cluster) -> str:
    from plexus.services.libvirt import panel_public_key
    network = ipaddress.ip_network(cluster.guest_subnet, strict=False)
    images = db.query(Image).filter(Image.active.is_(True)).order_by(Image.id).all()
    return _env().get_template(NODE_TEMPLATE).render(
        uplink=cluster.uplink_interface, bridge=GUEST_BRIDGE, node_prefix=24,
        private_ips=secondary_private_ips(db, cluster), rules=heredoc(cluster_rules(db, cluster), "RULES"),
        panel_key=panel_public_key(decrypt_node_key(cluster.ssh_key_encrypted)),
        gateway=guest_gateway(cluster.guest_subnet), guest_prefix=network.prefixlen, guest_netmask=str(network.netmask),
        images=[{"id": int(i.id), "kind": i.kind, "url": i.url, "sha": i.checksum} for i in images],
        node_alias=node_unit_alias(cluster.name),
        **{name: node_file(path, terminator) for name, (path, terminator) in NODE_FILES.items()},
    )
