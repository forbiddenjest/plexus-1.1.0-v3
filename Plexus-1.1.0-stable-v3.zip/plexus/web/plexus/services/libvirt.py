"""All libvirt and node-SSH access is confined to this service.

Every remote command is a fixed argv template; the only variable parts are values
validated here (vm names, integer image ids, IPv4 addresses, sizes).
"""
import asyncio, hashlib, ipaddress, json, logging, os, re, secrets, shlex, shutil, tempfile
from contextlib import contextmanager
from urllib.parse import urlencode
import asyncssh
import libvirt
from passlib.hash import sha512_crypt
from plexus.security import decrypt_node_key
from plexus.config import settings

log = logging.getLogger("plexus.hypervisor")

class HypervisorError(RuntimeError):
    """A node or hypervisor operation failed. The message carries the real cause."""

class NotStartedError(HypervisorError):
    """Raised before anything on the node was changed: the machine is exactly as it was."""

VM_RE = re.compile(r"^vm[0-9]+$")
# Node-side state lives in its own directory (not the panel's /var/lib/plexus), so a
# panel and a node on the same VM never fight over ownership or mode of one directory.
STATE_DIR = "/var/lib/plexus-node"
NODE_HELPER = "/usr/local/sbin/plexus-node"
STAGED_RULES = f"{STATE_DIR}/staged/rules.nft"
STAGED_IPS = f"{STATE_DIR}/staged/private_ips"
NETWORK_NAME = "plexus"
RULES_APPLY_TIMEOUT = 30
CPU_MODES = ("host-passthrough", "host-model")
OPERATION_INVALID = getattr(libvirt, "VIR_ERR_OPERATION_INVALID", 55)


def _libvirt_error_handler(_ctx, error):
    """libvirt prints every error to stderr by default (the bare 'libvirt: ...' lines).
    Callers log failures with context instead; keep the raw text at debug level."""
    try:
        log.debug("libvirt: %s", error[2])
    except Exception:  # nosec B110 - logging must never raise
        pass


if hasattr(libvirt, "registerErrorHandler"):
    libvirt.registerErrorHandler(_libvirt_error_handler, None)


def error_detail(exc: BaseException) -> str:
    """The real error text (libvirt's own message when there is one), one line, bounded."""
    text = ""
    getter = getattr(exc, "get_error_message", None)
    if callable(getter):
        try:
            text = getter() or ""
        except Exception:
            text = ""
    text = " ".join((text or str(exc) or type(exc).__name__).split())
    return text[:300]


def _error_code(exc) -> int | None:
    getter = getattr(exc, "get_error_code", None)
    try:
        return int(getter()) if callable(getter) else None
    except Exception:
        return None


def _fail(message: str, exc: BaseException, cls=HypervisorError) -> HypervisorError:
    """Log and wrap a failure without hiding its cause (A4: generic messages hid it)."""
    detail = error_detail(exc)
    log.error("%s: %s", message, detail)
    return cls(f"{message}: {detail}")

def _vm(name: str) -> str:
    if not VM_RE.fullmatch(name or ""): raise HypervisorError("Invalid VM name")
    return name

def _machine_dir(vm_name: str) -> str: return f"{STATE_DIR}/machines/{_vm(vm_name)}"
def base_image_path(image_id: int) -> str: return f"{STATE_DIR}/images/{int(image_id)}.img"
def iso_path(image_id: int) -> str: return f"{STATE_DIR}/isos/{int(image_id)}.iso"
def _mac(vm_name: str) -> str:
    digest = hashlib.sha256(vm_name.encode()).digest()
    return "52:54:00:%02x:%02x:%02x" % (digest[0], digest[1], digest[2])

# ---------- node identity / connections ----------

def _known_hosts_line(cluster) -> str:
    if not cluster.node_host_key:
        raise HypervisorError("This node has no verified SSH host key")
    host_line = cluster.node_host_key.strip().split()
    if len(host_line) < 2:
        raise HypervisorError("Stored node host key is invalid")
    expected_name = f"[{cluster.node_ipv4}]:{cluster.ssh_port}" if cluster.ssh_port != 22 else cluster.node_ipv4
    return f"{expected_name} {host_line[-2]} {host_line[-1]}\n"

def _write_private(path: str, content: str):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        handle.write(content)

@contextmanager
def _node_identity_files(cluster):
    """Per-call private copy of the node key and pinned host key.

    asyncssh never needs these (keys stay in memory). libvirt's SSH transports only
    accept file paths, so the decrypted key exists on disk for the duration of
    libvirt.open() only, in a fresh 0700 directory unique to this call, and is removed
    as soon as the connection is authenticated. Concurrent calls for different
    clusters therefore never share or overwrite a file.
    """
    known_hosts = _known_hosts_line(cluster)
    base = settings.runtime_dir or None
    directory = tempfile.mkdtemp(prefix=f"node{int(cluster.id)}-", dir=base)  # mode 0700
    try:
        key_path, hosts_path = os.path.join(directory, "key"), os.path.join(directory, "known_hosts")
        _write_private(key_path, decrypt_node_key(cluster.ssh_key_encrypted))
        _write_private(hosts_path, known_hosts)
        yield key_path, hosts_path
    finally:
        shutil.rmtree(directory, ignore_errors=True)

def panel_private_key(cluster):
    return asyncssh.import_private_key(decrypt_node_key(cluster.ssh_key_encrypted))

def panel_public_key(private_key_text: str) -> str:
    return asyncssh.import_private_key(private_key_text).export_public_key().decode().strip()

async def _node_connection(cluster):
    try:
        return await asyncssh.connect(cluster.node_ipv4, port=cluster.ssh_port, username="panel",
            client_keys=[panel_private_key(cluster)],
            known_hosts=asyncssh.import_known_hosts(_known_hosts_line(cluster)), connect_timeout=8)
    except HypervisorError: raise
    except Exception as exc:
        raise _fail(f"SSH connection to node {cluster.name} ({cluster.node_ipv4}:{cluster.ssh_port}) failed", exc) from exc

async def _run(connection, argv: list[str], timeout: int = 120):
    result = await connection.run(shlex.join(argv), check=False, timeout=timeout)
    if result.exit_status != 0:
        stderr = " ".join(str(result.stderr or "").split())[:200]
        log.warning("Node command %s exited %s: %s", argv[0], result.exit_status, stderr or "no output")
        raise HypervisorError(f"Node command failed: {argv[0]} (exit {result.exit_status}){': ' + stderr if stderr else ''}")
    return result.stdout or ""

async def _write(connection, path: str, content: str, mode: int = 0o600):
    async with connection.start_sftp_client() as sftp:
        async with sftp.open(path, "w") as handle:
            await handle.write(content)
        await sftp.chmod(path, mode)

def libvirt_uri(cluster, key_path: str, hosts_path: str) -> str:
    """qemu+libssh, not qemu+ssh: only the libssh/libssh2 transports honour known_hosts and
    known_hosts_verify. qemu+ssh shells out to the OS ssh binary, which ignores both and
    consults ~/.ssh/known_hosts instead. known_hosts_verify=normal refuses unknown or
    changed host keys; sshauth=privkey stops it falling back to agent/password prompts."""
    ipaddress.IPv4Address(cluster.node_ipv4)
    query = urlencode({"keyfile": key_path, "known_hosts": hosts_path, "known_hosts_verify": "normal", "sshauth": "privkey"})
    return f"qemu+libssh://panel@{cluster.node_ipv4}:{int(cluster.ssh_port)}/system?{query}"

def _connect(cluster):
    """A new libvirt connection per call; callers close it. Nothing is cached between
    calls or worker cycles, so a broken transport can never be reused."""
    with _node_identity_files(cluster) as (key_path, hosts_path):
        try: return libvirt.open(libvirt_uri(cluster, key_path, hosts_path))
        except libvirt.libvirtError as exc:
            raise _fail(f"Hypervisor connection to {getattr(cluster, 'name', 'node')} failed", exc) from exc

def check_link(cluster) -> str:
    """Open the same qemu+libssh link every machine action uses; returns the node hostname."""
    conn = _connect(cluster)
    try:
        try: return str(conn.getHostname())
        except libvirt.libvirtError as exc: raise _fail(f"Hypervisor on {cluster.name} did not answer", exc) from exc
    finally: conn.close()

# ---------- power / status ----------

def _crashed(state: int, reason: int) -> bool:
    return state == getattr(libvirt, "VIR_DOMAIN_CRASHED", 6) or (state == getattr(libvirt, "VIR_DOMAIN_SHUTOFF", 5) and reason == getattr(libvirt, "VIR_DOMAIN_SHUTOFF_CRASHED", 3))

# create() and destroy() are synchronous; shutdown() and reboot() only ask the guest
# (ACPI) and return immediately, so they report the transition and the reconcile loop
# confirms the final state.
POWER_RESULTS = {"start": "running", "force-stop": "stopped", "stop": "stopping", "restart": "restarting"}

def power_action(cluster, vm_name: str, action: str):
    if action not in POWER_RESULTS:
        raise HypervisorError("Unsupported machine action")
    name = _vm(vm_name)
    conn = _connect(cluster)
    try:
        try:
            domain = conn.lookupByName(name)
        except libvirt.libvirtError as exc:
            raise _fail(f"Machine {name} is not defined on the node", exc) from exc
        try:
            if action == "start": domain.create()
            elif action == "stop": domain.shutdown()
            elif action == "restart": domain.reboot(0)
            else: domain.destroy()
        except libvirt.libvirtError as exc:
            # Already in the requested state (boot on a running guest, stop on a stopped
            # one) is success, not a failed job.
            if _error_code(exc) == OPERATION_INVALID:
                try: active = bool(domain.isActive())
                except libvirt.libvirtError: active = None
                if action == "start" and active is True:
                    log.info("%s is already running; boot treated as done", name)
                    return "running"
                if action in {"stop", "force-stop"} and active is False:
                    log.info("%s is already stopped; %s treated as done", name, action)
                    return "stopped"
            raise _fail(f"Machine action '{action}' failed for {name}", exc) from exc
        return POWER_RESULTS[action]
    finally: conn.close()

def domain_status(cluster, vm_name: str, conn=None):
    """Pass an open conn to reuse one libvirt connection for many domains."""
    own = conn is None
    conn = conn or _connect(cluster)
    try:
        state, reason = conn.lookupByName(_vm(vm_name)).state()[:2]
        if state == libvirt.VIR_DOMAIN_RUNNING: return "running"
        return "crashed" if _crashed(state, reason) else "stopped"
    except libvirt.libvirtError: return "unknown"
    finally:
        if own: conn.close()

def open_connection(cluster):
    """Public handle for callers that batch several domains on one node per cycle."""
    return _connect(cluster)

# ---------- domain definition ----------

def _kbytes_per_second(mbps) -> int:
    """libvirt <bandwidth> uses KiB/s-ish 'kilobytes per second'; 1 Mbps = 125 KB/s."""
    return max(0, int(mbps or 0)) * 125

def bandwidth_xml(spec: dict) -> str:
    """Per-port speed caps. inbound = traffic towards the guest, outbound = from the guest."""
    parts = []
    for direction, key in (("inbound", "speed_in_mbps"), ("outbound", "speed_out_mbps")):
        rate = _kbytes_per_second(spec.get(key))
        if rate:
            parts.append(f"<{direction} average='{rate}' peak='{rate}' burst='{max(1024, rate // 8)}'/>")
    return f"<bandwidth>{''.join(parts)}</bandwidth>" if parts else ""

def domain_xml(spec: dict) -> str:
    vm = _vm(spec["vm_name"]); directory = _machine_dir(vm)
    guest_ip = str(ipaddress.IPv4Address(spec["guest_ip"]))
    iso = spec.get("iso_image_id")
    boot_cdrom = spec.get("boot_device") == "cdrom" and iso
    iso_source = f"<source file='{iso_path(iso)}'/>" if iso else ""
    # host-passthrough shows guests the real CPU model (not e.g. "EPYC-Milan"). Moves
    # between nodes are cold boots, so they work with either mode.
    cpu_mode = spec.get("cpu_mode") if spec.get("cpu_mode") in CPU_MODES else CPU_MODES[0]
    return f"""<domain type='kvm'>
  <name>{vm}</name>
  <memory unit='MiB'>{int(spec['memory_mb'])}</memory>
  <vcpu>{int(spec['vcpu'])}</vcpu>
  <os><type arch='x86_64' machine='q35'>hvm</type></os>
  <features><acpi/><apic/></features>
  <cpu mode='{cpu_mode}'/>
  <on_poweroff>destroy</on_poweroff><on_reboot>restart</on_reboot><on_crash>destroy</on_crash>
  <devices>
    <disk type='file' device='disk'><driver name='qemu' type='qcow2' discard='unmap'/><source file='{directory}/disk.qcow2'/><target dev='vda' bus='virtio'/><boot order='{2 if boot_cdrom else 1}'/></disk>
    <disk type='file' device='cdrom'><driver name='qemu' type='raw'/><source file='{directory}/seed.iso'/><target dev='sda' bus='sata'/><readonly/></disk>
    <disk type='file' device='cdrom'><driver name='qemu' type='raw'/>{iso_source}<target dev='sdb' bus='sata'/><readonly/><boot order='{1 if boot_cdrom else 2}'/></disk>
    <interface type='network'><source network='{NETWORK_NAME}'/><mac address='{_mac(vm)}'/><model type='virtio'/><port isolated='yes'/>{bandwidth_xml(spec)}<filterref filter='clean-traffic'><parameter name='IP' value='{guest_ip}'/></filterref></interface>
    <channel type='unix'><target type='virtio' name='org.qemu.guest_agent.0'/></channel>
    <serial type='pty'/><console type='pty'/>
    <graphics type='vnc' port='-1' autoport='yes' listen='127.0.0.1'/>
    <video><model type='virtio'/></video>
    <memballoon model='virtio'><stats period='10'/></memballoon>
  </devices>
</domain>"""

def _cloud_init(spec: dict, password: str | None, authorized_key: str, host_key_private: str, host_key_public: str):
    """password=None (node transfer) leaves the existing guest password untouched."""
    network = ipaddress.ip_network(spec["guest_subnet"], strict=False)
    guest_ip = ipaddress.ip_address(spec["guest_ip"]); gateway = ipaddress.ip_address(spec["gateway"])
    if guest_ip not in network or gateway not in network: raise HypervisorError("Guest address outside subnet")
    account = {"name": "ubuntu", "groups": ["sudo"], "shell": "/bin/bash", "sudo": "ALL=(ALL) NOPASSWD:ALL",
               "lock_passwd": False, "ssh_authorized_keys": [authorized_key]}  # nosec B105 - cloud-init flag, not a password
    if password is not None:
        account["hashed_passwd"] = sha512_crypt.hash(password)
    user_data = {
        "hostname": spec["hostname"], "manage_etc_hosts": True,
        "users": [account],
        "ssh_pwauth": True, "ssh_deletekeys": True,
        "ssh_keys": {"ed25519_private": host_key_private, "ed25519_public": host_key_public},
        "package_update": True, "packages": ["qemu-guest-agent"],
        "runcmd": [["systemctl", "enable", "--now", "qemu-guest-agent"]],
    }
    network_config = {"version": 2, "ethernets": {"eth0": {
        "match": {"macaddress": _mac(spec["vm_name"])}, "set-name": "eth0",
        "addresses": [f"{guest_ip}/{network.prefixlen}"], "routes": [{"to": "default", "via": str(gateway)}],
        "nameservers": {"addresses": ["1.1.1.1", "8.8.8.8"]}}}}
    meta = {"instance-id": f"{spec['vm_name']}-{secrets.token_hex(4)}", "local-hostname": spec["hostname"]}
    # JSON is valid YAML, which avoids hand-escaping user-visible values.
    return "#cloud-config\n" + json.dumps(user_data), json.dumps(network_config), json.dumps(meta)

def new_guest_host_key():
    key = asyncssh.generate_private_key("ssh-ed25519")
    return key.export_private_key().decode(), key.export_public_key().decode().strip()

async def _build_disk_and_seed(connection, spec: dict, password: str, authorized_key: str, host_private: str, host_public: str):
    vm = _vm(spec["vm_name"]); directory = _machine_dir(vm)
    base = base_image_path(spec["image_id"]); size = f"{int(spec['disk_gb'])}G"
    await _run(connection, ["test", "-r", base])
    # 0751: libvirt-qemu is not in the panel/libvirt group and must be able to traverse to
    # the disk files; libvirt's dynamic ownership relabels the files themselves.
    await _run(connection, ["install", "-d", "-m", "0751", directory])
    await _run(connection, ["rm", "-f", "--", f"{directory}/disk.qcow2", f"{directory}/seed.iso"])
    await _run(connection, ["qemu-img", "create", "-q", "-f", "qcow2", "-F", "qcow2", "-b", base, f"{directory}/disk.qcow2", size], timeout=300)
    await _write_seed(connection, spec, password, authorized_key, host_private, host_public)

async def _write_seed(connection, spec: dict, password, authorized_key: str, host_private: str, host_public: str):
    directory = _machine_dir(spec["vm_name"])
    user_data, network_config, meta = _cloud_init(spec, password, authorized_key, host_private, host_public)
    await _write(connection, f"{directory}/user-data", user_data)
    await _write(connection, f"{directory}/network-config", network_config)
    await _write(connection, f"{directory}/meta-data", meta)
    try:
        await _run(connection, ["cloud-localds", "-N", f"{directory}/network-config", f"{directory}/seed.iso", f"{directory}/user-data", f"{directory}/meta-data"])
    finally:
        await _run(connection, ["rm", "-f", "--", f"{directory}/user-data", f"{directory}/network-config", f"{directory}/meta-data"])

def _define_and_start(cluster, spec: dict):
    conn = _connect(cluster)
    try:
        domain = conn.defineXML(domain_xml(spec))
        domain.setAutostart(1)
        domain.create()
    except libvirt.libvirtError as exc: raise _fail(f"Machine definition failed for {spec['vm_name']}", exc) from exc
    finally: conn.close()

def _destroy_and_undefine(cluster, vm_name: str):
    """Raises NotStartedError when the guest was left untouched (e.g. node unreachable)."""
    try:
        conn = _connect(cluster)
    except HypervisorError as exc:
        raise NotStartedError(str(exc)) from exc
    destroyed = False
    try:
        try: domain = conn.lookupByName(_vm(vm_name))
        except libvirt.libvirtError: return
        if domain.isActive():
            domain.destroy()
        destroyed = True
        domain.undefineFlags(libvirt.VIR_DOMAIN_UNDEFINE_MANAGED_SAVE | libvirt.VIR_DOMAIN_UNDEFINE_SNAPSHOTS_METADATA)
    except libvirt.libvirtError as exc:
        raise _fail(f"Machine removal failed for {vm_name}", exc, HypervisorError if destroyed else NotStartedError) from exc
    finally: conn.close()

# ---------- lifecycle ----------

async def provision(cluster, spec: dict, password: str) -> str:
    """Create overlay + seed, define and boot. Returns the guest host public key to pin."""
    host_private, host_public = new_guest_host_key()
    authorized_key = panel_public_key(decrypt_node_key(cluster.ssh_key_encrypted))
    connection = await _node_connection(cluster)
    try: await _build_disk_and_seed(connection, spec, password, authorized_key, host_private, host_public)
    finally: connection.close()
    await asyncio.to_thread(_define_and_start, cluster, spec)
    return host_public

async def rebuild_preflight(cluster, spec: dict):
    """Everything a rebuild needs, checked before the old guest is touched. A failure here
    raises NotStartedError so the machine keeps its previous state (A5)."""
    try:
        await asyncio.to_thread(check_link, cluster)
        connection = await _node_connection(cluster)
        try: await _run(connection, ["test", "-r", base_image_path(spec["image_id"])])
        finally: connection.close()
    except NotStartedError: raise
    except HypervisorError as exc:
        raise NotStartedError(f"Rebuild did not start, the machine was not changed: {exc}") from exc

async def rebuild(cluster, spec: dict, password: str) -> str:
    await rebuild_preflight(cluster, spec)
    await asyncio.to_thread(_destroy_and_undefine, cluster, spec["vm_name"])
    return await provision(cluster, spec, password)

async def delete(cluster, vm_name: str):
    await asyncio.to_thread(_destroy_and_undefine, cluster, vm_name)
    connection = await _node_connection(cluster)
    try: await _run(connection, ["rm", "-rf", "--", _machine_dir(vm_name)])
    finally: connection.close()

# ---------- resize / speed ----------

def redefine(cluster, spec: dict):
    """Persist vCPU, memory and port-speed changes; live-apply the speed caps if running."""
    conn = _connect(cluster)
    try:
        conn.defineXML(domain_xml(spec))
        domain = conn.lookupByName(_vm(spec["vm_name"]))
        if domain.isActive() and hasattr(domain, "setInterfaceParameters"):
            params = {}
            for prefix, key in (("inbound", "speed_in_mbps"), ("outbound", "speed_out_mbps")):
                rate = _kbytes_per_second(spec.get(key))
                params.update({f"{prefix}.average": rate, f"{prefix}.peak": rate, f"{prefix}.burst": max(1024, rate // 8) if rate else 0})
            try: domain.setInterfaceParameters(_mac(spec["vm_name"]), params, libvirt.VIR_DOMAIN_AFFECT_LIVE)
            except libvirt.libvirtError as exc:  # persistent config still applies on next boot
                log.info("Live speed update for %s not applied (%s); it applies on next boot", spec["vm_name"], error_detail(exc))
    except libvirt.libvirtError as exc: raise _fail(f"Machine update failed for {spec['vm_name']}", exc) from exc
    finally: conn.close()

async def grow_disk(cluster, vm_name: str, disk_gb: int):
    """Grow only (shrinking would destroy data). Guest growpart extends the root fs on boot."""
    connection = await _node_connection(cluster)
    try: await _run(connection, ["qemu-img", "resize", "-q", f"{_machine_dir(vm_name)}/disk.qcow2", f"{int(disk_gb)}G"], timeout=300)
    finally: connection.close()

def _is_active(cluster, vm_name: str) -> bool:
    conn = _connect(cluster)
    try:
        try: return bool(conn.lookupByName(_vm(vm_name)).isActive())
        except libvirt.libvirtError: return False
    finally: conn.close()

# ---------- transfer between nodes ----------
#
# A transfer never exposes guest data: the disk is streamed source -> panel -> target over
# the two pinned, key-authenticated SSH sessions (encrypted end to end, never written to
# the panel's disk), every scratch file lives in a 0700 directory only the panel account
# can enter, and the copy is accepted only when the SHA-256 computed on the source, the
# SHA-256 of the bytes that crossed the panel and the SHA-256 on the target all match and
# qemu-img confirms the image is consistent. The source copy is removed only after the
# machine has booted on the target.

TRANSFER_CHUNK = 4 * 1024 * 1024
SCRATCH = ".transfer"      # on the source: the flattened image being sent
INCOMING = ".incoming"     # on the target: the image being received
# Room the target must have beyond the image itself (qemu metadata, seed, logs).
TRANSFER_HEADROOM = 1024 ** 3
_QEMU_PROGRESS = re.compile(rb"\((\d+(?:\.\d+)?)/100%\)")


async def _report(progress, fraction: float, detail: str = ""):
    if progress is not None:
        await progress(max(0.0, min(1.0, fraction)), detail)


def _human(value: float) -> str:
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if value < 1024 or unit == "TiB":
            return f"{value:.0f} {unit}" if unit == "B" else f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} TiB"


def _domain_defined(cluster, vm_name: str) -> bool:
    conn = _connect(cluster)
    try:
        try:
            conn.lookupByName(_vm(vm_name))
            return True
        except libvirt.libvirtError:
            return False
    finally: conn.close()


async def _free_bytes(connection) -> int:
    out = await _run(connection, ["df", "-B1", "--output=avail", STATE_DIR], timeout=15)
    lines = [line.strip() for line in out.strip().splitlines()[1:] if line.strip()]
    if not lines or not lines[-1].isdigit():
        raise HypervisorError("Unexpected df output")
    return int(lines[-1])


async def _disk_info(connection, path: str) -> dict:
    raw = await _run(connection, ["qemu-img", "info", "--output=json", "-U", path], timeout=60)
    try:
        info = json.loads(raw)
        return {"virtual": int(info.get("virtual-size") or 0), "actual": int(info.get("actual-size") or 0)}
    except (ValueError, TypeError) as exc:
        raise HypervisorError("Could not read the machine disk information") from exc


async def transfer_preflight(source, target, vm_name: str, disk_gb: int, iso_image_id=None) -> dict:
    """Everything a transfer needs, checked before the machine is touched. Any failure
    raises NotStartedError: the machine keeps running on the source exactly as it was."""
    vm = _vm(vm_name); directory = _machine_dir(vm)
    try:
        for cluster in (source, target):
            await asyncio.to_thread(check_link, cluster)
        if await asyncio.to_thread(_domain_defined, target, vm):
            raise HypervisorError(f"{target.name} already has a machine named {vm}")
        src = await _node_connection(source)
        try:
            await _run(src, ["test", "-r", f"{directory}/disk.qcow2"])
            info = await _disk_info(src, f"{directory}/disk.qcow2")
            await _run(src, ["rm", "-rf", "--", f"{directory}/{SCRATCH}"])  # stale scratch from an interrupted attempt
            source_free = await _free_bytes(src)
        finally: src.close()
        # The flattened image holds overlay + base data: never more than the virtual disk.
        estimate = min(max(info["virtual"], int(disk_gb) * 1024 ** 3), info["actual"] + 4 * TRANSFER_HEADROOM)
        if source_free < estimate:
            raise HypervisorError(f"{source.name} has only {_human(source_free)} free for the transfer snapshot (needs about {_human(estimate)})")
        dst = await _node_connection(target)
        try:
            await _run(dst, ["install", "-d", "-m", "0751", directory])
            await _run(dst, ["rm", "-rf", "--", f"{directory}/{INCOMING}", f"{directory}/disk.qcow2", f"{directory}/seed.iso"])
            target_free = await _free_bytes(dst)
            if iso_image_id:
                await _run(dst, ["test", "-r", iso_path(iso_image_id)])
        finally: dst.close()
        if target_free < estimate + TRANSFER_HEADROOM:
            raise HypervisorError(f"{target.name} has only {_human(target_free)} free; the disk needs about {_human(estimate + TRANSFER_HEADROOM)}")
        return {"virtual": info["virtual"], "actual": info["actual"], "estimate": estimate, "target_free": target_free}
    except NotStartedError: raise
    except HypervisorError as exc:
        raise NotStartedError(f"Transfer did not start, the machine was not changed: {exc}") from exc


async def stop_for_transfer(cluster, vm_name: str, grace: int = 120, progress=None):
    """Graceful ACPI shutdown (a consistent filesystem), forced only after the grace period."""
    if not await asyncio.to_thread(_is_active, cluster, vm_name):
        await _report(progress, 1.0, "Machine is already powered off")
        return
    try: await asyncio.to_thread(power_action, cluster, vm_name, "stop")
    except HypervisorError: pass
    loop = asyncio.get_running_loop(); started = loop.time(); deadline = started + grace
    while loop.time() < deadline:
        if not await asyncio.to_thread(_is_active, cluster, vm_name):
            await _report(progress, 1.0, "Guest shut down cleanly")
            return
        await _report(progress, (loop.time() - started) / grace, "Waiting for the guest to shut down")
        await asyncio.sleep(3)
    await asyncio.to_thread(power_action, cluster, vm_name, "force-stop")
    await _report(progress, 1.0, "Guest powered off after the grace period")


async def _run_with_progress(connection, argv: list[str], progress, label: str, timeout: int):
    """Run a qemu-img command with -p and turn its percentage output into progress."""
    process = await connection.create_process(shlex.join(argv), encoding=None, stderr=asyncssh.STDOUT)
    loop = asyncio.get_running_loop(); deadline = loop.time() + timeout
    tail = b""
    try:
        while True:
            chunk = await asyncio.wait_for(process.stdout.read(4096), timeout=max(1.0, deadline - loop.time()))
            if not chunk:
                break
            tail = (tail + chunk)[-512:]
            found = _QEMU_PROGRESS.findall(tail)
            if found:
                await _report(progress, float(found[-1]) / 100.0, label)
        await process.wait_closed()
    except asyncio.TimeoutError as exc:
        process.close()
        raise HypervisorError(f"{argv[0]} timed out") from exc
    if process.exit_status != 0:
        text = " ".join(_QEMU_PROGRESS.sub(b"", tail).decode(errors="replace").split())[:200]
        raise HypervisorError(f"Node command failed: {argv[0]} (exit {process.exit_status}){': ' + text if text else ''}")


async def snapshot_disk(source, vm_name: str, progress=None) -> int:
    """Flatten the (stopped) machine's overlay into one self-contained image in a private
    scratch directory. The target may not have the same base image, so it is never needed
    there. Returns the image size in bytes."""
    vm = _vm(vm_name); directory = _machine_dir(vm); scratch = f"{directory}/{SCRATCH}"
    src = await _node_connection(source)
    try:
        await _run(src, ["install", "-d", "-m", "0700", scratch])
        await _run_with_progress(src, ["qemu-img", "convert", "-p", "-O", "qcow2", f"{directory}/disk.qcow2", f"{scratch}/disk.qcow2"],
                                 progress, "Flattening the disk into a transfer image", timeout=7200)
        await _run(src, ["chmod", "0600", f"{scratch}/disk.qcow2"])
        size = (await _run(src, ["stat", "-c", "%s", f"{scratch}/disk.qcow2"], timeout=15)).strip()
        if not size.isdigit():
            raise HypervisorError("Could not read the transfer image size")
        return int(size)
    finally: src.close()


async def copy_disk(source, target, vm_name: str, size: int, progress=None) -> str:
    """Stream the snapshot to the target and verify it three ways. Returns the SHA-256."""
    vm = _vm(vm_name); directory = _machine_dir(vm)
    flat, incoming = f"{directory}/{SCRATCH}/disk.qcow2", f"{directory}/{INCOMING}"
    part = f"{incoming}/disk.qcow2.part"
    src = await _node_connection(source)
    try:
        dst = await _node_connection(target)
        try:
            free = await _free_bytes(dst)
            if free < size + TRANSFER_HEADROOM:
                raise HypervisorError(f"{target.name} has only {_human(free)} free; the transfer image is {_human(size)}")
            await _run(dst, ["install", "-d", "-m", "0700", incoming])
            await _run(dst, ["install", "-m", "0600", "/dev/null", part])
            # The source hashes its file while the same bytes are streamed and hashed here.
            source_digest = asyncio.ensure_future(_run(src, ["sha256sum", "--", flat], timeout=7200))
            reader = await src.create_process(shlex.join(["cat", "--", flat]), encoding=None)
            writer = await dst.create_process(shlex.join(["dd", f"of={part}", "bs=4M", "conv=notrunc,fsync", "status=none"]), encoding=None)
            stream_hash = hashlib.sha256()
            sent = 0
            loop = asyncio.get_running_loop(); started = last = loop.time()
            try:
                while True:
                    chunk = await reader.stdout.read(TRANSFER_CHUNK)
                    if not chunk: break
                    stream_hash.update(chunk)
                    writer.stdin.write(chunk)
                    await writer.stdin.drain()
                    sent += len(chunk)
                    now = loop.time()
                    if now - last >= 0.5 or sent >= size:
                        last = now
                        rate = sent / max(now - started, 0.001)
                        await _report(progress, sent / size if size else 1.0, f"{_human(sent)} of {_human(size)} · {_human(rate)}/s")
                writer.stdin.write_eof()
                await writer.wait_closed(); await reader.wait_closed()
            except BaseException:
                source_digest.cancel(); reader.close(); writer.close()
                raise
            expected = (await source_digest).split()[0]
            if reader.exit_status != 0 or writer.exit_status != 0:
                raise HypervisorError("Disk stream failed")
            if sent != size or stream_hash.hexdigest() != expected:
                raise HypervisorError("Disk stream was corrupted in transit")
            actual = (await _run(dst, ["sha256sum", "--", part], timeout=7200)).split()[0]
            if actual != expected:
                raise HypervisorError("Transferred disk failed its checksum")
            await _run(dst, ["qemu-img", "check", "-q", part], timeout=1800)
            await _run(dst, ["mv", "-f", "--", part, f"{directory}/disk.qcow2"])
            await _run(dst, ["rm", "-rf", "--", incoming])
            return expected
        finally: dst.close()
    finally: src.close()


async def remove_scratch(source, vm_name: str):
    src = await _node_connection(source)
    try: await _run(src, ["rm", "-rf", "--", f"{_machine_dir(vm_name)}/{SCRATCH}"])
    finally: src.close()


def _define_and_ensure_running(cluster, spec: dict):
    """Idempotent define + start: a resumed transfer may find the guest already running."""
    conn = _connect(cluster)
    try:
        domain = conn.defineXML(domain_xml(spec))
        domain.setAutostart(1)
        if not domain.isActive():
            domain.create()
    except libvirt.libvirtError as exc: raise _fail(f"Machine definition failed for {spec['vm_name']}", exc) from exc
    finally: conn.close()


async def boot_transferred(target, spec: dict) -> str:
    """New seed (new address, new pinned host key, password unchanged), define, start.
    The seed carries a new instance id, so cloud-init applies the new network
    configuration (address, prefix, gateway) on this first boot on the target."""
    host_private, host_public = new_guest_host_key()
    authorized_key = panel_public_key(decrypt_node_key(target.ssh_key_encrypted))
    connection = await _node_connection(target)
    try: await _write_seed(connection, spec, None, authorized_key, host_private, host_public)
    finally: connection.close()
    await asyncio.to_thread(_define_and_ensure_running, target, spec)
    return host_public


def _guest_addresses(cluster, vm_name: str) -> set[str]:
    conn = _connect(cluster)
    try:
        domain = conn.lookupByName(_vm(vm_name))
        source = getattr(libvirt, "VIR_DOMAIN_INTERFACE_ADDRESSES_SRC_AGENT", 1)
        found = set()
        for iface in (domain.interfaceAddresses(source, 0) or {}).values():
            for address in iface.get("addrs") or []:
                if address.get("type") == getattr(libvirt, "VIR_IP_ADDR_TYPE_IPV4", 0):
                    found.add(str(address.get("addr")))
        return found
    except libvirt.libvirtError:
        return set()
    finally: conn.close()


async def wait_for_guest_address(cluster, vm_name: str, guest_ip: str, timeout: int = 150, progress=None) -> bool:
    """True once the guest agent reports the new address (best effort: an image without
    the agent simply times out; the network configuration is still applied by cloud-init)."""
    expected = str(ipaddress.IPv4Address(guest_ip))
    loop = asyncio.get_running_loop(); started = loop.time()
    while loop.time() - started < timeout:
        if expected in await asyncio.to_thread(_guest_addresses, cluster, vm_name):
            return True
        await _report(progress, (loop.time() - started) / timeout, f"Waiting for the guest to confirm {expected}")
        await asyncio.sleep(5)
    return False


async def discard_copy(cluster, vm_name: str):
    """Undo a half-finished transfer on the target (or retire the source afterwards)."""
    await delete(cluster, vm_name)

def set_guest_password(cluster, vm_name: str, password: str):
    conn = _connect(cluster)
    try: conn.lookupByName(_vm(vm_name)).setUserPassword("ubuntu", password, 0)
    except libvirt.libvirtError as exc: raise _fail(f"Guest agent password update failed for {vm_name}", exc) from exc
    finally: conn.close()

def _affect_flags(domain):
    return libvirt.VIR_DOMAIN_AFFECT_CONFIG | (libvirt.VIR_DOMAIN_AFFECT_LIVE if domain.isActive() else 0)

def set_media(cluster, spec: dict):
    """Mount (iso_image_id set) or eject the install disc, and apply boot order to the persistent config."""
    conn = _connect(cluster)
    try:
        domain = conn.lookupByName(_vm(spec["vm_name"]))
        iso = spec.get("iso_image_id")
        source = f"<source file='{iso_path(iso)}'/>" if iso else ""
        device = f"<disk type='file' device='cdrom'><driver name='qemu' type='raw'/>{source}<target dev='sdb' bus='sata'/><readonly/></disk>"
        domain.updateDeviceFlags(device, _affect_flags(domain))
        conn.defineXML(domain_xml(spec))  # boot order only takes effect on next boot
    except libvirt.libvirtError as exc: raise _fail(f"Media update failed for {spec['vm_name']}", exc) from exc
    finally: conn.close()

async def sync_image(cluster, image):
    if not str(image.url).startswith("https://") or not re.fullmatch(r"[a-f0-9]{64}", image.checksum):
        raise HypervisorError("Image source is not verified")
    target = base_image_path(image.id) if image.kind == "cloud" else iso_path(image.id)
    connection = await _node_connection(cluster)
    try:
        await _run(connection, ["curl", "-fsSL", "--proto", "=https", "--retry", "3", "-o", f"{target}.part", image.url], timeout=1800)
        digest = (await _run(connection, ["sha256sum", f"{target}.part"], timeout=600)).split()[0]
        if digest != image.checksum:
            await _run(connection, ["rm", "-f", "--", f"{target}.part"])
            raise HypervisorError("Image checksum mismatch")
        await _run(connection, ["mv", "-f", "--", f"{target}.part", target])
    finally: connection.close()

async def push_rules(cluster, rules: str, private_ips: list[str]):
    """Stage rules for the root-owned plexus-rules.path unit, which validates and applies them."""
    for address in private_ips: ipaddress.IPv4Address(address)
    connection = await _node_connection(cluster)
    try:
        await _write(connection, STAGED_IPS, "\n".join(private_ips) + "\n", 0o640)
        await _write(connection, STAGED_RULES, rules, 0o640)
        expected = hashlib.sha256(rules.encode()).hexdigest()
        wanted_ips = set(private_ips)
        loop = asyncio.get_running_loop(); deadline = loop.time() + RULES_APPLY_TIMEOUT
        while True:
            # Success needs both: the rules hash the root unit records after `nft -f`,
            # and every private IP actually present on the uplink (netplan applied).
            # The rules hash alone matches when only the IP list changed.
            result = await connection.run(shlex.join(["cat", f"{STATE_DIR}/applied.sha256"]), check=False, timeout=10)
            rules_ok = result.exit_status == 0 and (result.stdout or "").strip() == expected
            ips_ok = True
            if rules_ok and wanted_ips:
                present = await connection.run(shlex.join(["ip", "-4", "-o", "addr", "show", "dev", cluster.uplink_interface]), check=False, timeout=10)
                found = {part.split("/")[0] for line in (present.stdout or "").splitlines() for part in line.split()[3:4]}
                ips_ok = present.exit_status == 0 and wanted_ips <= found
            if rules_ok and ips_ok:
                return
            if loop.time() >= deadline:
                raise HypervisorError("Node did not apply the updated rules")
            await asyncio.sleep(0.5)
    finally: connection.close()

HEALTH_CHECKS = ("libvirt", "forwarding", "ips", "rules", "network")
VERIFY_CHECKS = HEALTH_CHECKS + ("link",)
CHECK_LABELS = {"libvirt": "libvirt service", "forwarding": "IP forwarding", "ips": "private IPs on the uplink",
                "rules": "network rules", "network": "guest network", "link": "panel-to-hypervisor link"}

async def verify_node(cluster) -> tuple[dict, str]:
    """(checks, detail). Besides the node's own health script, this opens the real
    qemu+libssh link that every machine action uses, so Verify can no longer pass while
    machine actions fail (A6). detail carries the real error text of each failure."""
    checks = {key: False for key in VERIFY_CHECKS}
    problems = []
    try:
        connection = await _node_connection(cluster)
    except HypervisorError as exc:
        return checks, str(exc)
    try:
        health = json.loads(await _run(connection, [NODE_HELPER, "health"], timeout=20))
        for key in HEALTH_CHECKS:
            checks[key] = bool(health.get(key))
    except (HypervisorError, ValueError, TypeError) as exc:
        problems.append(f"node health script: {error_detail(exc)}")
    finally:
        connection.close()
    try:
        await asyncio.to_thread(check_link, cluster)
        checks["link"] = True
    except HypervisorError as exc:
        problems.append(str(exc))
    return checks, "; ".join(problems)

def node_capacity(cluster) -> tuple[int, int]:
    conn = _connect(cluster)
    try:
        info = conn.getInfo()
        return int(info[2]), int(info[1])
    finally: conn.close()

def host_stats(conn) -> dict:
    """Live host figures from an open connection: threads, memory and cumulative CPU time."""
    info = conn.getInfo()  # [model, memory MiB, cpus, mhz, nodes, sockets, cores, threads]
    stats = {"cpu_threads": int(info[2]), "memory_total_mb": int(info[1]), "memory_used_mb": None, "cpu_busy_ns": 0, "cpu_total_ns": 0}
    try:
        memory = conn.getMemoryStats(-1, 0)  # KiB: total, free, buffers, cached
        total = int(memory.get("total", 0))
        available = int(memory.get("free", 0)) + int(memory.get("buffers", 0)) + int(memory.get("cached", 0))
        if total:
            stats["memory_total_mb"] = total // 1024
            stats["memory_used_mb"] = max(0, total - available) // 1024
    except (libvirt.libvirtError, AttributeError, TypeError, ValueError) as exc:
        log.debug("Host memory statistics unavailable: %s", error_detail(exc))
    try:
        cpu = conn.getCPUStats(-1, 0)  # ns: kernel, user, idle, iowait
        idle = int(cpu.get("idle", 0)) + int(cpu.get("iowait", 0))
        busy = int(cpu.get("kernel", 0)) + int(cpu.get("user", 0))
        stats["cpu_busy_ns"], stats["cpu_total_ns"] = busy, busy + idle
    except (libvirt.libvirtError, AttributeError, TypeError, ValueError) as exc:
        log.debug("Host CPU statistics unavailable: %s", error_detail(exc))
    return stats

async def host_disk(cluster) -> tuple[int, int]:
    """(total, used) bytes of the filesystem that holds the machine disks."""
    connection = await _node_connection(cluster)
    try:
        out = await _run(connection, ["df", "-B1", "--output=size,used", STATE_DIR], timeout=15)
    finally: connection.close()
    lines = [line.split() for line in out.strip().splitlines()[1:] if line.strip()]
    if not lines or len(lines[-1]) < 2:
        raise HypervisorError("Unexpected df output")
    return int(lines[-1][0]), int(lines[-1][1])

# ---------- console: SSH to the guest through the node ----------

async def fetch_guest_host_key(cluster, guest_ip: str) -> str:
    """Re-pin: read the guest's current ed25519 host key through the node tunnel.

    Trust-on-first-use, so it is administrator-only and audited. Authentication with
    the panel key must still succeed, which proves this is the panel-provisioned guest."""
    ipaddress.IPv4Address(guest_ip)
    node = await _node_connection(cluster)
    try:
        guest = await asyncssh.connect(guest_ip, port=22, tunnel=node, username="ubuntu", client_keys=[panel_private_key(cluster)],
            known_hosts=None, server_host_key_algs=["ssh-ed25519"], connect_timeout=10)
        try:
            key = guest.get_server_host_key()
            if key is None: raise HypervisorError("Guest presented no host key")
            return key.export_public_key().decode().strip()
        finally:
            guest.close()
    except HypervisorError: raise
    except Exception as exc:
        raise HypervisorError("Could not reach the guest to read its host key") from exc
    finally:
        node.close()

async def open_console(cluster, machine, cols: int = 120, rows: int = 32):
    """machine/cluster may be detached ORM objects; only already-loaded attributes are read."""
    ip = machine.cluster_ip.guest_ipv4 if machine.cluster_ip else None
    if not ip or not machine.guest_host_key: raise HypervisorError("Console unavailable")
    ipaddress.IPv4Address(ip)
    node = await _node_connection(cluster)
    try:
        key_type, key_data = machine.guest_host_key.split()[:2]
        guest = await asyncssh.connect(ip, port=22, tunnel=node, username="ubuntu", client_keys=[panel_private_key(cluster)],
            known_hosts=asyncssh.import_known_hosts(f"{ip} {key_type} {key_data}\n"), connect_timeout=10)
        process = await guest.create_process(term_type="xterm-256color", term_size=(cols, rows), encoding=None)
        return (node, guest), process
    except Exception as exc:
        node.close(); raise HypervisorError("Console unavailable") from exc
