"""Per-machine telemetry from libvirt, retention, and the live figures pages show.

Accuracy rules:
* every sample carries the exact time its counters were read (not the time it was saved),
  so rates and CPU % are computed over the real interval;
* counters restart at zero whenever QEMU restarts (boot after power-off, transfer to
  another node); a counter that went backwards never produces a negative or a huge
  value - the interval is simply skipped;
* memory is what the guest itself reports as in use (virtio balloon statistics); the
  QEMU process size is only a fallback and is never shown above the configured memory;
* a page never presents an old sample as live.
"""
from contextlib import suppress
from datetime import timedelta
from defusedxml import ElementTree as ET
import libvirt
from plexus.config import settings
from plexus.models import MetricSample, utcnow
from plexus.services.libvirt import _connect

# Balloon statistics refresh period requested from the guest (seconds).
BALLOON_PERIOD = 10


def purge_metrics(db):
    cutoff = utcnow() - timedelta(days=settings.metrics_retention_days)
    db.query(MetricSample).filter(MetricSample.sampled_at < cutoff).delete(synchronize_session=False)


def live_window_seconds() -> float:
    """A sample older than this is no longer "live" (three missed cycles, at least 45 s)."""
    return max(45.0, 3.0 * settings.metrics_interval_seconds)


def _aware(value):
    return value if value is None or value.tzinfo else value.replace(tzinfo=utcnow().tzinfo)


def guest_memory_used_mb(stats: dict, configured_mb: int | None = None) -> int:
    """Memory in use inside the guest, in MiB.

    available = memory the guest sees, usable = MemAvailable, unused = MemFree (KiB).
    Falls back to the QEMU resident size when the guest reports nothing."""
    stats = stats or {}
    used_kib = None
    available = stats.get("available")
    if available:
        if stats.get("usable") is not None:
            used_kib = int(available) - int(stats["usable"])
        elif stats.get("unused") is not None:
            used_kib = int(available) - int(stats["unused"]) - int(stats.get("disk_caches", 0) or 0)
    if used_kib is None:
        used_kib = int(stats.get("rss", 0) or 0)
    used_mb = max(0, used_kib // 1024)
    if configured_mb:
        used_mb = min(used_mb, int(configured_mb))
    return used_mb


def cpu_percent(cpu_time_ns: int, sampled_at, previous, vcpus: int) -> float | None:
    """Average guest CPU use since the previous sample, 0-100 % of all its vCPUs.
    None when there is no usable previous sample (first sample, counter reset, gap)."""
    if previous is None or previous.sampled_at is None or previous.cpu_time_ns is None:
        return None
    elapsed = (sampled_at - _aware(previous.sampled_at)).total_seconds()
    if elapsed <= 0 or elapsed > 10 * settings.metrics_interval_seconds:
        return None
    delta = int(cpu_time_ns) - int(previous.cpu_time_ns)
    if delta < 0:
        return None  # QEMU restarted: counters began again at zero
    return round(min(100.0, delta / (elapsed * 1_000_000_000 * max(int(vcpus), 1)) * 100.0), 2)


def collect_machine_metrics(cluster, vm_name, previous=None, connection=None):
    """Pass connection to reuse one libvirt connection per node per collection cycle."""
    own = connection is None
    connection = connection or _connect(cluster)
    if connection is None:
        return None
    try:
        domain = connection.lookupByName(vm_name)
        state, max_memory_kib, _memory, vcpus, cpu_time = domain.info()
        if state != 1:
            return None
        memory = domain.memoryStats() or {}
        if "unused" not in memory and "usable" not in memory and hasattr(domain, "setMemoryStatsPeriod"):
            # Ask the balloon driver for guest statistics; they appear from the next cycle.
            with suppress(libvirt.libvirtError, TypeError):
                domain.setMemoryStatsPeriod(BALLOON_PERIOD, getattr(libvirt, "VIR_DOMAIN_AFFECT_LIVE", 1))
        memory_used_mb = guest_memory_used_mb(memory, int(max_memory_kib) // 1024 if max_memory_kib else None)
        disk_read = disk_write = network_rx = network_tx = 0
        root = ET.fromstring(domain.XMLDesc(0))
        for disk in root.findall("./devices/disk"):
            if disk.get("device", "disk") != "disk":
                continue  # install media and the seed disc are not the machine's disk
            target = disk.find("target")
            dev = target.get("dev") if target is not None else None
            if dev:
                with suppress(libvirt.libvirtError, IndexError, TypeError, ValueError):
                    stats = domain.blockStats(dev)
                    disk_read += max(0, int(stats[1]))
                    disk_write += max(0, int(stats[3]))
        for target in root.findall("./devices/interface/target"):
            dev = target.get("dev")
            if dev:
                with suppress(libvirt.libvirtError, IndexError, TypeError, ValueError):
                    stats = domain.interfaceStats(dev)
                    network_rx += max(0, int(stats[0]))
                    network_tx += max(0, int(stats[4]))
        sampled_at = utcnow()
        try:
            epoch = f"{int(cluster.id)}:{int(domain.ID())}"
        except Exception:
            epoch = None
        return {"cpu_percent": cpu_percent(int(cpu_time), sampled_at, previous, int(vcpus)), "cpu_time_ns": int(cpu_time),
                "memory_used_mb": memory_used_mb, "disk_read_bytes": disk_read, "disk_write_bytes": disk_write,
                "network_rx_bytes": network_rx, "network_tx_bytes": network_tx, "sampled_at": sampled_at, "epoch": epoch}
    finally:
        if own:
            connection.close()


def _rate(current, previous, seconds) -> float | None:
    if current is None or previous is None or seconds <= 0:
        return None
    delta = int(current) - int(previous)
    return None if delta < 0 else delta / seconds


def live_rates(machine, samples, now=None) -> dict:
    """What the Metrics tab shows as "now": the latest sample if it is fresh, plus
    per-second rates from the last two samples of the same QEMU run."""
    now = now or utcnow()
    result = {"live": False, "age": None, "cpu": None, "memory_mb": None, "memory_pct": None,
              "disk_read_bps": None, "disk_write_bps": None, "net_in_bps": None, "net_out_bps": None}
    if not samples:
        return result
    latest = samples[-1]
    age = (now - _aware(latest.sampled_at)).total_seconds() if latest.sampled_at else None
    result["age"] = age
    result["live"] = machine.state == "running" and age is not None and age <= live_window_seconds()
    if not result["live"]:
        return result
    result["cpu"] = latest.cpu_percent
    result["memory_mb"] = latest.memory_used_mb
    if machine.memory_mb:
        result["memory_pct"] = round(min(100.0, latest.memory_used_mb / machine.memory_mb * 100.0), 1)
    if len(samples) >= 2:
        before = samples[-2]
        seconds = (_aware(latest.sampled_at) - _aware(before.sampled_at)).total_seconds()
        if 0 < seconds <= 10 * settings.metrics_interval_seconds:
            result["disk_read_bps"] = _rate(latest.disk_read_bytes, before.disk_read_bytes, seconds)
            result["disk_write_bps"] = _rate(latest.disk_write_bytes, before.disk_write_bytes, seconds)
            result["net_in_bps"] = _rate(latest.network_rx_bytes, before.network_rx_bytes, seconds)
            result["net_out_bps"] = _rate(latest.network_tx_bytes, before.network_tx_bytes, seconds)
    return result
