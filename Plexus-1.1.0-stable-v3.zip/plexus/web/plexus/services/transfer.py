"""Machine transfer between nodes: stages, validation and the live status shown to people.

The work itself runs in the clusters service (worker._transfer); this module holds what the
web panel and the worker share, so both always agree on stage names and percentages.
"""
from datetime import timedelta
from plexus.models import Cluster, ClusterIP, Job, Machine, utcnow

TRANSFER_PHASE_COPY = "copy"        # disk being copied; the machine still belongs to the source
TRANSFER_PHASE_SWAPPED = "swapped"  # address and node switched; finishing on the target

# key: (start %, end %, label). The bar moves through each stage's range in order.
STAGES = {
    "queued": (0, 0, "Waiting to start"),
    "preflight": (0, 5, "Preparing the transfer"),
    "shutdown": (5, 12, "Stopping the machine"),
    "snapshot": (12, 25, "Preparing machine data"),
    "copy": (25, 85, "Transferring machine data"),
    "verify": (85, 89, "Checking transferred data"),
    "network": (89, 92, "Updating the network"),
    "boot": (92, 96, "Starting the machine"),
    "confirm": (96, 98, "Starting the machine"),
    "finalize": (98, 100, "Finishing up"),
    "complete": (100, 100, "Transfer complete"),
    "rollback": (0, 0, "Restoring the machine"),
    "failed": (0, 0, "Transfer failed"),
}
# The steps listed in the progress dialog (stages that map onto one row are grouped).
STEPS = (
    ("preflight", "Preparing", ("preflight",)),
    ("shutdown", "Stopping", ("shutdown",)),
    ("snapshot", "Preparing data", ("snapshot",)),
    ("copy", "Transferring data", ("copy",)),
    ("verify", "Checking data", ("verify",)),
    ("network", "Updating network", ("network",)),
    ("boot", "Starting", ("boot", "confirm")),
    ("finalize", "Finishing", ("finalize", "complete")),
)
ORDER = [key for key in STAGES if key not in {"queued", "rollback", "failed"}]
# Owners see the progress, not node names or addresses of other customers.
OWNER_LABELS = {key: label for key, (_s, _e, label) in STAGES.items()}
# A finished transfer stays visible in the dialog for this long after it ends.
RECENT = timedelta(minutes=10)


def latest_transfer(db, machine_id: str, include_recent: bool = True):
    job = db.query(Job).filter(Job.machine_id == machine_id, Job.kind == "transfer").order_by(Job.created_at.desc(), Job.id.desc()).first()
    if job is None:
        return None
    if job.state in {"queued", "running"}:
        return job
    if include_recent and job.updated_at is not None:
        stamp = job.updated_at if job.updated_at.tzinfo else job.updated_at.replace(tzinfo=utcnow().tzinfo)
        if utcnow() - stamp <= RECENT:
            return job
    return None


def _payload(job) -> dict:
    import json
    try:
        data = json.loads(job.payload or "{}")
        return data if isinstance(data, dict) and "sealed" not in data else {}
    except ValueError:
        return {}


def step_states(stage: str, state: str) -> list[dict]:
    """[{key, label, status}] with status done / active / pending / failed for the dialog."""
    if state == "complete":
        return [{"key": key, "label": label, "status": "done"} for key, label, _ in STEPS]
    current = ORDER.index(stage) if stage in ORDER else -1
    rows = []
    for key, label, members in STEPS:
        positions = [ORDER.index(m) for m in members]
        if current < 0:
            status = "pending"
        elif current > max(positions):
            status = "done"
        elif current >= min(positions):
            status = "failed" if state == "failed" else "active"
        else:
            status = "pending"
        rows.append({"key": key, "label": label, "status": status})
    if state == "failed" and current < 0:
        rows[0]["status"] = "failed"
    return rows


def transfer_status(db, machine: Machine, job=None, admin: bool = True) -> dict | None:
    """JSON-ready status of the machine's current (or just finished) transfer."""
    job = job or latest_transfer(db, machine.id)
    if job is None:
        return None
    data = _payload(job)
    stage = job.stage or ("queued" if job.state == "queued" else "preflight")
    if job.state == "complete":
        stage = "complete"
    elif job.state == "failed":
        stage = "failed"
    label = STAGES.get(stage, STAGES["preflight"])[2]
    percent = 100 if job.state == "complete" else max(0, min(100, int(job.progress or 0)))
    status = {
        "job_id": job.id, "state": job.state, "stage": stage, "label": label, "percent": percent,
        "detail": job.detail or "", "machine_state": machine.state, "steps": step_states(job.stage or "", job.state),
        "result": "",
    }
    if not admin:
        # Owners: progress and plain-language steps only.
        status["detail"] = ""
        status["result"] = "Your machine has been transferred and is available again." if job.state == "complete" else ("The transfer could not be completed. Your machine is available as before." if job.state == "failed" else "")
        return status
    target = db.get(Cluster, int(data["target_cluster_id"])) if str(data.get("target_cluster_id", "")).isdigit() else None
    source = db.get(Cluster, int(data["source_cluster_id"])) if str(data.get("source_cluster_id", "")).isdigit() else None
    if source is None and job.state == "queued":
        source = machine.cluster
    held = db.query(ClusterIP).filter(ClusterIP.held_for == machine.id).first()
    current_ip = machine.cluster_ip
    status.update({
        "machine_id": machine.id, "vm_name": machine.vm_name,
        "source": source.name if source else (machine.cluster.name if machine.cluster else ""),
        "target": target.name if target else "",
        "old_ipv4": held.public_ipv4 if held else (data.get("old_ipv4") or (current_ip.public_ipv4 if current_ip and machine.cluster_id != (target.id if target else None) else "")),
        "new_ipv4": current_ip.public_ipv4 if current_ip and target and current_ip.cluster_id == target.id else "",
    })
    # Before the switch the address is not yet taken: show the one the target will hand out.
    expected = preview_target_ip(db, target) if target and not status["new_ipv4"] and job.state in {"queued", "running"} else None
    status["new_ipv4_expected"] = expected.public_ipv4 if expected else ""
    # Plain-language outcome only; the technical reason stays in the job record.
    if job.state == "complete":
        status["result"] = f"{machine.id} is now running on {status['target'] or 'the new node'}."
    elif job.state == "failed":
        status["result"] = "The transfer could not be completed. The machine was kept on its original node."
    return status


def preview_target_ip(db, cluster: Cluster) -> ClusterIP | None:
    """The address the transfer will most likely receive (the first free one)."""
    return (db.query(ClusterIP).filter(ClusterIP.cluster_id == cluster.id, ClusterIP.machine_id.is_(None), ClusterIP.held_for.is_(None))
            .order_by(ClusterIP.id).first())
