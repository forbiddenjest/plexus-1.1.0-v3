"use strict";
(() => {
  // Preloader: shown on first paint (body.is-loading), on page switches, sign-in and
  // every action; hidden once the page is ready or restored from the back/forward cache.
  const body = document.body;
  const showLoader = () => body.classList.add("is-loading");
  const hideLoader = () => body.classList.remove("is-loading");
  if (document.readyState === "complete") hideLoader();
  else window.addEventListener("load", hideLoader, { once: true });
  window.addEventListener("pageshow", (event) => { if (event.persisted) hideLoader(); });
  setTimeout(hideLoader, 8000); // never trap the page behind the loader
  document.addEventListener("click", (event) => {
    if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const link = event.target instanceof Element ? event.target.closest("a[href]") : null;
    if (!link || link.target === "_blank" || link.hasAttribute("download") || link.hasAttribute("hx-get")) return;
    const url = new URL(link.href, window.location.href);
    if (url.origin !== window.location.origin || (url.pathname === window.location.pathname && url.search === window.location.search && url.hash)) return;
    showLoader();
  });
  document.addEventListener("submit", (event) => {
    const form = event.target;
    if (!(form instanceof HTMLFormElement) || form.hasAttribute("hx-post")) return;
    setTimeout(() => { if (!event.defaultPrevented) showLoader(); }, 0);
  });
  document.addEventListener("htmx:beforeRequest", (event) => {
    const elt = event.detail?.elt;
    if (elt instanceof Element && elt.closest("[hx-trigger*='every']")) return; // live refresh stays silent
    showLoader();
  });
  document.addEventListener("htmx:afterRequest", hideLoader);
  const csrf = document.querySelector('meta[name="csrf-token"]')?.content || "";
  if (window.htmx) {
    window.htmx.config.allowEval = false;
    window.htmx.config.allowScriptTags = false;
    window.htmx.on("htmx:configRequest", (event) => {
      if (csrf) event.detail.headers["X-CSRF-Token"] = csrf;
    });
  }
  document.addEventListener("htmx:confirm", (event) => {
    const form = event.detail?.elt;
    const message = form instanceof HTMLFormElement ? form.dataset.confirm : "";
    if (!message) return;
    event.preventDefault();
    if (window.confirm(message)) event.detail.issueRequest(true);
  });
  document.addEventListener("submit", (event) => {
    const form = event.target;
    if (!(form instanceof HTMLFormElement) || form.hasAttribute("hx-post")) return;
    const message = form.dataset.confirm;
    if (message && !window.confirm(message)) event.preventDefault();
  });
  // Failed htmx actions (409 busy, 422 invalid) return the error page; show its message inline.
  document.addEventListener("htmx:beforeSwap", (event) => {
    const xhr = event.detail.xhr;
    if (!xhr || xhr.status < 400) return;
    let message = "The request could not be completed.";
    try {
      const doc = new DOMParser().parseFromString(xhr.responseText || "", "text/html");
      const text = doc.querySelector(".auth-card p")?.textContent?.trim();
      if (text) message = text;
    } catch (_) { /* keep default */ }
    const box = document.createElement("div");
    box.className = "alert alert-error";
    box.setAttribute("role", "alert");
    box.textContent = message;
    event.detail.shouldSwap = false;
    const target = event.detail.target;
    if (target) target.replaceChildren(box);
  });
  // Copy buttons for one-time secrets.
  document.addEventListener("click", (event) => {
    const button = event.target instanceof Element ? event.target.closest("[data-copy]") : null;
    if (!button) return;
    const source = document.getElementById(button.dataset.copy || "");
    if (!source || !navigator.clipboard) return;
    navigator.clipboard.writeText(source.textContent || "").then(() => {
      const label = button.lastChild;
      if (label && label.nodeType === Node.TEXT_NODE) {
        const previous = label.textContent;
        label.textContent = "Copied";
        setTimeout(() => { label.textContent = previous; }, 1500);
      }
    }).catch(() => {});
  });
  // ---------------------------------------------------------------- live state
  // Machine states refresh in place every few seconds (paused while the tab is hidden),
  // so a boot, shutdown or transfer shows up without reloading the page.
  const LIVE_MS = 4000;
  const fetchJSON = async (url) => {
    const response = await fetch(url, { credentials: "same-origin", headers: { Accept: "application/json" }, cache: "no-store" });
    if (response.redirected || response.status === 401 || response.status === 403) throw new Error("signed-out");
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return response.json();
  };
  const STATE_RE = /^[a-z-]{1,20}$/;
  const setBadge = (badge, state, label) => {
    if (!STATE_RE.test(state)) return;
    badge.className = `status status-${state}`;
    const text = badge.querySelector(".status-text");
    if (text) text.textContent = label;
  };
  const poll = (fn, interval) => {
    let timer = null; let failures = 0;
    const tick = async () => {
      if (document.hidden) { timer = setTimeout(tick, interval); return; }
      try { await fn(); failures = 0; } catch (error) {
        if (error && error.message === "signed-out") return; // session ended: stop polling
        failures += 1;
      }
      timer = setTimeout(tick, Math.min(interval * (1 + failures), 30000));
    };
    timer = setTimeout(tick, interval);
    document.addEventListener("visibilitychange", () => { if (!document.hidden && timer) { clearTimeout(timer); timer = setTimeout(tick, 50); } });
  };
  const dashboard = document.querySelector("[data-live-dashboard]");
  if (dashboard) {
    const url = dashboard.dataset.liveDashboard;
    if (url && url.startsWith("/dashboard/live")) {
      poll(async () => {
        const data = await fetchJSON(url);
        for (const item of data.machines || []) {
          document.querySelectorAll(`[data-live-state="${CSS.escape(item.id)}"]`).forEach((badge) => setBadge(badge, item.state, item.label));
        }
        const running = document.querySelector("[data-live-running]");
        if (running && Number.isInteger(data.running)) running.textContent = String(data.running);
      }, LIVE_MS);
    }
  }
  const machineHead = document.querySelector("[data-live-machine]");
  if (machineHead) {
    const url = machineHead.dataset.liveMachine;
    const startedBusy = machineHead.dataset.busy === "true";
    const tab = machineHead.dataset.tab;
    if (url && /^\/machines\/vm-[a-z0-9]{5}\/live$/.test(url)) {
      poll(async () => {
        const data = await fetchJSON(url);
        document.querySelectorAll(`[data-live-state="${CSS.escape(data.id)}"]`).forEach((badge) => setBadge(badge, data.state, data.label));
        const block = document.querySelector("[data-live-block]");
        if (block && STATE_RE.test(data.state)) { block.className = `state-block state-${data.state}`; block.textContent = data.label.toUpperCase(); }
        const uptime = document.querySelector("[data-live-uptime]");
        if (uptime) uptime.textContent = data.uptime;
        if (data.transfer) {
          const pct = Math.max(0, Math.min(100, Number(data.transfer.percent) || 0));
          document.querySelectorAll("[data-live-transfer-percent]").forEach((el) => { el.textContent = String(pct); });
          document.querySelectorAll("[data-live-transfer-label]").forEach((el) => { el.textContent = data.transfer.label; });
          document.querySelectorAll("[data-live-transfer-bar]").forEach((el) => el.setAttribute("width", String(pct)));
        }
        // Actions become available (or unavailable): reload the overview so buttons match.
        if (data.busy !== startedBusy && (tab === "overview" || tab === "metrics")) {
          const typing = document.activeElement && /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName);
          if (!typing) window.location.reload();
        }
      }, LIVE_MS);
    }
  }

  // ---------------------------------------------------------------- machine transfer dialog
  const dialog = document.getElementById("transfer-dialog");
  if (dialog) {
    const statusUrl = dialog.dataset.statusUrl || "";
    const q = (name) => dialog.querySelector(`[data-xfer-${name}]`);
    let polling = false; let finished = false;
    const open = () => { dialog.hidden = false; body.classList.add("has-dialog"); q("card")?.focus({ preventScroll: true }); if (!polling && !finished) start(); };
    const close = () => { dialog.hidden = true; body.classList.remove("has-dialog"); };
    const render = (s) => {
      const pct = Math.max(0, Math.min(100, Number(s.percent) || 0));
      const card = q("card");
      if (card && /^[a-z]+$/.test(s.state)) card.dataset.state = s.state;
      q("percent").textContent = String(pct);
      q("fill").style.width = `${pct}%`;
      q("bar").setAttribute("aria-valuenow", String(pct));
      q("stage").textContent = s.label || "";
      if (s.source) q("source").textContent = s.source;
      if (s.target) q("target").textContent = s.target;
      if (s.old_ipv4) q("old").textContent = s.old_ipv4;
      const newIp = s.new_ipv4 || s.new_ipv4_expected || "";
      if (newIp) q("new").textContent = newIp;
      const title = q("title"); const result = q("result"); const note = q("note");
      if (s.state === "complete" || s.state === "failed") {
        finished = true;
        title.textContent = s.state === "complete" ? "Machine Transfer Complete" : "Machine Transfer Failed";
        if (note) note.hidden = true;
        result.hidden = false; result.className = `xfer-result xfer-result-${s.state}`;
        result.textContent = s.result || (s.state === "complete" ? "The machine is running on its new node." : "The transfer could not be completed. The machine was kept on its original node.");
        q("hide").hidden = true; q("done").hidden = false;
      } else {
        title.textContent = s.state === "queued" ? "Machine Transfer Starting..." : "Machine Transfer in Progress...";
      }
    };
    const start = () => {
      if (!statusUrl.startsWith("/administrator/machines/")) return;
      polling = true;
      const tick = async () => {
        try {
          const s = await fetchJSON(statusUrl);
          if (s.state && s.state !== "none") render(s);
          if (s.state === "complete" || s.state === "failed" || s.state === "none") { polling = false; return; }
        } catch (error) { if (error && error.message === "signed-out") { polling = false; return; } }
        setTimeout(tick, document.hidden ? 4000 : 1000);
      };
      tick();
    };
    dialog.querySelector("[data-xfer-hide]")?.addEventListener("click", close);
    dialog.querySelector("[data-xfer-done]")?.addEventListener("click", () => { showLoader(); window.location.reload(); });
    document.querySelectorAll("[data-transfer-open]").forEach((button) => button.addEventListener("click", open));
    document.addEventListener("keydown", (event) => { if (event.key === "Escape" && !dialog.hidden && !finished) close(); });
    const fill = q("fill"); if (fill) fill.style.width = `${Math.max(0, Math.min(100, Number(fill.dataset.pct) || 0))}%`;
    if (dialog.dataset.autoOpen === "true") open();
  }

  const consoleRoot = document.querySelector("[data-socket]");
  const openButton = document.querySelector("[data-console-open]");
  if (!consoleRoot || !openButton) return;
  openButton.addEventListener("click", () => {
    if (!window.Terminal) {
      showError("The local terminal client did not load. Refresh the page and try again.");
      return;
    }
    const placeholder = consoleRoot.querySelector(".console-placeholder");
    if (placeholder) placeholder.remove();
    const term = new window.Terminal({ cursorBlink: true, convertEol: true, fontFamily: '"SFMono-Regular", Consolas, monospace', fontSize: 13, theme: { background: "#0a0c0e", foreground: "#e9edf1", cursor: "#2f6bd6" } });
    term.open(consoleRoot);
    const fit = window.FitAddon ? new window.FitAddon.FitAddon() : null;
    if (fit) { term.loadAddon(fit); fit.fit(); }
    const socketPath = consoleRoot.dataset.socket;
    if (!socketPath || !/^\/ws\/machines\/vm-[a-z0-9]{5}\/console$/.test(socketPath)) {
      term.dispose(); showError("This machine does not have a valid console address."); return;
    }
    const scheme = window.location.protocol === "https:" ? "wss:" : "ws:";
    const socket = new WebSocket(`${scheme}//${window.location.host}${socketPath}`);
    socket.binaryType = "arraybuffer";
    socket.addEventListener("open", () => { term.writeln("\x1b[36mSecure console connected.\x1b[0m"); if (fit) fit.fit(); term.focus(); });
    socket.addEventListener("message", (event) => {
      if (event.data instanceof ArrayBuffer) term.write(new Uint8Array(event.data));
      else term.write(String(event.data));
    });
    socket.addEventListener("close", () => term.writeln("\r\n\x1b[90mConsole connection closed.\x1b[0m"));
    socket.addEventListener("error", () => term.writeln("\r\n\x1b[31mUnable to connect to the machine console.\x1b[0m"));
    term.onData((data) => {
      if (socket.readyState === WebSocket.OPEN) socket.send(new TextEncoder().encode(data));
    });
    window.addEventListener("resize", () => { if (fit) fit.fit(); }, { passive: true });
  }, { once: true });
  function showError(message) {
    const notice = document.createElement("p");
    notice.className = "console-error";
    notice.setAttribute("role", "alert");
    notice.textContent = message;
    consoleRoot.replaceChildren(notice);
  }
})();

