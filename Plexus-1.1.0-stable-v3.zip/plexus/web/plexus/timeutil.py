"""Panel time zone (IST by default).

Timestamps are stored in UTC, which keeps comparisons, expiry checks and ordering exact
across daylight-saving changes and server moves. Everything a person reads (pages,
logs, daily/monthly traffic buckets) is expressed in the panel time zone,
PLEXUS_TIMEZONE, which defaults to Asia/Kolkata (IST, UTC+05:30).
"""
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from plexus.config import settings

# IST has no daylight saving, so a fixed offset is exact when tzdata is unavailable.
IST = timezone(timedelta(hours=5, minutes=30), "IST")
_IST_NAMES = {"asia/kolkata", "asia/calcutta", "ist"}


def _panel_zone():
    name = (settings.timezone or "").strip()
    if name.lower() in _IST_NAMES:
        try:
            return ZoneInfo("Asia/Kolkata")
        except (ZoneInfoNotFoundError, ValueError):
            return IST
    try:
        return ZoneInfo(name)
    except (ZoneInfoNotFoundError, ValueError):
        return IST


LOCAL_TZ = _panel_zone()


def to_local(value: datetime | None) -> datetime | None:
    """Naive values from SQLite are UTC (that is how they were written)."""
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(LOCAL_TZ)


def local_now() -> datetime:
    return datetime.now(LOCAL_TZ)


def tz_label() -> str:
    return local_now().tzname() or str(LOCAL_TZ)


def format_local(value: datetime | None, pattern: str = "%Y-%m-%d %H:%M", empty: str = "—") -> str:
    local = to_local(value)
    return local.strftime(pattern) if local else empty
