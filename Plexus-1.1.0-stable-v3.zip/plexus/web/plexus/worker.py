"""Database-backed queue worker. Only a single service instance should run."""
import asyncio
import json
import logging
import os
import sys
import time
from collections import defaultdict
from datetime import timedelta
from fastapi import HTTPException
from sqlalchemy import update
from sqlalchemy.orm import object_session
from plexus.config import settings
from plexus.db import SessionLocal
from plexus.models import AuditLog, Cluster, ClusterIP, Image, Job, LoginAttempt, Machine, MetricSample, NodeSample, Session as LoginSession, Setting, utcnow
from plexus.security import decrypt_node_key, encrypt_node_key
from plexus.services import libvirt as hv
from plexus.services.clusters import cluster_rules, secondary_private_ips
from plexus.services.libvirt import domain_status, power_action
from plexus.services.machines import allocate_ip, guest_gateway
from plexus.services.metrics import collect_machine_metrics, purge_metrics
from plexus.services.panel_settings import DEFAULT_CPU_MODE, cpu_mode
from plexus.services.quotas import check_cluster_capacity
from plexus.services.traffic import counter_delta, record_traffic, rollover
from plexus.services.transfer import STAGES, TRANSFER_PHASE_COPY, TRANSFER_PHASE_SWAPPED

log = logging.getLogger("plexus.worker")
JOB_TIMEOUT = 1800
# A node-to-node transfer copies a whole disk; give it far longer than ordinary jobs.
JOB_TIMEOUTS = {"transfer": 6 * 3600, "sync-image": 3600, "provision": 3600, "rebuild": 3600}
MAX_JOB_TIMEOUT = max([JOB_TIMEOUT, *JOB_TIMEOUTS.values()])
# Jobs this process is executing right now; never requeued as "stale".
_RUNNING: set[int] = set()
# Rule pushes for one node are serialized and computed inside the lock, so an older
# snapshot can never overwrite a newer one.
_RULE_LOCKS: dict[int, asyncio.Lock] = defaultdict(asyncio.Lock)
# Consecutive reconcile cycles each node could not be reached from this process.
_UNREACHABLE: dict[int, int] = {}
# Why this process should exit so systemd starts a fresh one (None = keep running).
_RESTART_REASON: str | None = None
# Job running longer than this is never waited for when the worker restarts itself.
RESTART_DRAIN_SECONDS = 600
# Host disk usage needs an SSH round trip; sample it at most this often per node.
DISK_SAMPLE_SECONDS = 60
_DISK_CACHE: dict[int, tuple[float, int, int]] = {}


class WorkerRestart(Exception):
    """Raised out of worker_loop; worker_service exits non-zero so systemd restarts it."""


def request_restart(reason: str):
    global _RESTART_REASON
    if _RESTART_REASON is None:
        log.error("Worker restart requested: %s", reason)
        _RESTART_REASON = reason


def seal(data: dict) -> str:
    """Job payloads may carry a guest password; keep them encrypted at rest."""
    return json.dumps({"sealed": encrypt_node_key(json.dumps(data))})


def unseal(payload: str) -> dict:
    raw = json.loads(payload or "{}")
    return json.loads(decrypt_node_key(raw["sealed"])) if "sealed" in raw else raw


def job_timeout(kind: str) -> int:
    return JOB_TIMEOUTS.get(kind, JOB_TIMEOUT)


def machine_spec(machine) -> dict:
    ip = machine.cluster_ip
    if not ip: raise RuntimeError("Machine has no assigned address")
    session = object_session(machine)
    return {"cpu_mode": cpu_mode(session) if session is not None else DEFAULT_CPU_MODE,"vm_name": machine.vm_name, "hostname": machine.id, "vcpu": machine.vcpu, "memory_mb": machine.memory_mb,
            "disk_gb": machine.disk_gb, "image_id": machine.image_id, "guest_ip": ip.guest_ipv4,
            "guest_subnet": machine.cluster.guest_subnet, "gateway": guest_gateway(machine.cluster.guest_subnet),
            "iso_image_id": machine.iso_image_id, "boot_device": machine.boot_device,
            "speed_in_mbps": machine.speed_in_mbps, "speed_out_mbps": machine.speed_out_mbps}


async def push_cluster_rules(cluster_id: int):
    """Compute the full rule set from committed state in a fresh session, then apply it."""
    async with _RULE_LOCKS[int(cluster_id)]:
        db = SessionLocal()
        try:
            cluster = db.get(Cluster, int(cluster_id))
            if not cluster:
                return
            rules, private_ips = cluster_rules(db, cluster), secondary_private_ips(db, cluster)
        finally:
            db.close()
        await hv.push_rules(cluster, rules, private_ips)


def _queue_rule_push(db, cluster_id: int, actor_id=None):
    db.add(Job(kind="push-rules", actor_id=actor_id, state="queued", payload=json.dumps({"cluster_id": int(cluster_id)})))


async def _execute(db, job, machine, data):
    kind = job.kind
    if kind in {"start", "stop", "restart", "force-stop"} and machine:
        db.refresh(machine)
        # Suspended in the meantime: never boot it; a force-stop is still honoured.
        if machine.state == "suspended" and kind != "force-stop":
            return "Skipped: machine is suspended"
        result = await asyncio.to_thread(power_action, machine.cluster, machine.vm_name, kind)
        db.refresh(machine)  # an admin may have suspended it while the action ran
        if machine.state != "suspended":
            machine.set_power_state(result)
        return "Machine action completed"
    if kind in {"provision", "rebuild"} and machine:
        if kind == "rebuild":
            # Flushed, not committed: if the rebuild never starts, the rollback in _run_job
            # puts the previous image back.
            machine.image_id = int(data["image_id"]); db.flush(); db.refresh(machine)
        if not machine.image or machine.image.kind != "cloud" or not machine.image.active:
            raise RuntimeError("Machine image is not an active cloud image")
        action = hv.provision if kind == "provision" else hv.rebuild
        machine.guest_host_key = await action(machine.cluster, machine_spec(machine), data["password"])
        machine.set_power_state("running")
        cluster_id = machine.cluster_id
        db.commit()  # the guest exists and runs: never mark it failed after this point
        try:
            await push_cluster_rules(cluster_id)
        except Exception:
            _queue_rule_push(db, cluster_id, job.actor_id)
            return ("Machine built" if kind == "provision" else "Machine rebuilt") + "; node rules will be retried"
        return "Machine built" if kind == "provision" else "Machine rebuilt"
    if kind == "delete" and machine:
        cluster_id, vm_name, machine_id = machine.cluster_id, machine.vm_name, machine.id
        await hv.delete(machine.cluster, vm_name)
        db.query(ClusterIP).filter(ClusterIP.machine_id == machine_id).update({ClusterIP.machine_id: None}, synchronize_session=False)
        job.machine_id = None
        db.delete(machine)
        db.commit()  # the guest is gone: record that before anything else can fail
        try:
            await push_cluster_rules(cluster_id)
        except Exception:
            log.warning("Rule push after deleting %s failed; queued a retry", machine_id)
            _queue_rule_push(db, cluster_id, job.actor_id)
        return f"Machine {machine_id} deleted"
    if kind == "password" and machine:
        await asyncio.to_thread(hv.set_guest_password, machine.cluster, machine.vm_name, data["password"])
        return "Guest password updated"
    if kind == "media" and machine:
        await asyncio.to_thread(hv.set_media, machine.cluster, machine_spec(machine))
        return "Media updated"
    if kind == "firewall" and machine:
        await push_cluster_rules(machine.cluster_id)
        return "Firewall rules applied"
    if kind == "repin-host-key" and machine:
        if not machine.cluster_ip: raise RuntimeError("Machine has no assigned address")
        machine.guest_host_key = await hv.fetch_guest_host_key(machine.cluster, machine.cluster_ip.guest_ipv4)
        return "Guest host key re-pinned"
    if kind == "resize" and machine:
        # Specs were written (quota-checked) by the request; apply them to the hypervisor.
        grow = int(data.get("grow_disk_gb") or 0)
        if grow:
            await hv.grow_disk(machine.cluster, machine.vm_name, grow)
            data["disk_grown"] = True  # a later failure must not pretend the disk is small again
        await asyncio.to_thread(hv.redefine, machine.cluster, machine_spec(machine))
        return "Machine resources updated (vCPU/memory apply on next boot if it was running)"
    if kind == "transfer" and machine:
        return await _transfer(db, job, machine, data)
    if kind == "cleanup-copy":
        return await _cleanup_copy(db, data)
    if kind == "push-rules":
        await push_cluster_rules(int(data["cluster_id"]))
        return "Node rules applied"
    if kind == "sync-image":
        image, cluster = db.get(Image, int(data["image_id"])), db.get(Cluster, int(data["cluster_id"]))
        if not image or not cluster:
            return "Skipped: image or cluster no longer exists"
        await hv.sync_image(cluster, image)
        return "Image synced"
    raise RuntimeError("Unsupported operation")


class TransferProgress:
    """Live progress for the "Machine Transfer in Progress" dialog.

    Written to the job row from a short session of its own (never the job's session, so a
    progress write can never commit half of a state change). Monotonic while the
    transfer moves forward; throttled to about two writes a second."""

    def __init__(self, job_id: int):
        self.job_id, self.percent, self.stage, self.detail, self._last = job_id, 0, "", "", 0.0

    def reporter(self, stage: str):
        async def report(fraction: float, detail: str = ""):
            await self.set(stage, fraction, detail)
        return report

    async def set(self, stage: str, fraction: float = 0.0, detail: str = "", force: bool = False):
        start, end, _label = STAGES[stage]
        percent = int(start + (end - start) * max(0.0, min(1.0, float(fraction))))
        if stage not in {"rollback", "failed"}:
            percent = max(self.percent, percent)
        now = time.monotonic()
        due = force or stage != self.stage or (percent != self.percent and now - self._last >= 0.5) or (detail != self.detail and now - self._last >= 1.0)
        if not due:
            return
        self.percent, self.stage, self.detail, self._last = percent, stage, detail[:200], now
        try:
            await asyncio.to_thread(_write_progress, self.job_id, percent, stage, self.detail)
        except Exception:  # progress must never break the transfer itself
            log.debug("Progress update for job %s failed", self.job_id, exc_info=True)


def _write_progress(job_id: int, percent: int, stage: str, detail: str):
    db = SessionLocal()
    try:
        db.execute(update(Job).where(Job.id == job_id).values(progress=percent, stage=stage, detail=detail, updated_at=utcnow()))
        db.commit()
    finally:
        db.close()


async def _quietly(awaitable, what: str):
    try:
        await awaitable
    except Exception as exc:
        log.warning("%s failed: %s", what, hv.error_detail(exc))
        return False
    return True


def _save_payload(db, job, data: dict):
    job.payload = json.dumps(data)


async def _restore_power(db, machine, source, previous: str, previous_started_at: str | None, touched: bool):
    """Put the machine back the way it was on the source node."""
    if not touched:
        machine.set_power_state(previous)
        if previous == "running" and previous_started_at:
            try:
                from datetime import datetime
                machine.started_at = datetime.fromisoformat(previous_started_at)
            except (TypeError, ValueError):
                pass
        return
    if previous == "running":
        try:
            machine.set_power_state(await asyncio.to_thread(power_action, source, machine.vm_name, "start"))
            return
        except Exception as exc:
            log.warning("Could not start %s again on %s after the failed transfer: %s", machine.id, source.name, hv.error_detail(exc))
            machine.set_power_state("unknown")  # reconcile reads the real state
            return
    machine.set_power_state("stopped")


async def _transfer(db, job, machine, data):
    """Move a machine to another node with all of its data and a new IPv4.

      preflight -> shutdown -> snapshot -> copy (3-way SHA-256) -> verify (qemu-img check)
      -> network (new address committed, old one held) -> boot on target -> confirm
      -> finalize (rules on both nodes, source copy removed, old address released).

    Any failure up to and including the boot returns the machine to the source node with
    its old address and power state. The phase is stored in the job, so a worker restart
    resumes safely: before the swap the copy starts again; after it the move finishes."""
    progress = TransferProgress(job.id)
    db.refresh(machine)
    target_id = int(data["target_cluster_id"])
    phase = data.get("phase")
    if machine.state == "transferring" and phase == TRANSFER_PHASE_SWAPPED and machine.cluster_id == target_id:
        source = db.get(Cluster, int(data["source_cluster_id"]))
        log.info("Resuming the transfer of %s on %s", machine.id, machine.cluster.name)
        return await _transfer_finish(db, job, machine, source, machine.cluster, data, progress)
    if machine.state == "transferring" and phase == TRANSFER_PHASE_COPY:
        previous, previous_started = data.get("previous_state", "stopped"), data.get("previous_started_at")
        log.info("Restarting the interrupted copy of %s", machine.id)
    elif machine.state in {"running", "stopped"}:
        previous = machine.state
        previous_started = machine.started_at.isoformat() if machine.started_at else None
    else:
        raise RuntimeError(f"Machine is {machine.state}; transfer cancelled")
    source = machine.cluster
    target = db.get(Cluster, target_id)
    if not target or target.state != "active" or target.id == source.id:
        raise RuntimeError("Target cluster is not active")
    try:
        check_cluster_capacity(db, target.id, machine.memory_mb, machine.disk_gb, exclude_machine=machine.id)
    except HTTPException as exc:
        raise RuntimeError(str(exc.detail)) from exc
    if not db.query(ClusterIP.id).filter(ClusterIP.cluster_id == target.id, ClusterIP.machine_id.is_(None), ClusterIP.held_for.is_(None)).first():
        raise RuntimeError(f"{target.name} has no free IPv4 address")
    data.setdefault("old_ipv4", machine.cluster_ip.public_ipv4 if machine.cluster_ip else "")
    data.update(source_cluster_id=source.id, previous_state=previous, previous_started_at=previous_started, phase=TRANSFER_PHASE_COPY)
    _save_payload(db, job, data)
    machine.set_power_state("transferring")
    db.commit()
    await progress.set("preflight", 0.0, f"{source.name} → {target.name}", force=True)
    vm = machine.vm_name
    touched = False
    try:
        await hv.transfer_preflight(source, target, vm, machine.disk_gb, machine.iso_image_id)
        await progress.set("preflight", 1.0, "Both nodes are ready")
        touched = True  # from here on the machine was changed (powered off)
        await hv.stop_for_transfer(source, vm, progress=progress.reporter("shutdown"))
        size = await hv.snapshot_disk(source, vm, progress=progress.reporter("snapshot"))
        await progress.set("copy", 0.0, "Transferring machine data", force=True)
        digest = await hv.copy_disk(source, target, vm, size, progress=progress.reporter("copy"))
        await progress.set("verify", 1.0, "Data checked", force=True)
    except BaseException as exc:
        await progress.set("rollback", 0.0, "Restoring the machine", force=True)
        if touched:
            await _quietly(hv.discard_copy(target, vm), f"Removing the partial copy of {vm} on {target.name}")
            await _quietly(hv.remove_scratch(source, vm), f"Removing the transfer snapshot of {vm} on {source.name}")
        db.rollback()
        machine = db.get(Machine, machine.id)
        await _restore_power(db, machine, source, previous, previous_started, touched and not isinstance(exc, hv.NotStartedError))
        db.commit()
        raise
    await _quietly(hv.remove_scratch(source, vm), f"Removing the transfer snapshot of {vm} on {source.name}")

    # Swap: the machine moves to the target address in one short transaction; its old
    # address is held for it (never handed out) until the move is final.
    await progress.set("network", 0.0, "Reserving the new IPv4", force=True)
    old_ip = db.query(ClusterIP).filter(ClusterIP.machine_id == machine.id).first()
    if old_ip:
        old_ip.machine_id = None
        old_ip.held_for = machine.id
    db.flush()
    new_ip = allocate_ip(db, target.id, machine.id)
    machine.cluster_id = target.id
    machine.traffic_epoch = ""  # a new QEMU process on another node starts its counters at zero
    data.update(phase=TRANSFER_PHASE_SWAPPED, old_ip_id=old_ip.id if old_ip else None, new_ip_id=new_ip.id)
    _save_payload(db, job, data)
    db.commit(); db.refresh(machine)
    return await _transfer_finish(db, job, machine, source, target, data, progress)


async def _transfer_finish(db, job, machine, source, target, data, progress):
    vm, previous = machine.vm_name, data.get("previous_state", "stopped")
    new_ip = machine.cluster_ip
    if new_ip is None:
        raise RuntimeError("Machine has no address on the target")
    await progress.set("network", 1.0, f"New IPv4 {new_ip.public_ipv4} · guest {new_ip.guest_ipv4}")
    try:
        await progress.set("boot", 0.0, "Updating the network", force=True)
        machine.guest_host_key = await hv.boot_transferred(target, machine_spec(machine))
        db.commit()
        await progress.set("boot", 1.0, f"Running on {target.name}")
    except BaseException:
        await progress.set("rollback", 0.0, "Restoring the machine", force=True)
        db.rollback()
        machine = db.get(Machine, machine.id)
        db.query(ClusterIP).filter(ClusterIP.machine_id == machine.id).update({ClusterIP.machine_id: None}, synchronize_session=False)
        db.flush()
        db.query(ClusterIP).filter(ClusterIP.held_for == machine.id).update({ClusterIP.machine_id: machine.id, ClusterIP.held_for: None}, synchronize_session=False)
        machine.cluster_id = source.id
        machine.traffic_epoch = ""
        db.commit(); db.refresh(machine)
        await _quietly(hv.discard_copy(target, vm), f"Removing the copy of {vm} on {target.name}")
        await _restore_power(db, machine, source, previous, None, True)
        db.commit()
        raise
    # Past this point the machine lives on the target. It is never rolled back again.
    confirmed = await hv.wait_for_guest_address(target, vm, new_ip.guest_ipv4, progress=progress.reporter("confirm"))
    await progress.set("finalize", 0.0, "Finishing up", force=True)
    db.query(ClusterIP).filter(ClusterIP.held_for == machine.id).update({ClusterIP.held_for: None}, synchronize_session=False)
    machine.set_power_state("running")
    db.commit()
    notes = []
    try:
        await push_cluster_rules(target.id)
    except Exception:
        _queue_rule_push(db, target.id, job.actor_id); db.commit()
        notes.append(f"rules on {target.name} will be retried")
    await progress.set("finalize", 0.4, "Finishing up")
    if not await _quietly(hv.delete(source, vm), f"Removing {vm} from {source.name}"):
        db.add(Job(kind="cleanup-copy", actor_id=job.actor_id, state="queued", payload=json.dumps({"cluster_id": source.id, "vm_name": vm, "machine_id": machine.id})))
        db.add(AuditLog(action="machine.transfer_cleanup", target=machine.id, result="failed"))
        db.commit()
        notes.append(f"the old copy on {source.name} will be removed by a retry")
    try:
        await push_cluster_rules(source.id)
    except Exception:
        _queue_rule_push(db, source.id, job.actor_id); db.commit()
    if previous == "stopped":
        # It was off before the move: boot once (applies the new network), then off again.
        await progress.set("finalize", 0.8, "Finishing up")
        try:
            await hv.stop_for_transfer(target, vm)
            machine.set_power_state("stopped"); db.commit()
        except Exception as exc:
            log.warning("Could not power %s off after the move: %s", machine.id, hv.error_detail(exc))
    if not confirmed:
        notes.append("the guest has not confirmed its new address yet (no guest agent answer)")
    await progress.set("complete", 1.0, f"Now on {target.name} at {new_ip.public_ipv4}", force=True)
    return f"Machine moved from {source.name} to {target.name}; new IPv4 {new_ip.public_ipv4}" + (f" ({'; '.join(notes)})" if notes else "")


async def _cleanup_copy(db, data):
    cluster = db.get(Cluster, int(data["cluster_id"]))
    machine = db.get(Machine, str(data.get("machine_id") or "")) if data.get("machine_id") else None
    if not cluster:
        return "Skipped: cluster no longer exists"
    # Never remove the copy a machine is actually running from.
    if machine is not None and machine.cluster_id == cluster.id:
        return "Skipped: the machine lives on this node"
    if db.query(Machine.id).filter(Machine.vm_name == data["vm_name"], Machine.cluster_id == cluster.id).first():
        return "Skipped: a machine with this name lives on this node"
    await hv.discard_copy(cluster, data["vm_name"])
    return f"Old copy of {data['vm_name']} removed from {cluster.name}"


RESTORABLE_STATES = {"running", "stopped"}


TRANSFER_SUMMARY_KEYS = ("target_cluster_id", "source_cluster_id", "old_ipv4")


def _finished_payload(job, data=None) -> str:
    """Finished jobs keep no secrets. A transfer keeps only where it went and from which
    address, so its dialog still shows the real route after the move."""
    if job.kind != "transfer":
        return "{}"
    if data is None:
        try:
            data = json.loads(job.payload or "{}")
        except ValueError:
            data = {}
    return json.dumps({k: data[k] for k in TRANSFER_SUMMARY_KEYS if isinstance(data, dict) and k in data})


def _record_failure(db, job, data, exc):
    job.state = "failed"; job.payload = _finished_payload(job, data if isinstance(data, dict) else None)
    if job.kind == "transfer":
        job.stage, job.detail = "failed", (str(exc) or type(exc).__name__)[:200]
    job.result = (str(exc) or type(exc).__name__)[:500]
    failed_machine = db.get(Machine, job.machine_id) if job.machine_id else None
    if failed_machine and job.kind == "rebuild" and isinstance(exc, hv.NotStartedError):
        # The old guest was never touched (e.g. node unreachable at the first step): put
        # back the state it had, so Boot/Stop keep working and reconcile keeps watching it.
        previous = data.get("previous_state")
        failed_machine.set_power_state(previous if previous in RESTORABLE_STATES | {"failed"} else "unknown")
        if previous == "running" and data.get("previous_started_at"):
            try:
                from datetime import datetime
                failed_machine.started_at = datetime.fromisoformat(data["previous_started_at"])
            except (TypeError, ValueError):
                pass
        log.warning("Rebuild of %s did not start; state restored to %s", failed_machine.id, failed_machine.state)
    elif failed_machine and job.kind in {"provision", "rebuild"}:
        failed_machine.set_power_state("failed")
    elif failed_machine and job.kind == "resize" and data.get("previous"):
        # Hypervisor never got the new size: put the record back so quotas stay true.
        for key, value in data["previous"].items():
            if key == "disk_gb" and data.get("disk_grown"):
                continue  # the disk really is larger now
            if key in {"vcpu", "memory_mb", "disk_gb", "speed_in_mbps", "speed_out_mbps"}:
                setattr(failed_machine, key, int(value))
    elif failed_machine and job.kind == "transfer" and failed_machine.state == "transferring":
        # The rollback itself could not finish: never guess, let reconcile read the node.
        failed_machine.set_power_state("unknown")
        if failed_machine.cluster_ip is None:
            held = db.query(ClusterIP).filter(ClusterIP.held_for == failed_machine.id).first()
            if held and held.cluster_id == failed_machine.cluster_id:
                held.machine_id, held.held_for = failed_machine.id, None
    elif failed_machine and job.kind in {"start", "stop", "restart", "force-stop"} and failed_machine.state != "suspended":
        failed_machine.set_power_state("unknown")
    elif failed_machine and job.kind == "delete" and failed_machine.state == "deleting":
        pass  # stays "deleting"; an administrator can retry the delete
    db.add(AuditLog(actor_id=job.actor_id, action=f"job.{job.kind}", target=job.machine_id or str(job.id), result="failed"))


async def _run_job(job_id: int):
    db = SessionLocal()
    job_data: dict = {}
    _RUNNING.add(job_id)
    started = time.monotonic()
    label = f"job {job_id}"
    try:
        job = db.get(Job, job_id)
        if not job:
            return
        label = f"job {job_id} {job.kind}" + (f" ({job.machine_id})" if job.machine_id else "")
        log.info("%s started", label)
        machine = db.get(Machine, job.machine_id) if job.machine_id else None
        try:
            job_data = unseal(job.payload)
            result = await asyncio.wait_for(_execute(db, job, machine, job_data), timeout=job_timeout(job.kind))
        except (Exception, asyncio.CancelledError) as exc:
            failure = RuntimeError(f"Timed out after {job_timeout(job.kind)} s") if isinstance(exc, asyncio.TimeoutError) else exc
            if isinstance(exc, asyncio.CancelledError):
                log.warning("%s interrupted (worker stopping); it is retried at next start", label)
            else:
                log.warning("%s failed after %.1fs: %s", label, time.monotonic() - started, hv.error_detail(failure))
                if not isinstance(exc, (hv.HypervisorError, asyncio.TimeoutError)):
                    log.debug("%s traceback", label, exc_info=exc)
            db.rollback()
            job = db.get(Job, job_id)
            if job and isinstance(exc, asyncio.CancelledError):
                # Interrupted by a worker stop, not failed: run it again at the next start
                # (the payload, including a transfer's phase, is kept).
                job.state = "queued"; job.updated_at = utcnow()
            elif job:
                _record_failure(db, job, job_data, failure)
                job.updated_at = utcnow()
            db.commit()
            if isinstance(exc, asyncio.CancelledError):
                raise
            return
        job = db.get(Job, job_id)
        job.result = result
        job.state = "complete"; job.payload = _finished_payload(job); job.updated_at = utcnow()
        if job.kind == "transfer":
            job.progress, job.stage = 100, "complete"
        db.add(AuditLog(actor_id=job.actor_id, action=f"job.{job.kind}", target=job.machine_id or str(job_id), result="ok"))
        db.commit()
        log.info("%s completed in %.1fs: %s", label, time.monotonic() - started, result)
    finally:
        _RUNNING.discard(job_id)
        db.close()


def _claim_next(db, busy_machines: set):
    """Claim the oldest queued job whose machine has no other job in flight."""
    now = utcnow()
    in_flight = db.query(Job.machine_id).filter(Job.state == "running", Job.machine_id.isnot(None))
    query = db.query(Job.id, Job.machine_id).filter(Job.state == "queued").filter(
        (Job.machine_id.is_(None)) | (Job.machine_id.notin_(in_flight)))
    if busy_machines:
        query = query.filter((Job.machine_id.is_(None)) | (Job.machine_id.notin_(busy_machines)))
    candidate = query.order_by(Job.created_at, Job.id).first()
    if not candidate:
        return None, None
    job_id, machine_id = candidate
    changed = db.execute(update(Job).where(Job.id == job_id, Job.state == "queued").values(state="running", updated_at=now)).rowcount
    db.commit()
    return (job_id, machine_id) if changed == 1 else (None, None)


def recover_interrupted(db):
    """Worker start: anything still 'running' was interrupted by a restart or crash."""
    db.query(Job).filter(Job.state == "running").update({Job.state: "queued", Job.updated_at: utcnow()}, synchronize_session=False)


def _requeue_stale(db):
    cutoff = utcnow() - timedelta(seconds=MAX_JOB_TIMEOUT + 60)
    query = db.query(Job).filter(Job.state == "running", Job.updated_at < cutoff)
    if _RUNNING:
        query = query.filter(Job.id.notin_(list(_RUNNING)))
    query.update({Job.state: "queued", Job.updated_at: utcnow()}, synchronize_session=False)


def _by_cluster(machines):
    groups: dict[int, list] = {}
    for machine in machines:
        groups.setdefault(machine.cluster_id, []).append(machine)
    return groups


def _collect_cluster(cluster, items):
    """One libvirt connection per node per cycle instead of one per machine.
    Returns (per-machine samples, host figures or None). The connection is opened and
    closed inside this call; nothing outlives the cycle."""
    results, host = {}, None
    try:
        conn = hv.open_connection(cluster)
    except Exception as exc:
        log.warning("Metrics: node %s unreachable: %s", cluster.name, hv.error_detail(exc))
        return results, host
    try:
        try:
            host = hv.host_stats(conn)
        except Exception as exc:
            log.debug("Metrics: no host figures for %s: %s", cluster.name, hv.error_detail(exc))
        for machine, previous in items:
            try:
                results[machine.id] = collect_machine_metrics(cluster, machine.vm_name, previous, connection=conn)
            except Exception as exc:
                log.debug("Metrics: no sample for %s: %s", machine.id, hv.error_detail(exc))
    finally:
        conn.close()
    return results, host


def _rate(current: int, previous: int | None, seconds: float) -> int:
    if previous is None or seconds <= 0:
        return 0
    return int(counter_delta(current, previous) / seconds)


async def _disk_figures(cluster) -> tuple[int | None, int | None]:
    cached = _DISK_CACHE.get(cluster.id)
    if cached and time.monotonic() - cached[0] < DISK_SAMPLE_SECONDS:
        return cached[1], cached[2]
    try:
        total, used = await hv.host_disk(cluster)
    except Exception as exc:
        log.debug("Metrics: no disk figures for %s: %s", cluster.name, hv.error_detail(exc))
        return (cached[1], cached[2]) if cached else (None, None)
    _DISK_CACHE[cluster.id] = (time.monotonic(), total, used)
    return total, used


def node_sample(db, cluster, host: dict, net_rx_bps: int, net_tx_bps: int, disk: tuple) -> NodeSample:
    previous = db.query(NodeSample).filter(NodeSample.cluster_id == cluster.id).order_by(NodeSample.sampled_at.desc(), NodeSample.id.desc()).first()
    cpu = None
    if previous and host["cpu_total_ns"] > previous.cpu_total_ns and host["cpu_busy_ns"] >= previous.cpu_busy_ns:
        cpu = min(100.0, max(0.0, (host["cpu_busy_ns"] - previous.cpu_busy_ns) / (host["cpu_total_ns"] - previous.cpu_total_ns) * 100))
    return NodeSample(cluster_id=cluster.id, cpu_threads=host["cpu_threads"], cpu_percent=cpu, cpu_busy_ns=host["cpu_busy_ns"], cpu_total_ns=host["cpu_total_ns"],
                      memory_total_mb=host["memory_total_mb"], memory_used_mb=host["memory_used_mb"], disk_total_bytes=disk[0], disk_used_bytes=disk[1],
                      net_rx_bps=max(0, int(net_rx_bps)), net_tx_bps=max(0, int(net_tx_bps)))


async def _poll_metrics():
    db = SessionLocal()
    try:
        running = db.query(Machine).filter(Machine.state == "running").all()
        groups = _by_cluster(running)
        # Every enrolled node (host figures for Metrics) plus any node that still has running
        # machines (traffic accounting must never pause, whatever the node's state).
        clusters = db.query(Cluster).filter(Cluster.state.in_(["active", "draining"]) | Cluster.id.in_(list(groups) or [-1])).order_by(Cluster.id).all()
        plans = []
        for cluster in clusters:
            machines = groups.get(cluster.id, [])
            items = [(m, db.query(MetricSample).filter(MetricSample.machine_id == m.id).order_by(MetricSample.sampled_at.desc(), MetricSample.id.desc()).first()) for m in machines]
            plans.append((cluster, machines, items))
        # Nodes are read in parallel: one slow or unreachable node never delays the others.
        collected = await asyncio.gather(*(asyncio.to_thread(_collect_cluster, cluster, items) for cluster, _m, items in plans), return_exceptions=True)
        for (cluster, machines, items), outcome in zip(plans, collected):
            if isinstance(outcome, BaseException):
                log.warning("Metrics: collection for %s failed: %s", cluster.name, hv.error_detail(outcome))
                continue
            results, host = outcome
            by_id = {m.id: m for m in machines}
            previous = {m.id: prev for m, prev in items}
            rx_bps = tx_bps = 0
            for machine_id, values in results.items():
                if not values:
                    continue
                epoch = values.pop("epoch", None)
                stamp = values.get("sampled_at") or utcnow()
                prev = previous.get(machine_id)
                if prev is not None and prev.sampled_at is not None:
                    seconds = (stamp - _aware(prev.sampled_at)).total_seconds()
                    if 0 < seconds < 10 * settings.metrics_interval_seconds:
                        rx_bps += _rate(values["network_rx_bytes"], prev.network_rx_bytes, seconds)
                        tx_bps += _rate(values["network_tx_bytes"], prev.network_tx_bytes, seconds)
                machine = by_id[machine_id]
                db.refresh(machine)
                if machine.state != "running" or machine.cluster_id != cluster.id:
                    continue  # stopped or moved while the node was being read: discard the sample
                db.add(MetricSample(machine_id=machine_id, **values))
                record_traffic(db, machine, values["network_rx_bytes"], values["network_tx_bytes"], epoch=epoch)
            if host:
                db.add(node_sample(db, cluster, host, rx_bps, tx_bps, await _disk_figures(cluster)))
        rollover(db)
        db.commit()
        purge_metrics(db)
        db.query(NodeSample).filter(NodeSample.sampled_at < utcnow() - timedelta(days=settings.metrics_retention_days)).delete(synchronize_session=False)
        db.commit()
    finally:
        db.close()
    heartbeat("metrics")


def _aware(value):
    return value if value is None or value.tzinfo else value.replace(tzinfo=utcnow().tzinfo)


HEARTBEAT_KEY = "clusters_heartbeat"


def heartbeat(source: str):
    """Record that the clusters service is alive (shown on Overview and by `plexus status`)."""
    db = SessionLocal()
    try:
        row = db.get(Setting, HEARTBEAT_KEY)
        value = f"{utcnow().isoformat()}|{source}"
        if row is None:
            db.add(Setting(key=HEARTBEAT_KEY, value=value))
        else:
            row.value = value
        db.commit()
    except Exception:
        db.rollback()
        log.debug("Heartbeat write failed", exc_info=True)
    finally:
        db.close()


def housekeeping(db):
    """Expired sessions, old sign-in attempts and audit rows beyond retention."""
    now = utcnow()
    db.query(LoginSession).filter(LoginSession.expires_at < now).delete(synchronize_session=False)
    db.query(LoginAttempt).filter(LoginAttempt.attempted_at < now - timedelta(days=2)).delete(synchronize_session=False)
    db.query(AuditLog).filter(AuditLog.created_at < now - timedelta(days=settings.audit_retention_days)).delete(synchronize_session=False)
    db.query(Job).filter(Job.state.in_(["complete", "failed"]), Job.updated_at < now - timedelta(days=settings.audit_retention_days)).delete(synchronize_session=False)


async def _housekeeping():
    db = SessionLocal()
    try:
        housekeeping(db); db.commit()
    finally:
        db.close()


TRANSITION_GRACE = 180  # seconds a guest gets to finish an ACPI shutdown/reboot


def _statuses(cluster, machines):
    """(statuses, reachable). A fresh connection per cycle, closed before returning."""
    try:
        conn = hv.open_connection(cluster)
    except Exception as exc:
        log.warning("Reconcile: node %s unreachable: %s", cluster.name, hv.error_detail(exc))
        return {}, False
    try:
        return {m.id: domain_status(cluster, m.vm_name, conn=conn) for m in machines}, True
    finally:
        conn.close()


async def probe_fresh_process(cluster_id: int) -> int:
    """Open the node link from a brand-new process (python -m plexus.probe).
    0 = reachable, 3 = unreachable, anything else = the probe itself failed."""
    try:
        process = await asyncio.create_subprocess_exec(sys.executable, "-m", "plexus.probe", str(int(cluster_id)),
                                                       stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE)
        _out, err = await asyncio.wait_for(process.communicate(), timeout=60)
        if process.returncode not in (0, 3):
            log.warning("Fresh-process probe for node %s exited %s: %s", cluster_id, process.returncode, (err or b"").decode(errors="replace")[-300:])
        return int(process.returncode)
    except Exception as exc:
        log.warning("Fresh-process probe for node %s could not run: %s", cluster_id, hv.error_detail(exc))
        return 1


async def note_reachability(cluster, reachable: bool):
    """A4: after node_failure_cycles failed cycles in a row, check the same link from a new
    process. If that works, this long-running process holds broken hypervisor state, so it
    exits and systemd starts a fresh one. If it fails too, the node itself is down and a
    restart would not help (and would interrupt other jobs), so it only logs."""
    threshold = settings.node_failure_cycles
    if reachable:
        failed = _UNREACHABLE.pop(cluster.id, 0)
        if failed >= threshold:
            log.info("Node %s is reachable again after %d failed cycles", cluster.name, failed)
        return
    failed = _UNREACHABLE[cluster.id] = _UNREACHABLE.get(cluster.id, 0) + 1
    if failed % threshold:
        return
    code = await probe_fresh_process(cluster.id)
    if code == 3:
        log.warning("Node %s has been unreachable for %d cycles, also from a fresh process: check the node and its network", cluster.name, failed)
    else:
        request_restart(f"node {cluster.name} unreachable for {failed} cycles from this worker"
                        + (" but reachable from a fresh process" if code == 0 else " and the fresh-process check failed"))


def check_resources():
    """Restart before running out of file descriptors (a leak would surface as random
    transport errors such as unverifiable SSH host keys)."""
    try:
        import resource
        soft = resource.getrlimit(resource.RLIMIT_NOFILE)[0]
        used = len(os.listdir("/proc/self/fd"))
    except Exception:
        return
    if soft and soft > 0 and used > soft * 0.85:
        request_restart(f"{used} of {soft} file descriptors in use")


def next_power_state(stored: str, observed: str, seconds_since_request: float | None) -> str | None:
    """Decide what reconcile should write. None = leave the row alone.

    stopping: only `stopped` confirms it; while the guest is still running inside the
    grace window we keep `stopping` so the UI does not flap back to running.
    restarting: the domain stays running across a reboot, so running confirms it.
    crashed: shown as stopped (the crash itself is written to the activity log).
    """
    if observed == "crashed":
        observed = "stopped"
    if observed not in {"running", "stopped"} or stored == "suspended":
        return None
    if stored == "stopping" and observed == "running":
        if seconds_since_request is not None and seconds_since_request < TRANSITION_GRACE:
            return None
        return "running"  # guest ignored ACPI shutdown; show the truth
    if stored in {"running", "stopped", "starting", "stopping", "restarting", "unknown"} and stored != observed:
        return observed
    return None


# Settled machines are compared with the hypervisor every FULL_RECONCILE_SECONDS; machines
# in a transition (booting, shutting down, rebooting, unknown) every FAST_RECONCILE_SECONDS,
# so the panel shows the real state within seconds of it changing.
FAST_RECONCILE_SECONDS = 5
FULL_RECONCILE_SECONDS = 30
TRANSITIONAL = {"starting", "stopping", "restarting", "unknown"}
OWNED_BY_JOBS = {"provisioning", "rebuilding", "deleting", "failed", "suspended", "transferring"}
_last_full_reconcile = 0.0


async def _reconcile(full: bool = True):
    db = SessionLocal()
    try:
        query = db.query(Machine).filter(Machine.state.notin_(list(OWNED_BY_JOBS)))
        if not full:
            query = query.filter(Machine.state.in_(list(TRANSITIONAL)))
        machines = query.all()
        groups = list(_by_cluster(machines).values())
        if not full:
            # Nodes that failed the last full pass are left to it (no log flood every 5 s).
            groups = [g for g in groups if not _UNREACHABLE.get(g[0].cluster_id)]
        answers = await asyncio.gather(*(asyncio.to_thread(_statuses, group[0].cluster, group) for group in groups), return_exceptions=True)
        for group, answer in zip(groups, answers):
            if isinstance(answer, BaseException):
                log.warning("Reconcile: reading %s failed: %s", group[0].cluster.name, hv.error_detail(answer))
                statuses, reachable = {}, False
            else:
                statuses, reachable = answer
            if full:
                await note_reachability(group[0].cluster, reachable)
            for machine in group:
                try:
                    db.refresh(machine)
                    if machine.state in OWNED_BY_JOBS:
                        continue  # changed while we were asking the node
                    if db.query(Job.id).filter(Job.machine_id == machine.id, Job.state.in_(["queued", "running"])).first():
                        continue  # a job owns the state right now
                    last = db.query(Job.updated_at).filter(Job.machine_id == machine.id, Job.kind.in_(["stop", "restart"])).order_by(Job.updated_at.desc()).first()
                    since = None
                    if last and last[0]:
                        since = (utcnow() - _aware(last[0])).total_seconds()
                    observed = statuses.get(machine.id, "unknown")
                    if observed == "crashed" and machine.state != "stopped":
                        db.add(AuditLog(action="machine.crashed", target=machine.id, result="failed"))
                    target = next_power_state(machine.state, observed, since)
                    if target:
                        log.info("Reconcile: %s %s -> %s", machine.id, machine.state, target)
                        machine.set_power_state(target)
                except Exception:
                    log.exception("Reconcile failed for %s", machine.id)
        db.commit()
    finally:
        db.close()
    if full:
        check_resources()
    heartbeat("reconcile")


async def _reconcile_tick():
    """Fast pass every tick; a full pass every FULL_RECONCILE_SECONDS."""
    global _last_full_reconcile
    now = time.monotonic()
    full = now - _last_full_reconcile >= FULL_RECONCILE_SECONDS
    if full:
        _last_full_reconcile = now
    await _reconcile(full=full)


async def _periodic(fn, interval_fn):
    """Run fn forever on its own schedule so a slow pass never blocks job dispatch."""
    while True:
        try:
            await fn()
        except Exception:
            log.exception("Background task %s failed; retrying next cycle", getattr(fn, "__name__", fn))
        await asyncio.sleep(interval_fn())


async def _drain(tasks: set):
    """Stop taking jobs and give running ones up to RESTART_DRAIN_SECONDS to finish."""
    if tasks:
        log.warning("Waiting up to %d s for %d running job(s) before restarting", RESTART_DRAIN_SECONDS, len(tasks))
        await asyncio.wait(set(tasks), timeout=RESTART_DRAIN_SECONDS)


async def worker_loop():
    """Dispatch up to worker_concurrency jobs at once, never two for the same machine."""
    global _RESTART_REASON
    _RESTART_REASON = None
    db = SessionLocal()
    try:
        recovered = db.query(Job).filter(Job.state == "running").count()
        recover_interrupted(db); db.commit()
        if recovered:
            log.info("Requeued %d job(s) interrupted by the previous stop", recovered)
    finally:
        db.close()
    log.info("Worker started: %d job slots, metrics every %d s, reconcile every %d s (transitions every %d s)",
             settings.worker_concurrency, settings.metrics_interval_seconds, FULL_RECONCILE_SECONDS, FAST_RECONCILE_SECONDS)
    slots = asyncio.Semaphore(settings.worker_concurrency)
    busy_machines: set[str] = set()
    tasks: set[asyncio.Task] = set()
    background = [
        asyncio.create_task(_periodic(_poll_metrics, lambda: settings.metrics_interval_seconds)),
        asyncio.create_task(_periodic(_reconcile_tick, lambda: FAST_RECONCILE_SECONDS)),
        asyncio.create_task(_periodic(_housekeeping, lambda: 3600)),
    ]

    async def run(job_id, machine_id):
        try:
            await _run_job(job_id)
        finally:
            if machine_id: busy_machines.discard(machine_id)
            slots.release()

    try:
        while True:
            if _RESTART_REASON:
                await _drain(tasks)
                raise WorkerRestart(_RESTART_REASON)
            await slots.acquire()
            db = SessionLocal()
            try:
                _requeue_stale(db); db.commit()
                job_id, machine_id = _claim_next(db, busy_machines)
            except Exception:
                log.exception("Could not claim the next job; retrying")
                db.rollback()
                job_id, machine_id = None, None
            finally:
                db.close()
            if job_id is None:
                slots.release()
                await asyncio.sleep(settings.worker_interval_seconds)
                continue
            if machine_id: busy_machines.add(machine_id)
            task = asyncio.create_task(run(job_id, machine_id))
            tasks.add(task); task.add_done_callback(tasks.discard)
    finally:
        for task in background: task.cancel()
        for task in tasks: task.cancel()
