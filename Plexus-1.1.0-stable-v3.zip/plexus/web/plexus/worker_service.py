"""Standalone process entry point for background jobs and metrics."""
import asyncio
import logging
import sys
from plexus import __version__
from plexus.config import production_problems, settings
from plexus.logging_setup import configure_logging
from plexus.worker import WorkerRestart, worker_loop

# Distinct non-zero exit status: systemd (Restart=on-failure) starts a fresh worker.
RESTART_EXIT_CODE = 75

if __name__ == "__main__":
    configure_logging(settings.log_level)
    log = logging.getLogger("plexus.worker")
    problems = production_problems(settings)
    if problems:
        sys.exit("Refusing to start: " + "; ".join(problems))
    log.info("Plexus %s worker starting (time zone %s)", __version__, settings.timezone)
    try:
        asyncio.run(worker_loop())
    except WorkerRestart as exc:
        log.error("Exiting so systemd starts a fresh worker: %s", exc)
        sys.exit(RESTART_EXIT_CODE)
    except KeyboardInterrupt:
        log.info("Worker stopped")
